# ************************************************************
# Sequel Pro SQL dump
# Versión 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: localhost (MySQL 5.7.26)
# Base de datos: agustitorellomata
# Tiempo de Generación: 2020-03-17 15:06:16 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Volcado de tabla apps_countries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `apps_countries`;

CREATE TABLE `apps_countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(4) NOT NULL DEFAULT '',
  `country_name` varchar(100) NOT NULL DEFAULT '',
  `active` int(2) DEFAULT '0',
  `order` int(2) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `apps_countries` WRITE;
/*!40000 ALTER TABLE `apps_countries` DISABLE KEYS */;

INSERT INTO `apps_countries` (`id`, `country_code`, `country_name`, `active`, `order`)
VALUES
	(1,'AF','Afghanistan',0,0),
	(2,'AL','Albania',0,0),
	(4,'DS','American Samoa',0,0),
	(6,'AO','Angola',0,0),
	(7,'AI','Anguilla',0,0),
	(9,'AG','Antigua and Barbuda',0,0),
	(10,'AR','Argentina',0,0),
	(11,'AM','Armenia',0,0),
	(12,'AW','Aruba',0,0),
	(13,'AU','Australia',0,0),
	(14,'AT','Austria',1,0),
	(15,'AZ','Azerbaijan',0,0),
	(16,'BS','Bahamas',0,0),
	(17,'BH','Bahrain',0,0),
	(18,'BD','Bangladesh',0,0),
	(19,'BB','Barbados',0,0),
	(20,'BY','Belarus',0,0),
	(21,'BE','Belgium',1,0),
	(22,'BZ','Belize',0,0),
	(23,'BJ','Benin',0,0),
	(24,'BM','Bermuda',0,0),
	(25,'BT','Bhutan',0,0),
	(26,'BO','Bolivia',0,0),
	(27,'BA','Bosnia and Herzegovina',1,0),
	(28,'BW','Botswana',0,0),
	(30,'BR','Brazil',0,0),
	(32,'BN','Brunei Darussalam',0,0),
	(33,'BG','Bulgaria',1,0),
	(34,'BF','Burkina Faso',0,0),
	(35,'BI','Burundi',0,0),
	(37,'CM','Cameroon',0,0),
	(38,'CA','Canada',0,0),
	(39,'CV','Cape Verde',0,0),
	(40,'KY','Cayman Islands',0,0),
	(42,'TD','Chad',0,0),
	(43,'CL','Chile',0,0),
	(44,'CN','China',0,0),
	(47,'CO','Colombia',0,0),
	(48,'KM','Comoros',0,0),
	(49,'CG','Congo',0,0),
	(50,'CK','Cook Islands',0,0),
	(51,'CR','Costa Rica',0,0),
	(52,'HR','Croatia (Hrvatska)',1,0),
	(53,'CU','Cuba',0,0),
	(54,'CY','Cyprus',1,0),
	(55,'CZ','Czech Republic',1,0),
	(56,'DK','Denmark',1,0),
	(57,'DJ','Djibouti',0,0),
	(58,'DM','Dominica',0,0),
	(59,'DO','Dominican Republic',0,0),
	(60,'TP','East Timor',0,0),
	(61,'EC','Ecuador',0,0),
	(62,'EG','Egypt',0,0),
	(63,'SV','El Salvador',0,0),
	(64,'GQ','Equatorial Guinea',0,0),
	(65,'ER','Eritrea',0,0),
	(66,'EE','Estonia',1,0),
	(69,'FO','Faroe Islands',0,0),
	(70,'FJ','Fiji',0,0),
	(71,'FI','Finland',1,0),
	(72,'FR','France',1,0),
	(74,'GF','French Guiana',0,0),
	(75,'PF','French Polynesia',0,0),
	(77,'GA','Gabon',0,0),
	(78,'GM','Gambia',0,0),
	(79,'GE','Georgia',0,0),
	(80,'DE','Germany',1,0),
	(81,'GH','Ghana',0,0),
	(83,'GK','Guernsey',0,0),
	(84,'GR','Greece',1,0),
	(85,'GL','Greenland',0,0),
	(87,'GP','Guadeloupe',0,0),
	(88,'GU','Guam',0,0),
	(89,'GT','Guatemala',0,0),
	(90,'GN','Guinea',0,0),
	(91,'GW','Guinea-Bissau',0,0),
	(93,'HT','Haiti',0,0),
	(95,'HN','Honduras',0,0),
	(96,'HK','Hong Kong',0,0),
	(97,'HU','Hungary',1,0),
	(98,'IS','Iceland',1,0),
	(99,'IN','India',0,0),
	(100,'IM','Isle of Man',0,0),
	(101,'ID','Indonesia',0,0),
	(102,'IR','Iran (Islamic Republic of)',0,0),
	(103,'IQ','Iraq',0,0),
	(104,'IE','Ireland',1,0),
	(105,'IL','Israel',1,0),
	(106,'IT','Italy',1,0),
	(107,'CI','Ivory Coast',0,0),
	(108,'JE','Jersey',0,0),
	(109,'JM','Jamaica',0,0),
	(110,'JP','Japan',0,0),
	(111,'JO','Jordan',0,0),
	(112,'KZ','Kazakhstan',0,0),
	(113,'KE','Kenya',0,0),
	(118,'KW','Kuwait',0,0),
	(120,'LA','Lao People\'s Democratic Republic',0,0),
	(121,'LV','Latvia',1,0),
	(122,'LB','Lebanon',0,0),
	(123,'LS','Lesotho',0,0),
	(124,'LR','Liberia',0,0),
	(125,'LY','Libyan Arab Jamahiriya',0,0),
	(126,'LI','Liechtenstein',1,0),
	(127,'LT','Lithuania',1,0),
	(128,'LU','Luxembourg',1,0),
	(129,'MO','Macau',0,0),
	(130,'MK','Macedonia',1,0),
	(131,'MG','Madagascar',0,0),
	(132,'MW','Malawi',0,0),
	(133,'MY','Malaysia',0,0),
	(134,'MV','Maldives',0,0),
	(135,'ML','Mali',0,0),
	(136,'MT','Malta',1,0),
	(137,'MH','Marshall Islands',0,0),
	(139,'MR','Mauritania',0,0),
	(140,'MU','Mauritius',0,0),
	(141,'TY','Mayotte',0,0),
	(142,'MX','Mexico',0,0),
	(143,'FM','Micronesia, Federated States of',0,0),
	(144,'MD','Moldova, Republic of',0,0),
	(145,'MC','Monaco',1,0),
	(146,'MN','Mongolia',0,0),
	(147,'ME','Montenegro',1,0),
	(149,'MA','Morocco',0,0),
	(150,'MZ','Mozambique',0,0),
	(152,'NA','Namibia',0,0),
	(154,'NP','Nepal',0,0),
	(156,'AN','Netherlands Antilles',1,0),
	(158,'NZ','New Zealand',1,0),
	(159,'NI','Nicaragua',0,0),
	(160,'NE','Niger',0,0),
	(161,'NG','Nigeria',0,0),
	(165,'NO','Norway',1,0),
	(166,'OM','Oman',0,0),
	(167,'PK','Pakistan',0,0),
	(168,'PW','Palau',0,0),
	(169,'PS','Palestine',0,0),
	(170,'PA','Panama',0,0),
	(172,'PY','Paraguay',0,0),
	(173,'PE','Peru',0,0),
	(174,'PH','Philippines',0,0),
	(176,'PL','Poland',1,0),
	(177,'PT','Portugal',1,0),
	(178,'PR','Puerto Rico',0,0),
	(179,'QA','Qatar',0,0),
	(180,'RE','Reunion',0,0),
	(181,'RO','Romania',1,0),
	(182,'RU','Russian Federation',1,0),
	(183,'RW','Rwanda',0,0),
	(184,'KN','Saint Kitts and Nevis',0,0),
	(185,'LC','Saint Lucia',0,0),
	(187,'WS','Samoa',0,0),
	(188,'SM','San Marino',0,0),
	(190,'SA','Saudi Arabia',0,0),
	(191,'SN','Senegal',0,0),
	(192,'RS','Serbia',1,0),
	(193,'SC','Seychelles',0,0),
	(194,'SL','Sierra Leone',0,0),
	(195,'SG','Singapore',0,0),
	(196,'SK','Slovakia',0,0),
	(197,'SI','Slovenia',1,0),
	(199,'SO','Somalia',0,0),
	(200,'ZA','South Africa',0,0),
	(202,'ES','Spain (España)',1,1),
	(203,'LK','Sri Lanka',0,0),
	(206,'SD','Sudan',0,0),
	(207,'SR','Suriname',0,0),
	(209,'SZ','Swaziland',0,0),
	(210,'SE','Sweden',1,0),
	(211,'CH','Switzerland',1,0),
	(213,'TW','Taiwan',0,0),
	(215,'TZ','Tanzania, United Republic of',0,0),
	(216,'TH','Thailand',0,0),
	(217,'TG','Togo',0,0),
	(220,'TT','Trinidad and Tobago',0,0),
	(222,'TR','Turkey',1,0),
	(223,'TM','Turkmenistan',0,0),
	(226,'UG','Uganda',0,0),
	(227,'UA','Ukraine',1,0),
	(228,'AE','United Arab Emirates',0,0),
	(229,'GB','United Kingdom',1,0),
	(230,'US','United States',0,0),
	(232,'UY','Uruguay',0,0),
	(233,'UZ','Uzbekistan',0,0),
	(234,'VU','Vanuatu',0,0),
	(235,'VA','Vatican City State',0,0),
	(236,'VE','Venezuela',0,0),
	(237,'VN','Vietnam',0,0),
	(238,'VG','Virgin Islands (British)',0,0),
	(239,'VI','Virgin Islands (U.S.)',0,0),
	(240,'WF','Wallis and Futuna Islands',0,0),
	(242,'YE','Yemen',0,0),
	(245,'ZM','Zambia',0,0),
	(246,'ZW','Zimbabwe',0,0),
	(247,'ESAN','Andorra (Spain)',1,0),
	(248,'ESMA','Palma de Mallorca (Spain)',1,0),
	(249,'ESBA','Baleares (Spain)',1,0),
	(250,'ESPA','Las Palmas y Tenerife (Spain)',1,0),
	(251,'ESCA','Canarias Menores (Spain)',1,0),
	(252,'ESCE','Ceuta y Melilla (Spain)',1,0);

/*!40000 ALTER TABLE `apps_countries` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla category
# ------------------------------------------------------------

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `hash` varchar(255) DEFAULT NULL,
  `lang_data` text,
  `menu_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;

INSERT INTO `category` (`id`, `parent_id`, `order`, `hash`, `lang_data`, `menu_name`)
VALUES
	(23,0,5,'cava-texturitzat','{\"es\":\"CAVA TEXTURITZADO\",\"en\":\"CAVA TEXTURITZAT\",\"ca\":\"CAVA TEXTURITZAT\"}','CAVA TEXTURITZAT'),
	(19,0,0,'cavas','{\"es\":\"Cavas\",\"en\":\"Cavas\",\"ca\":\"Caves\"}','Cavas'),
	(20,0,2,'vinos','{\"es\":\"Vinos\",\"en\":\"Wines\",\"ca\":\"Vins\"}','Vinos'),
	(21,0,3,'l’esperit','{\"es\":\"L&rsquo;Esperit\",\"en\":\"L&rsquo;Esperit\",\"ca\":\"L&rsquo;Esperit\"}','L’Esperit'),
	(22,0,4,'vinagres','{\"es\":\"Vinagres\",\"en\":\"Vinegars\",\"ca\":\"Vinagres\"}','Vinagres'),
	(24,0,1,'productes-gourmet','{\"es\":\"Productos Gourmet\",\"en\":\"Gourmet\",\"ca\":\"Productes Gourmet\"}','Productes Gourmet');

/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla countries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `countries`;

CREATE TABLE `countries` (
  `code` varchar(2) DEFAULT NULL,
  `locale` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;

INSERT INTO `countries` (`code`, `locale`)
VALUES
	('af','af_ZA'),
	('ar','ar'),
	('bg','bg_BG'),
	('ca','ca_ES'),
	('cs','cs_CZ'),
	('cy','cy_GB'),
	('da','da_DK'),
	('de','de_DE'),
	('el','el_GR'),
	('en','en_US'),
	('es','es_ES'),
	('et','et_EE'),
	('eu','eu'),
	('fa','fa_IR'),
	('fi','fi_FI'),
	('fr','fr_FR'),
	('he','he_IL'),
	('hr','hr_HR'),
	('hu','hu_HU'),
	('id','id_ID'),
	('is','is_IS'),
	('it','it_IT'),
	('ja','ja_JP'),
	('km','km_KH'),
	('ko','ko_KR'),
	('lt','lt_LT'),
	('lv','lv_LV'),
	('mn','mn_MN'),
	('nb','nb_NO'),
	('nl','nl_NL'),
	('nn','nn_NO'),
	('pl','pl_PL'),
	('pt','pt_PT'),
	('ro','ro_RO'),
	('ru','ru_RU'),
	('sk','sk_SK'),
	('sl','sl_SI'),
	('sr','sr_RS'),
	('sv','sv_SE'),
	('th','th_TH'),
	('tr','tr_TR'),
	('uk','uk_UA'),
	('vi','vi_VN'),
	('zh','zh_CN');

/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla gallery
# ------------------------------------------------------------

DROP TABLE IF EXISTS `gallery`;

CREATE TABLE `gallery` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `objects` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `gallery` WRITE;
/*!40000 ALTER TABLE `gallery` DISABLE KEYS */;

INSERT INTO `gallery` (`id`, `title`, `objects`)
VALUES
	(1,'cavas-grid',NULL),
	(2,'solid-blanc','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"99690d21c78c91f992280e9faa6fd631\",\"img\":\"content\\/f625de8d03aca1c8e948bf535ee1773e.jpg\",\"thumb\":\"content\\/0.96436700-15506983151e575edd609d72496a6d324df5b0b753w_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"solid-blanc.jpg\",\"isThumb\":\"1\",\"id\":\"25a5ac71df7bbb4565164bc58fab5201\",\"img\":\"content\\/1c58be4b38e0e8c7148bad288a3b7ddf.jpg\",\"thumb\":\"content\\/0.04307000-15541050610c282261c947c1af44d7a9914348b9edw_450h_.jpg\",\"type\":\"image\"}]'),
	(3,'solid-rosat','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"2fc18991fe4ac727bb6ade222766994e\",\"img\":\"content\\/b9d21ef3146696538359c8aa1bbd7ff6.jpg\",\"thumb\":\"content\\/0.04095800-1550698320ec4a2a7ed061248ba9bd39284c0f26caw_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"solid-rosat.jpg\",\"isThumb\":\"1\",\"id\":\"a5e5b0233867dff50cd1f6d50d5b07a2\",\"img\":\"content\\/73bc092b55701058f5442776fd7ba51b.jpg\",\"thumb\":\"content\\/0.73465100-1554105073c9c0b44ec80386e4f89226b4febb148dw_450h_.jpg\",\"type\":\"image\"}]'),
	(4,'vinagres-cava','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"98d95f4a32403c98f57a5f8bd4308a99\",\"img\":\"content\\/963cfa3ae746d8092d84d4e66737d081.jpg\",\"thumb\":\"content\\/0.52435600-1550698400955b9c8de3d440b62507d5e5e33daf26w_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"sec-de-cava.jpg\",\"isThumb\":\"1\",\"id\":\"4a6607c680cd687c143c157f71e019da\",\"img\":\"content\\/1284ffb35ffad59648ed4b5bbeb83c97.jpg\",\"thumb\":\"content\\/0.34345400-155410511566093eab9f85ad8100ddd4b40addddf0w_450h_.jpg\",\"type\":\"image\"}]'),
	(5,'vinagres-balsamic','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"3d25e5575be48b1d5e03b432441d6db2\",\"img\":\"content\\/e960577e8d9b49894773237e3e23d8b0.jpg\",\"thumb\":\"content\\/0.54607300-1550698404e15995347ff4d9aab0e0b1b68d78c1f1w_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"balsa\\u0300mic-de-cava.jpg\",\"isThumb\":\"1\",\"id\":\"e50ede17200b5f3e5a78499c70ff9e6f\",\"img\":\"content\\/4bb8345f56cdf5987f70a736cd64e251.jpg\",\"thumb\":\"content\\/0.26934000-155410509362bedc8502c33169bca6b2a96fa6182cw_450h_.jpg\",\"type\":\"image\"}]'),
	(6,'lesperit','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"0454a7e2af1cc3fc2c5a6cb9656e1d10\",\"img\":\"content\\/c5696cf1135312cb37afb90730c068b4.jpg\",\"thumb\":\"content\\/0.29581900-15506984527d41b1433c49e9b0b7aac437664ca305w_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"l\'esperit.jpg\",\"isThumb\":\"1\",\"id\":\"0e1ed73ac0a30bd1eb0796c4ab728259\",\"img\":\"content\\/16860e164c184437b9af2f10e2ce7e30.jpg\",\"thumb\":\"content\\/0.23415600-1554105027a1b5d48c3aa60fba94eacdc3a9a473a2w_450h_.jpg\",\"type\":\"image\"}]'),
	(7,'eco-xic','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"a632a3a5caf620a98ddfe2c9b88028cb\",\"img\":\"content\\/a97a3b273e55b41784ba09eb7aca6806.jpg\",\"thumb\":\"content\\/0.35814300-15506984890f1290606696d59a12f132437d002617w_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"agusti\\u0301-torello\\u0301-mata-Xic.jpg\",\"isThumb\":\"1\",\"id\":\"fbb7b0f19a2dc730336b93aa309b3384\",\"img\":\"content\\/15b5bc027c6f485cc10f4604361eda87.jpg\",\"thumb\":\"content\\/0.42139800-1554105133fee8253b30e0e5bc062de19fbc8be4bcw_450h_.jpg\",\"type\":\"image\"}]'),
	(8,'eco-aptia','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"d62245be15b4b50e45398af1112e4d64\",\"img\":\"content\\/3bae6e5c3ad339373378237904199eb6.jpg\",\"thumb\":\"content\\/0.46445300-1550698497e7204fc4ed416e417c7ae04ea86cf092w_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"APTIA\\u0300-2016.jpg\",\"isThumb\":\"1\",\"id\":\"3e0c7a539cf47823bf8417828a67683a\",\"img\":\"content\\/f32bfe2fad0660d727eeca49184a70cd.jpg\",\"thumb\":\"content\\/0.17557800-15541051483e3c0441f84d72aa7dc85746d37460f4w_450h_.jpg\",\"type\":\"image\"}]'),
	(9,'cavas-kripta-gran','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"7987e4a1595a4d3fe437154db50b2299\",\"img\":\"content\\/2f0f2bc12c5b6189777f82c99a170244.jpg\",\"thumb\":\"content\\/0.41723000-15506985565698570b03b868b39e9c140ad13b959fw_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"kripta-gran-an\\u0303ada.jpg\",\"isThumb\":\"1\",\"id\":\"20d25627eb1f551e58a93c3facc2b7a0\",\"img\":\"content\\/c4dea3e99169e6094a768fce8ca385e6.jpg\",\"thumb\":\"content\\/0.63203700-1554104927f03cbd12afdede9c0673dfb848811f6bw_450h_.jpg\",\"type\":\"image\"}]'),
	(10,'cavas-kripta','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"bd75f387f94a843d9e5be5c57a2d0ac4\",\"img\":\"content\\/73177aa11f35d467041760b00c3fb119.jpg\",\"thumb\":\"content\\/0.48742800-155069857061a8e6dcea8654bc1893e29bcfcfd1d8w_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"kripta.jpg\",\"isThumb\":\"1\",\"id\":\"b19fc8b10e302faa73375c92470d7872\",\"img\":\"content\\/4e5ebd21f61251ad3bbf268d07e37072.jpg\",\"thumb\":\"content\\/0.49509100-155410494179da4c33caee614887ef6aac01b192ddw_450h_.jpg\",\"type\":\"image\"}]'),
	(11,'cavas-magnum','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"fb85f62d0c8263a3641169b869c3ef1e\",\"img\":\"content\\/bfa5a1fec88fc03509bccb96a43fbe4e.jpg\",\"thumb\":\"content\\/0.91951100-15506985938ff37844a3b41beb4e35c62174dd0ae4w_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"magnum-gran-reserva.jpg\",\"isThumb\":\"1\",\"id\":\"de15eddb96370bfd215392d853aeffaf\",\"img\":\"content\\/b840bec442590e4465fd4ff3602dc40d.jpg\",\"thumb\":\"content\\/0.09904400-1554104956d48e1f968205de1561dd1625d40528a2w_450h_.jpg\",\"type\":\"image\"}]'),
	(12,'cavas-gran-res-barrica','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"4dd555528204856139bcd21f75083783\",\"img\":\"content\\/7b075e98f7705c3b5531fa867800c66f.jpg\",\"thumb\":\"content\\/0.11785400-1550698647f1c96ff59c09fa90fbb8438dd8ac5d35w_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"gran-reserva-barrica.jpg\",\"isThumb\":\"1\",\"id\":\"9d2497ceb99ef86981d5cff8016805a0\",\"img\":\"content\\/274d166b48aff4fec8ae3a96ae5658ba.jpg\",\"thumb\":\"content\\/0.01962600-15541048902813a992365a035ef851bafb99c8cf5aw_450h_.jpg\",\"type\":\"image\"}]'),
	(13,'cavas-brut-nat-res','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"8b2b1d490ca1484a486c927bd52f22f7\",\"img\":\"content\\/3fa25b18f3debca68d9c9be6ba4f4d0f.jpg\",\"thumb\":\"content\\/0.38525600-1550698675bccb3763e5c0eb7935f0034fdbad4a6fw_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"brut-nature-gran-reserva.jpg\",\"isThumb\":\"1\",\"id\":\"c2692e0b9db3b041821294fccebbe177\",\"img\":\"content\\/e0d2b38df2510691e5c4f971a37716bd.jpg\",\"thumb\":\"content\\/0.96211300-1554104845d5b7f3daa6f3c8fa88541894cf4e662fw_450h_.jpg\",\"type\":\"image\"}]'),
	(14,'cavas-brut-gran-res','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"6e6cebc0a8fdf15238dfec81773ea865\",\"img\":\"content\\/bd0942f12f9884061c7027bf03b44bd4.jpg\",\"thumb\":\"content\\/0.00587400-155069869894031d9fd60077e06e75489152702a51w_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"brut-gran-reserva.jpg\",\"isThumb\":\"1\",\"id\":\"e327a20c56498b1358b595edc92e144a\",\"img\":\"content\\/6dcc7e2e5b30264028c9bacc3b29fb1e.jpg\",\"thumb\":\"content\\/0.62486800-1554104828da1bcf5432cf92fd75874918d0fe519ew_450h_.jpg\",\"type\":\"image\"}]'),
	(15,'cavas-brut-res','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"a8affc2f971436b3086ee51b47d6ea06\",\"img\":\"content\\/b64e36a79d1ce06bc990ed52b5600acb.jpg\",\"thumb\":\"content\\/0.59562200-1550698716b20bf3375e3cceb9362661d7a8f2be1dw_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"brut-reserva.jpg\",\"isThumb\":\"1\",\"id\":\"c87008aa827dd37c5527190aae26cfad\",\"img\":\"content\\/4ae9650c070678b81c1772613ec6c602.jpg\",\"thumb\":\"content\\/0.44443400-1554104863481740c7184d254b5aa40976060a9cc5w_450h_.jpg\",\"type\":\"image\"}]'),
	(16,'cavas-rosat-trepat','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"95b0b8c99b2b9875cd17d7af25172455\",\"img\":\"content\\/d86799efa882eca1f2bdde1ce8b243b0.jpg\",\"thumb\":\"content\\/0.90882400-15506987320fd0abf6339bd05b4a8bec0b16d5b7f3w_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"rosat-trepat.jpg\",\"isThumb\":\"1\",\"id\":\"ca4699698593ce3c627d34963e96efe0\",\"img\":\"content\\/3cfc9eb2e5c4acf3be11a902fc418e56.jpg\",\"thumb\":\"content\\/0.04652600-15541049735b6b79b1ec60b1724ef08463b5c5afa4w_450h_.jpg\",\"type\":\"image\"}]'),
	(17,'cavas-375-brut','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"4479e7ca3470047e173fab745dc41a5f\",\"img\":\"content\\/2e3fdc1581a92deb2fe913fd8a641aef.jpg\",\"thumb\":\"content\\/0.51184200-15506987531b0bf9edf67d40aabaabd1e913799c6aw_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"375-Brut-Gran-Reserva.jpg\",\"isThumb\":\"1\",\"id\":\"6a6f9d48da61e4f9f5a8ecf6eac76159\",\"img\":\"content\\/e64888c02f0065931239b88e7a1a68ae.jpg\",\"thumb\":\"content\\/0.97406400-155410478083702f6ed5fb5b43d8d66de8592b6edcw_450h_.jpg\",\"type\":\"image\"}]'),
	(18,'cavas-375-rosat','[{\"alt\":\"\",\"title\":\"\",\"isThumb\":0,\"id\":\"e465be4eb30896282c39a6681087e98f\",\"img\":\"content\\/42d7f2f05617475e1b53173dfa1c2c62.jpg\",\"thumb\":\"content\\/0.61335400-1550698757a2e74bfb0f5601ab07fa213d1568315fw_450h_.jpg\",\"type\":\"image\"},{\"alt\":\"\",\"title\":\"375-Rosat-Trepat.jpg\",\"isThumb\":\"1\",\"id\":\"a25c907a517807ae5ba0d0c65388aeca\",\"img\":\"content\\/da2e052102cff606847196aeced35bba.jpg\",\"thumb\":\"content\\/0.27184400-1554104806137e9a9b3a14256b862237c4455e7dabw_450h_.jpg\",\"type\":\"image\"}]'),
	(19,'pantalla-home','[{\"isThumb\":0,\"img\":\"content\\/aa8369e669eaf0065b62ed39e0173e5b.jpg\",\"thumb\":\"content\\/0.61437000-1550699378e19e58c777c4869e38c1552e5dd41f00w_450h_.jpg\",\"alt\":\"\",\"title\":\"\",\"type\":\"image\",\"id\":\"d9a2ba739e1d69f8bf52861dd068a82f\"}]'),
	(20,'pantalla-filosofia','[{\"isThumb\":0,\"img\":\"content\\/29143975801b9225a8bb74a5674be45e.jpg\",\"thumb\":\"content\\/0.51334900-15506994892709e51f6795ab6e7dabf8f7358d4609w_450h_.jpg\",\"alt\":\"\",\"title\":\"\",\"type\":\"image\",\"id\":\"8af9d1e9e6d9a9eca0c33016ef7d2105\"}]'),
	(21,'pantalla-visitas','[{\"isThumb\":0,\"img\":\"content\\/b64c0d15ace5a1d98afc2448cc92e396.jpg\",\"thumb\":\"content\\/0.04365900-1550699533088bd795456c4349418ecd085abb12f6w_450h_.jpg\",\"alt\":\"\",\"title\":\"\",\"type\":\"image\",\"id\":\"3d9cd99929cdaf0953191ea057736b77\"},{\"isThumb\":0,\"img\":\"content\\/4d660da7b11860ccaef7eb2abc539cdb.jpg\",\"thumb\":\"content\\/0.01899700-1554104013dfe7783c68e1ad8f3518ba1a48c91fadw_450h_.jpg\",\"alt\":\"\",\"title\":\"peu-4-estaciones-400px.jpg\",\"type\":\"image\",\"id\":\"af5d5bc8c68a366f85af86c4d4ac0af8\"},{\"isThumb\":0,\"img\":\"content\\/5c5ac5ea5dd3ea3da2bcc3c9aab81775.jpg\",\"thumb\":\"content\\/0.31771900-15541040149f6d604d32a0ce1a209c4b6b29694d37w_450h_.jpg\",\"alt\":\"\",\"title\":\"peu-4-estaciones.jpg\",\"type\":\"image\",\"id\":\"3f02a8f5f788ccf78f6d7e2a845d2466\"}]'),
	(22,'pantalla-visitas-slider','[{\"isThumb\":0,\"img\":\"content\\/0741cce43ac942b25f10649dadbae278.jpg\",\"thumb\":\"content\\/0.45622000-1550699542ddd9149a01d17d3f91bba62bc6c4aa36w_450h_.jpg\",\"alt\":\"\",\"title\":\"\",\"type\":\"image\",\"id\":\"3875b0d4c53da599ed7f2c09af953478\"}]'),
	(23,'pantalla-kripta','[{\"isThumb\":0,\"img\":\"content\\/6cd2f06db803d20e1ec77806a46b89c8.jpg\",\"thumb\":\"content\\/0.04989700-1550699557158d61b33e350e3d7c65936b7e44a737w_450h_.jpg\",\"alt\":\"\",\"title\":\"\",\"type\":\"image\",\"id\":\"22ccc51adcd3ec973d18f4796bcc452a\"},{\"isThumb\":0,\"img\":\"content\\/c6046e0df43bc23695bd9991b00c527f.jpg\",\"thumb\":\"content\\/0.26507000-155069955773d7029c17b3f2dc780ce5b113612f00w_450h_.jpg\",\"alt\":\"\",\"title\":\"\",\"type\":\"image\",\"id\":\"104c1ebcf1f42a2a49e1fa58bd52610c\"}]'),
	(24,'documentos','[{\"isThumb\":0,\"img\":\"content\\/31a7782884f18159680dea1d80a74a10.pdf\",\"thumb\":\"images\\/fileformat\\/pdf.png\",\"alt\":\"\",\"title\":\"BARRICA 2012 Esp.pdf\",\"type\":\"file\",\"id\":\"40f1bf14fde866ad0038b77e1fa8ef70\"},{\"isThumb\":0,\"img\":\"content\\/ef5ce2fbf5c65bd1ef38b639dd7327ef.pdf\",\"thumb\":\"images\\/fileformat\\/pdf.png\",\"alt\":\"\",\"title\":\"BRUT GRAN RESERVA 2012 Esp.pdf\",\"type\":\"file\",\"id\":\"d46c23c0e7c94c57f64de01794e0966f\"},{\"isThumb\":0,\"img\":\"content\\/3135e9ee60c869c19d7c26d1ce3572be.pdf\",\"thumb\":\"images\\/fileformat\\/pdf.png\",\"alt\":\"\",\"title\":\"BRUT NATURE 2012 Esp.pdf\",\"type\":\"file\",\"id\":\"3fae7b4780c3f103755df2b709cf8539\"},{\"isThumb\":0,\"img\":\"content\\/37198b4a2fb4df345c83d021a3498aee.pdf\",\"thumb\":\"images\\/fileformat\\/pdf.png\",\"alt\":\"\",\"title\":\"BRUT RVA 2015 Esp.pdf\",\"type\":\"file\",\"id\":\"b11f2f4a59bcb3195c16916bd803e433\"},{\"isThumb\":0,\"img\":\"content\\/dabe15cd3493c251afc06bc06fcc226a.pdf\",\"thumb\":\"images\\/fileformat\\/pdf.png\",\"alt\":\"\",\"title\":\"KRIPTA 2007 - 40 ANIVERSARIO Esp.pdf\",\"type\":\"file\",\"id\":\"3d9168b18a9c327f6fa5599f01039a89\"},{\"isThumb\":0,\"img\":\"content\\/16a07adb5b396d5dafa7560b28d61c2b.pdf\",\"thumb\":\"images\\/fileformat\\/pdf.png\",\"alt\":\"\",\"title\":\"KRIPTA.pdf\",\"type\":\"file\",\"id\":\"a8f128a9a9148f94adc2f6a351a1f915\"},{\"isThumb\":0,\"img\":\"content\\/64aa75e7673d3133d1e578bd9b7828f5.pdf\",\"thumb\":\"images\\/fileformat\\/pdf.png\",\"alt\":\"\",\"title\":\"MAGNUM 2010 Esp.pdf\",\"type\":\"file\",\"id\":\"0bec77be8dcd1cf162295b476ca44cd4\"},{\"isThumb\":0,\"img\":\"content\\/396520cc76b611a92b978bba1889eed5.pdf\",\"thumb\":\"images\\/fileformat\\/pdf.png\",\"alt\":\"\",\"title\":\"ROSAT 2016 Esp.pdf\",\"type\":\"file\",\"id\":\"2393effd261b8ac86d417a9456d5f46a\"},{\"isThumb\":0,\"img\":\"content\\/e0558260da2703d4dc5ab612dabf8eb5.pdf\",\"thumb\":\"images\\/fileformat\\/pdf.png\",\"alt\":\"\",\"title\":\"VI APTIA 2016 CAST-ANG.pdf\",\"type\":\"file\",\"id\":\"1dfe30a76968ba557a417c53a26972b9\"},{\"isThumb\":0,\"img\":\"content\\/0856ac2570412ad0bb4d470c28a5b502.pdf\",\"thumb\":\"images\\/fileformat\\/pdf.png\",\"alt\":\"\",\"title\":\"VI XIC 2018 Esp.pdf\",\"type\":\"file\",\"id\":\"ad7dd8625236299785bb05932bf43d3e\"},{\"isThumb\":0,\"img\":\"content\\/46101b77917b26cfa784cd8cb27b60c5.pdf\",\"thumb\":\"images\\/fileformat\\/pdf.png\",\"alt\":\"\",\"title\":\"XIC VERMELL 2016 Esp-Ang.pdf\",\"type\":\"file\",\"id\":\"37c26676c4733e88213ff18badcb263a\"},{\"isThumb\":0,\"img\":\"content\\/4072de9b75548f5b8fd591f6273e0424.pdf\",\"thumb\":\"images\\/fileformat\\/pdf.png\",\"alt\":\"\",\"title\":\"BRUT NATURE GRAN RESERVA 2012 Esp.pdf\",\"type\":\"file\",\"id\":\"07263fe9381f67d8e2d4e4609ad47c36\"}]'),
	(25,'pantalla premios','[{\"isThumb\":0,\"img\":\"content\\/dccdc3725edff48a8dec8bad21971a9c.jpg\",\"thumb\":\"content\\/0.69804000-155429348929ba2b49a7da986683e7b0b3c68c0571w_450h_.jpg\",\"alt\":\"\",\"title\":\"BARRICA-2016-CINVE.jpg\",\"type\":\"image\",\"id\":\"863eb214815f4b8f1a04ddb1ade8d57d\"},{\"isThumb\":0,\"img\":\"content\\/54ea471033228aac781883b87e24d2f5.jpg\",\"thumb\":\"content\\/0.84458700-1554293490d241bb6d2605c0c5f39908bbcb147df3w_450h_.jpg\",\"alt\":\"\",\"title\":\"CWWSC-Barrica-2011-2017.jpg\",\"type\":\"image\",\"id\":\"0dc8cb6356b1669b0fb69686fb0cbb42\"},{\"isThumb\":0,\"img\":\"content\\/e1070925896c2f622757e5ddeb825278.jpg\",\"thumb\":\"content\\/0.58265000-1554293491096af3f2fbc79bfd41a713b6dc39c869w_450h_.jpg\",\"alt\":\"\",\"title\":\"CWWSC-esperit-2016.jpg\",\"type\":\"image\",\"id\":\"22d4f211569ab1bcde5013bade36f88d\"},{\"isThumb\":0,\"img\":\"content\\/330834997186365a2df61de4c8f5ace2.jpg\",\"thumb\":\"content\\/0.14349200-155429349298c9c24aaba4e73681c914d50f7dd40ew_450h_.jpg\",\"alt\":\"\",\"title\":\"CWWSC-Rosat-2014-2017.jpg\",\"type\":\"image\",\"id\":\"a1e7f6d8c1476c25feffbc134bed10db\"},{\"isThumb\":0,\"img\":\"content\\/928f521739fb21231e28d92fc1f99e41.jpg\",\"thumb\":\"content\\/0.69648900-1554293492987ec61207cab91a3c4ac1dcb96e2d18w_450h_.jpg\",\"alt\":\"\",\"title\":\"decanter-2017.jpg\",\"type\":\"image\",\"id\":\"02403eaac47e1b72d957a6c51054dd9c\"},{\"isThumb\":0,\"img\":\"content\\/e519817b3954aee41648eb6f2d719a87.jpg\",\"thumb\":\"content\\/0.42292800-15542934931e2cca55706953c8ff9a50eb32318344w_450h_.jpg\",\"alt\":\"\",\"title\":\"Kripta-2008-Diploma-Medalla-ORO-CIVAS-2016-54.jpg\",\"type\":\"image\",\"id\":\"f413d735b9da6ebac8c449f42bc409f4\"},{\"isThumb\":0,\"img\":\"content\\/bc83fe0684ef4c355296501ac04ce0f7.jpg\",\"thumb\":\"content\\/0.20435200-1554293494c81e1c616313ee7910e5ecd7be7a1142w_450h_.jpg\",\"alt\":\"\",\"title\":\"KRIPTA-2016-CINVE.jpg\",\"type\":\"image\",\"id\":\"c48817f293030ed17f0913b497e0a991\"},{\"isThumb\":0,\"img\":\"content\\/7872c6caa335ae18d9c600d633fabd7c.jpg\",\"thumb\":\"content\\/0.55958900-1554293495a3a4f288d5d0333ae8ce37971d80e58dw_450h_.jpg\",\"alt\":\"\",\"title\":\"KRIPTA-2016.jpg\",\"type\":\"image\",\"id\":\"351c61008d5ad764a03060c8d7b4344a\"},{\"isThumb\":0,\"img\":\"content\\/5f4bf4d735d9247e55afc6916ef7e118.jpg\",\"thumb\":\"content\\/0.42700800-1554293496eaab78550645342df1dfd3d2b1c4dd10w_450h_.jpg\",\"alt\":\"\",\"title\":\"premio-XIC-20151-e1455723924966.jpg\",\"type\":\"image\",\"id\":\"6cdcd5b3bb91ead6dbf9ddecebea53cb\"},{\"isThumb\":0,\"img\":\"content\\/e943cf2c12ee7fe47a22e2d151594d85.jpg\",\"thumb\":\"content\\/0.27711800-1554293497364b55d6229e264e12f3b557b0388dacw_450h_.jpg\",\"alt\":\"\",\"title\":\"premios-magnum-2015-ORO.jpg\",\"type\":\"image\",\"id\":\"8373e69b8691fbb5e8eee1d56478a38c\"},{\"isThumb\":0,\"img\":\"content\\/dc46b7182853146453b37fdf4492effc.jpg\",\"thumb\":\"content\\/0.11681300-1554293498f142a7c933165a4998145fcc032b8444w_450h_.jpg\",\"alt\":\"\",\"title\":\"Premis-me-gusta_1-2015.jpg\",\"type\":\"image\",\"id\":\"d06eca7a1bc358ee7bc9dd730d1296b7\"},{\"isThumb\":0,\"img\":\"content\\/4453d708df310e9cb3de6cb0c6a1aa14.jpg\",\"thumb\":\"content\\/0.03682700-1554293499c2d5027c77590ea3756d30c725f26b51w_450h_.jpg\",\"alt\":\"\",\"title\":\"Premis-me-gusta_2-2015-e1455723668545.jpg\",\"type\":\"image\",\"id\":\"f2cf704d21929c963c8a5917217bf207\"},{\"isThumb\":0,\"img\":\"content\\/8fbe5f05f2cfafc911088ff77fb33083.jpg\",\"thumb\":\"content\\/0.84728700-155429349926d6d8d45a71226e9f55d86afb05da51w_450h_.jpg\",\"alt\":\"\",\"title\":\"Premis-me-gusta_3-2015-e1455723737596.jpg\",\"type\":\"image\",\"id\":\"f04dbc89d9f1862910e428113d5061c3\"},{\"isThumb\":0,\"img\":\"content\\/507c95135a8bf35e64110d2dd19dc9cb.jpg\",\"thumb\":\"content\\/0.70845100-15542935005a4a0193bf49392b9cd6159522540beaw_450h_.jpg\",\"alt\":\"\",\"title\":\"premis-me-gusta-MAGNUM-2016.jpg\",\"type\":\"image\",\"id\":\"f61c1caf817bb716ca2419fdd42dab8c\"},{\"isThumb\":0,\"img\":\"content\\/f19f5ad9ad42ca7e5ae2d30c4550483c.jpg\",\"thumb\":\"content\\/0.88190800-155429350190c06c2f6458f05a560ac2114255a73cw_450h_.jpg\",\"alt\":\"\",\"title\":\"puntuacio.jpg\",\"type\":\"image\",\"id\":\"fc61461e35283f882969b053bd1dc888\"},{\"isThumb\":0,\"img\":\"content\\/2960a27f19da94956e037737028487e6.jpg\",\"thumb\":\"content\\/0.52637200-15542935026bdd0e3c08c5e6c2be9168e828aed9fcw_450h_.jpg\",\"alt\":\"\",\"title\":\"VINUM-NATURE-Aptia-2013.jpg\",\"type\":\"image\",\"id\":\"d05c92bb29d82962529d60fe35c82db0\"},{\"isThumb\":0,\"img\":\"content\\/5be82de9c604ca687bfd8fd3f10f27b9.jpg\",\"thumb\":\"content\\/0.40464800-155429350370e0d4f199de932d222805c152730f8fw_450h_.jpg\",\"alt\":\"\",\"title\":\"Vivino-Wine-Style-awards-2014-Barrica.jpg\",\"type\":\"image\",\"id\":\"568056e28cd08ebadea057916ce365a2\"},{\"isThumb\":0,\"img\":\"content\\/59831f2ef3c0dda3f264617dbe571cb1.jpg\",\"thumb\":\"content\\/0.17055500-15542935040a49c4b28beb72e5eb1066a21d13d245w_450h_.jpg\",\"alt\":\"\",\"title\":\"Vivino-Wine-Style-awards-2014-Kripta.jpg\",\"type\":\"image\",\"id\":\"170afe99955ccedec764f3a061bffca4\"},{\"isThumb\":0,\"img\":\"content\\/720b5b3cf0dc36860091809a24d53ff1.png\",\"thumb\":\"content\\/0.97189200-155429350472afbe83af05f6ba23e999276aabbddcw_450h_.png\",\"alt\":\"\",\"title\":\"Vivinos-2017-Wine-Style-Awards.png\",\"type\":\"image\",\"id\":\"40c1376826d0b9da172a78cd070b8c58\"}]'),
	(26,'pantall el origen','[{\"isThumb\":0,\"img\":\"content\\/3501be95e6f447d8570b5b94e5e074f8.jpg\",\"thumb\":\"content\\/0.56254500-155440726871dfc2f38570c7d9e361b4cfb5f3cd69w_450h_.jpg\",\"alt\":\"\",\"title\":\"img-subzonas-depresiondelpenedes.jpg\",\"type\":\"image\",\"id\":\"84d8b5452284ca01107a9bfe898482a2\"},{\"isThumb\":0,\"img\":\"content\\/9634f9b8890261815839e8efc7a0c9a4.jpg\",\"thumb\":\"content\\/0.14570700-1554407562134d41189e9ed0ec8d17140f608e5857w_450h_.jpg\",\"alt\":\"\",\"title\":\"img-subzonas-sierralitoral.jpg\",\"type\":\"image\",\"id\":\"e09b00c419ff3f457be43e883748dbb2\"},{\"isThumb\":0,\"img\":\"content\\/e16c405eca1539e47ff92d24f17537a8.jpg\",\"thumb\":\"content\\/0.32372600-15544075986650892af25427cfb38c69e2d8ea9b99w_450h_.jpg\",\"alt\":\"\",\"title\":\"img-subzonas-sierraprelitoral.jpg\",\"type\":\"image\",\"id\":\"9c81d2a2ca4b05e55a6ce45b3c5e299b\"},{\"isThumb\":0,\"img\":\"content\\/41ef32cec2a4b48a51d10987ebcdbbbe.jpg\",\"thumb\":\"content\\/0.21303900-1554407606d682e27b23468387f819aa4d9231824cw_450h_.jpg\",\"alt\":\"\",\"title\":\"img-subzonas.jpg\",\"type\":\"image\",\"id\":\"772f1bd595addac6b556925bd9bd5b11\"}]'),
	(27,'pantalla variedad aut','[{\"isThumb\":0,\"img\":\"content\\/85028caeab5547a3b23d14f499252441.jpg\",\"thumb\":\"content\\/0.92612200-155440827929f22db95d55ed6e30c7978a1e63e20fw_450h_.jpg\",\"alt\":\"\",\"title\":\"img-variedadesautoctonas-macabeo1.jpg\",\"type\":\"image\",\"id\":\"4254d00359f78fcefeee1e6023f46f10\"},{\"isThumb\":0,\"img\":\"content\\/801b75aea3247894b61ec1ab952daefc.jpg\",\"thumb\":\"content\\/0.94301700-15544082837b93f9f6cf5f82768b9c5f28dabb354fw_450h_.jpg\",\"alt\":\"\",\"title\":\"img-variedadesautoctonas-macabeo2.jpg\",\"type\":\"image\",\"id\":\"8d01f61c30e3d39322d3f26242829c6a\"},{\"isThumb\":0,\"img\":\"content\\/5f48200a993340c5ef36dbf447c74880.jpg\",\"thumb\":\"content\\/0.46808500-15544082871e549f1f5521694e629216c19ec5be49w_450h_.jpg\",\"alt\":\"\",\"title\":\"img-variedadesautoctonas-parellada1.jpg\",\"type\":\"image\",\"id\":\"b2133d9b65a82cdbeeab2ad4b28de5c0\"},{\"isThumb\":0,\"img\":\"content\\/09601bfaa267a183669568446a848a0e.jpg\",\"thumb\":\"content\\/0.99007600-15544083021b4c366054f81ca4c93bc53b280572c7w_450h_.jpg\",\"alt\":\"\",\"title\":\"img-variedadesautoctonas-parellada2.jpg\",\"type\":\"image\",\"id\":\"77c6160cd20bac0e70b112223b0794d2\"},{\"isThumb\":0,\"img\":\"content\\/f0409808aa409627b04c7346278d0c0f.jpg\",\"thumb\":\"content\\/0.41685900-15544083153423a0b77a0e50dc060ca2a12c008945w_450h_.jpg\",\"alt\":\"\",\"title\":\"img-variedadesautoctonas-trepat1.jpg\",\"type\":\"image\",\"id\":\"f09b8589b6a83e3c81a12463253cb7fb\"},{\"isThumb\":0,\"img\":\"content\\/d27fac47b7c06f8f8ecb2f09eb7b23be.jpg\",\"thumb\":\"content\\/0.70063100-15544083285c84405b59ea47b2de65c5ae6cd147c7w_450h_.jpg\",\"alt\":\"\",\"title\":\"img-variedadesautoctonas-trepat2.jpg\",\"type\":\"image\",\"id\":\"2a568a6913f0c906dc9193d6ae6bb256\"},{\"isThumb\":0,\"img\":\"content\\/c44cb34f7c707f399586bff69bb7ccb8.jpg\",\"thumb\":\"content\\/0.46592800-155440834131137ead8ee8ea7997bb63ad1ad52f2cw_450h_.jpg\",\"alt\":\"\",\"title\":\"img-variedadesautoctonas-xarello1.jpg\",\"type\":\"image\",\"id\":\"51636cbded52e7679523cd98bff1e044\"},{\"isThumb\":0,\"img\":\"content\\/9096e92ec2f39a306afe5d73a9bf8651.jpg\",\"thumb\":\"content\\/0.69942200-15544083476871f2aa7f4488d5c2823f836edef183w_450h_.jpg\",\"alt\":\"\",\"title\":\"img-variedadesautoctonas-xarello2.jpg\",\"type\":\"image\",\"id\":\"2c4edaec1f517716cff400ebaf60c490\"}]'),
	(28,'pantall VITICULTURA ECOLÓGICA','[{\"isThumb\":0,\"img\":\"content\\/fdee56e0f2f1e3c9730b05b9ccfa909f.jpg\",\"thumb\":\"content\\/0.01734600-1554408158cbafa5926633bd5584b04606224f3095w_450h_.jpg\",\"alt\":\"\",\"title\":\"img_viticultores_controlamos_la_produccion3.jpg\",\"type\":\"image\",\"id\":\"520371ed23f05cdbe867e28e3799d810\"},{\"isThumb\":0,\"img\":\"content\\/e3d309c452f7d5c814e55de64899957b.jpg\",\"thumb\":\"content\\/0.21338900-155440818507d930becdd25cec513e6f3ff08c6c18w_450h_.jpg\",\"alt\":\"\",\"title\":\"img_viticultores_la_vendimia.jpg\",\"type\":\"image\",\"id\":\"2b64d547ba5e0be38a3bc989167ae513\"},{\"isThumb\":0,\"img\":\"content\\/10dfca36f2046bb2c9fd006f1aa422b0.jpg\",\"thumb\":\"content\\/0.37923600-1554408260851972d240030b3c8368e04bf736050dw_450h_.jpg\",\"alt\":\"\",\"title\":\"img_viticultores_recolectado_en_mano.jpg\",\"type\":\"image\",\"id\":\"ded6c880f6a95a50f755f1bef89f8d42\"}]'),
	(29,'pantall vinos crianza','[{\"isThumb\":0,\"img\":\"content\\/4bd28b2a80f3d3a9b09594241c885d55.jpg\",\"thumb\":\"content\\/0.70817700-15545711995e2b16a79bfeb650f5ed890cb29b8875w_450h_.jpg\",\"alt\":\"\",\"title\":\"img-crianza.jpg\",\"type\":\"image\",\"id\":\"e8e8abe566445910a9452340b7eb3710\"}]'),
	(30,'pantall vinos degulle','[{\"isThumb\":0,\"img\":\"content\\/1aea248d6440242f95024abaa72707f4.jpg\",\"thumb\":\"content\\/0.93423900-155457121272d1677cd42d4a524840f8d1950f5038w_450h_.jpg\",\"alt\":\"\",\"title\":\"img-garantiaycompromiso1.jpg\",\"type\":\"image\",\"id\":\"347cf58d02e2c9ffe7e35d3f070e336a\"}]'),
	(31,'pantall vinos','[{\"isThumb\":0,\"img\":\"content\\/c386bcb8f22b44efd5af860d20cb1c30.jpg\",\"thumb\":\"content\\/0.92303500-1554571225ba4675f2f8019c6c414bee82f2dad5e7w_450h_.jpg\",\"alt\":\"\",\"title\":\"img-prod-aptia-gran.jpg\",\"type\":\"image\",\"id\":\"353eb61f095698a9489c6226ebc716bd\"},{\"isThumb\":0,\"img\":\"content\\/2d9ab5577d3130057c89be5785d05fde.jpg\",\"thumb\":\"content\\/0.90977100-1554571227b141b67170eecccafc04b6ca7acb2a68w_450h_.jpg\",\"alt\":\"\",\"title\":\"img-prod-xic-gran.jpg\",\"type\":\"image\",\"id\":\"cce0843953f69911b8785af18af21f8b\"}]'),
	(32,'pantalla elaboracion de vinos','[{\"isThumb\":0,\"img\":\"content\\/9cafd648c8adcca529c15cf166532f5c.jpg\",\"thumb\":\"content\\/0.67483200-155497877478ade5bf67be089bbd59be37f3bc194fw_450h_.jpg\",\"alt\":\"\",\"title\":\"img-prensasyfermentacion1.jpg\",\"type\":\"image\",\"id\":\"742d76d3852f320c4764dd385ee3a27e\"}]');

/*!40000 ALTER TABLE `gallery` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla iva
# ------------------------------------------------------------

DROP TABLE IF EXISTS `iva`;

CREATE TABLE `iva` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `year` int(4) DEFAULT NULL,
  `iva` float DEFAULT NULL,
  `irpf` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `year` (`year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `iva` WRITE;
/*!40000 ALTER TABLE `iva` DISABLE KEYS */;

INSERT INTO `iva` (`id`, `year`, `iva`, `irpf`)
VALUES
	(1,2012,21,21),
	(2,2013,21,21),
	(3,2014,21,21),
	(4,2015,21,20),
	(5,2016,21,19),
	(6,2017,21,21),
	(7,2018,21,21),
	(8,2019,21,21);

/*!40000 ALTER TABLE `iva` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla lang
# ------------------------------------------------------------

DROP TABLE IF EXISTS `lang`;

CREATE TABLE `lang` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang_key` varchar(100) DEFAULT NULL,
  `lang_type` varchar(2) DEFAULT '',
  `lang_value` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lang_key` (`lang_key`,`lang_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `lang` WRITE;
/*!40000 ALTER TABLE `lang` DISABLE KEYS */;

INSERT INTO `lang` (`id`, `lang_key`, `lang_type`, `lang_value`)
VALUES
	(1,'error_db','es','Se ha producido un fallo al consultar base de datos'),
	(5,'error_db','en','Failed to query database.'),
	(9,'lang_es','es','Español'),
	(10,'lang_es','en','Spanish'),
	(11,'lang_en','es','Ingles'),
	(12,'lang_en','en','English'),
	(13,'lang_ca','es','Català'),
	(14,'lang_ca','en','Catalonian'),
	(17,'error_db','ca','S&#39;ha produït un error en consultar base de dades'),
	(29,'lang_es','ca','Castellano'),
	(32,'lang_en','ca','Ingles'),
	(35,'lang_ca','ca','Català'),
	(36,'mail_invitacion','es','Invitación'),
	(59,'mail_invitacion','en','Invitation'),
	(60,'mail_invitacion','ca','Invitació'),
	(61,'mail_regards','es','Un coordial saludo'),
	(62,'mail_regards','en','Regards.'),
	(63,'mail_regards','ca','Salutació coordial.'),
	(64,'mail_invitacion_html','es','<p>Nos gustaria enviarle una invitación</p><p>Al cual puede acceder entrando en siguiente link: %site_link%</p><p>También se le ha asignado un usuario y contraseña <i>(Exclusivo solo para usted.)</i>:</p><strong>Usuario:</strong> %user_name%<br/><strong>Contraseña:</strong> %user_pass%<br/><br/>'),
	(65,'mail_restablecerpass_html','es','<p>Hemos actualizado tu contraseña</p><p>Te recordamos tus datos de acceso:<br/><strong>Usuario: </strong>%user_name%<br/><strong>Contraseña:</strong> %user_pass%<p>Al cual puede acceder entrando en siguiente link: %site_link%</p><br/><br/>'),
	(66,'mail_restablecerpass','es','Recuperación de contraseña'),
	(67,'title_search_404','es','UPS! El link esta mal'),
	(68,'title_search_404','en','UPS! L&#39;enllaç d&#39;aquesta mal'),
	(69,'title_search_404','ca','UPS! The link is wrong'),
	(70,'text_search_404','es','Es posible que esta dirección URL este mal puesto, pero eso he buscado y he encontrado estas páginas:'),
	(72,'text_search_404','ca','És possible que aquesta direcció URL este mal posada, per això he buscat i he trobat aquestes pàgines:'),
	(73,'text_search_404','en','This URL is wrong, but that I have searched and found these pages:'),
	(74,'back_button','es','Volver'),
	(75,'back_button','en','Back'),
	(76,'back_button','ca','Tornar'),
	(77,'add_cart_but','es','añadir al carrito'),
	(78,'add_cart_but','ca','afegir a la cistella'),
	(79,'add_cart_but','en','add to cart'),
	(80,'title_info_evio','es','información de envío'),
	(81,'title_info_evio','ca','informació d&#39;enviament'),
	(82,'title_info_evio','en','shippment information'),
	(83,'title_shop','es','Tienda'),
	(84,'title_shop','ca','botiga'),
	(85,'title_shop','en','Shop'),
	(86,'no_price','es','precio no establecido'),
	(87,'no_price','ca','preu no establert'),
	(88,'no_price','en','Price not established'),
	(89,'no_stock','es','fuera de stock'),
	(90,'no_stock','ca','fora d&#39;estoc'),
	(91,'no_stock','en','out of stock'),
	(92,'tienda_no_items','es',''),
	(93,'tienda_no_items','ca','En aquet moment no li podem oferir venda dels nostres productes, disculpin les molèsties.'),
	(94,'tienda_no_items','en',''),
	(95,'lang_page_title_mi_cuenta','es','Mi cuenta'),
	(96,'lang_page_title_mi_cuenta','ca','El meu compte'),
	(97,'lang_page_title_mi_cuenta','en','My account'),
	(98,'login_new_user_title','es','Nuevo usuário'),
	(99,'login_registred_title','es','ya estás registrado?'),
	(100,'login_new_user_title','ca','nou usuari'),
	(101,'login_new_user_title','en','new user'),
	(102,'login_registred_title','ca','ja estàs registrat?'),
	(104,'login_registred_title','en','Already registered?'),
	(105,'label_new_user_email','es','Introduce tu correo electrónico para crear tu cuenta.'),
	(106,'label_new_user_email','ca','Introdueix el teu correu electrònic per crear el teu compte.'),
	(107,'label_new_user_email','en','Enter your email to create your account.'),
	(108,'new_user_but','es','crear cuenta'),
	(109,'new_user_but','ca','crear compte'),
	(110,'new_user_but','en','create account'),
	(111,'label_email','es','correo electrónico'),
	(112,'label_email','ca','correu electrònic'),
	(113,'label_email','en','Email'),
	(114,'label_pass','es','contraseña'),
	(115,'label_pass','ca','contrasenya'),
	(116,'label_pass','en','password'),
	(117,'login_init_session_but','es','iniciar sesión'),
	(118,'login_init_session_but','ca','iniciar sessió'),
	(119,'login_init_session_but','en','log in'),
	(120,'login_lost_pass_link','es','¿Has olvidado tu contraseña?'),
	(121,'login_lost_pass_link','ca','¿Ha oblidat la seva contrasenya?'),
	(123,'login_lost_pass_link','en','can you forgotten your password?'),
	(124,'form_empty_fields','es','Hay campos en blanco.'),
	(125,'form_empty_fields','ca','Hi ha camps en blanc.'),
	(126,'form_empty_fields','en','Check empty fields.'),
	(127,'pass_not_correct','es','Nombre o contraseña incorrecta.'),
	(128,'pass_not_correct','ca','Nom o contrasenya incorrecta.'),
	(129,'pass_not_correct','en','Wrong name or password.'),
	(130,'lang_page_title_recover_password','es','Recuperar contraseña'),
	(131,'lang_page_title_recover_password','ca','recuperar contrasenya'),
	(132,'lang_page_title_recover_password','en','Recover your password'),
	(133,'recover_pass_title','es','Recuperación de contraseña'),
	(134,'recover_pass_title','ca','Recuperació de contrasenya'),
	(135,'recover_pass_title','en','Recovering your password'),
	(136,'label_recover_user_email','es','Introduce tu correo electrónico para enviarte un formulario de recuperación'),
	(137,'label_recover_user_email','ca','Introduir el teu correu electrònic per enviar-te formulari de recuperació'),
	(138,'label_recover_user_email','en','Enter your email to send you a recovery form'),
	(139,'recovery_pass_but','es','enviar solicitud'),
	(140,'recovery_pass_but','en','send request'),
	(141,'recovery_pass_but','ca','enviar sol·licitud'),
	(142,'msg_new_mail_exist','es','Ya existe un usuario con este correo electrónico.'),
	(143,'msg_new_mail_exist','ca','Ja existeix un usuari amb aquest correu electrònic.'),
	(144,'msg_new_mail_exist','en','Already exists one client with this email.'),
	(145,'msg_no_data','es','Revise los campos obligatorios, hay algun campo vacío.'),
	(146,'msg_no_data','en','Check the required fields, there is some empty field.'),
	(147,'msg_no_data','ca','Revisi els camps obligatoris, hi ha algun camp buit.'),
	(148,'msg_email_not_valid','es','El correo electrónico no es válido.'),
	(149,'msg_email_not_valid','en','Email is not valid.'),
	(150,'msg_email_not_valid','ca','El correu electrònic no és vàlid.'),
	(151,'msg_new_client_mail_sended','es','Revise su correo electronico, le llegara la solicitud.'),
	(152,'msg_new_client_mail_sended','ca','Revisi el seu correu electrònic, li arribés la sol·licitud.'),
	(153,'msg_new_client_mail_sended','en','Check your email, your request will arrive.'),
	(154,'msg_account_activated','es','Su cuenta esta activada correctamente.'),
	(156,'msg_account_activated','ca','El seu compte està activada correctament.'),
	(157,'msg_account_activated','en','Your account is successfully activated.'),
	(158,'msg_account_activate_error','es','Su clave de activación no es correcta.'),
	(159,'msg_account_activate_error','ca','La seva clau d&#39;activació no és correcta.'),
	(160,'msg_account_activate_error','en','Your activation key is not correct.'),
	(161,'msg_new_client_create_error','es','Ahora mismo no he podido crear un usuario nuevo, intentelo en unos momentos.'),
	(162,'msg_new_client_create_error','ca','Ara mateix no he pogut crear un usuari nou, intenteu en uns moments.'),
	(163,'msg_new_client_create_error','en','Right now I could not create a new user, try it in a few moments.'),
	(164,'mail_subject_new_client','es','Acceso y activación de su cuenta.'),
	(165,'mail_subject_new_client','en','Access and activation of your account.'),
	(166,'mail_subject_new_client','ca','Accés i activació del seu compte.'),
	(167,'mail_new_client_html','es','<p>Hola estimado cliente, nos gustaria darles la bienvenida.</p><p>Hemos creado un link de activación: %site_link%</p><p>También se le ha asignado un usuario y contraseña <i>(Exclusivo solo para usted.)</i>:</p><strong>Usuario:</strong> %user_name%<br/><strong>Contraseña:</strong> %user_pass%<br/><br/>'),
	(168,'mail_new_client_html','ca','<p>Hola estimat client, ens agradaria donar-los la benvinguda.</p><p>Hem creat un link d&#39;activació: %site_link% </p> <p>També se li ha assignat un usuari i contrasenya <i>( exclusiu només per a vostè.)</i>: </p><strong>Usuari: </strong>%user_name% <br/><strong>Contrasenya:< strong>%user_pass%<br/><br/>'),
	(169,'mail_new_client_html','en','<p>Hello dear customer, we would like to welcome you.</p><p>We have created an activation link: %site_link%</p><p>You have also been assigned a username and password <i> ( Exclusive for you only.) </p> <strong> User: </strong>%user_name% <br/> <strong>Password: %user_pass% </strong><br/> <br/>'),
	(170,'msg_rec_mail_noexist','es','Usuario con este correo electrónico no existe.'),
	(171,'msg_rec_mail_noexist','en','User with this email does not exist.'),
	(172,'msg_rec_mail_noexist','ca','Usuari amb aquest correu electrònic no existeix.'),
	(173,'msg_recovery_pass_send_error','es','Por razones tecnicas no he podido enviar la solicitud, intentelo en unos momentos.'),
	(174,'msg_recovery_pass_send_error','ca','Per raons tècniques no he pogut enviar la sol·licitud, intenteu en uns moments.'),
	(175,'msg_recovery_pass_send_error','en','For technical reasons I could not send the request, try it in a few moments.'),
	(176,'mail_subject_recover_pass','es','Solicitud de recuperación de contraseña'),
	(177,'mail_subject_recover_pass','en','Request for password recovery'),
	(178,'mail_subject_recover_pass','ca','Sol·licitud de recuperació de contrasenya'),
	(179,'mail_recover_pass_html','es','<p>Hola estimado cliente, hemos recibido la solicitud para recuperación de su contraseña.</p><p>Hemos creado un link de activación: %site_link%</p><p>También se le ha asignado una nueva contraseña <i>(Exclusivo solo para usted.)</i>:</p><strong>Usuario:</strong> %user_name%<br/><strong>Contraseña:</strong> %user_pass%<br/><br/>'),
	(180,'mail_recover_pass_html','ca','<p>Hola estimat client, hem rebut la sol·licitud per a recuperació de la contrasenya.</p><p>Hem creat un link d&#39;activació: %site_link% </p> <p>També se li ha assignat una nova contrasenya <i>( exclusiu només per a vostè.)</i>: </p><strong>Usuari: </strong>%user_name% <br/><strong>Contrasenya:< strong>%user_pass%<br/><br/>'),
	(181,'mail_recover_pass_html','en','<p>Hello dear client, we have received the request for recovery of your password.</p><p>We have created an activation link: %site_link%</p><p>You have also been assigned new password <i> ( Exclusive for you only.) </p> <strong> User: </strong>%user_name% <br/> <strong>Password: %user_pass% </strong><br/> <br/>'),
	(182,'micuenta_datospers_title','es','Mis datos personales'),
	(183,'micuenta_welcome','es','¡Bienvenido a tu cuenta! Aquí podrás gestionar todos tus pedidos e información personal.'),
	(184,'micuenta_welcome','ca','Benvingut al teu compte! Aquí podràs gestionar totes les teves comandes i informació personal.'),
	(185,'micuenta_welcome','en','Welcome to your account! Here you can manage all your orders and personal information.'),
	(186,'micuenta_datospers_title','en','My personal information'),
	(188,'micuenta_datospers_title','ca','Les meves dades personals'),
	(189,'micuenta_direcciones_title','es','Mi dirección principal'),
	(190,'micuenta_direcciones_title','ca','La meava adreça'),
	(191,'micuenta_direcciones_title','en','My default address'),
	(192,'micuenta_no_direcciones_msg','es','No tiene ninguna dirección guardada'),
	(193,'micuenta_no_direcciones_msg','en','And there are none saved direction'),
	(194,'micuenta_no_direcciones_msg','ca','No hi te cap direcció guardada'),
	(195,'no_level_msg','es','No puede hacer esto, no tiene autorización!'),
	(196,'no_level_msg','ca','No pot Fer això, no hi té autorització!'),
	(197,'no_level_msg','en','Can not do that, you are not authorized!'),
	(198,'msg_client_persdata_updated','es','Sus datos se han actualizado correctamente'),
	(199,'msg_client_persdata_updated','en','Your personal data are updated succesfully'),
	(200,'msg_client_persdata_updated','ca','Les seves dades s&#39;han actualitzat correctament'),
	(201,'msg_client_persdata_no_updated','es','Sus datos no se han actualizado :('),
	(202,'msg_client_persdata_no_updated','en','Your personal data are not updated'),
	(203,'msg_client_persdata_no_updated','ca','Les seves dades no s&#39;han actualitzat :('),
	(204,'lang_label_dir','es','Dirección'),
	(205,'lang_label_city','es','Ciudad'),
	(206,'lang_label_region','es','Region'),
	(207,'lang_label_post','es','Código postal'),
	(208,'lang_label_country','es','País'),
	(209,'add_one_but','es','Añadir una'),
	(210,'form_save_but','es','Guardar'),
	(211,'form_tel','es','Teléfono'),
	(212,'form_cif','es','Cif, Dni, Nie (Facturación)'),
	(213,'form_surname','es','Apellidos'),
	(214,'form_name','es','Nombre'),
	(215,'label_client_id','es','Id del cliente'),
	(216,'menu_but_mis_pedidos','es','HISTORIAL DE PEDIDOS Y DETALLES'),
	(217,'menu_but_mis_devoluciones','es','MIS DEVOLUCIONES'),
	(218,'menu_but_misdirecciones','es','MIS DIRECCIONES'),
	(219,'menu_but_misdatos','es','MIS DATOS PERSONALES'),
	(220,'menu_but_logout','es','CERRAR SESIÓN'),
	(221,'menu_but_login','es','Iniciar sesion'),
	(222,'menu_but_register','es','Registrarse'),
	(223,'menu_but_enviodevoluciones','es','ENVÍOS Y DEVOLUCIONES'),
	(224,'menu_but_terycond','es','TÉRMINOS Y CONDICIONES'),
	(225,'menu_but_poryprivcookies','es','POLITICA DE PRIVACIDAD Y COOKIES'),
	(226,'menu_but_sobrenosotros','es','SOBRE NOSOTROS'),
	(227,'menu_but_contacto','es','contacto'),
	(228,'footer_text','es','Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500. Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500'),
	(229,'msg_no_hay_pedidos','es','No has realizado ningún pedido'),
	(230,'but_ir_a_la_tienda','es','Ir a la tienda'),
	(231,'lang_page_title_mis_devoluciones','es','Mis devoluciones'),
	(232,'lang_page_title_mis_pedidos','es','mis pedidos'),
	(233,'lang_page_title_mis_direcciones','es','mis direcciones'),
	(234,'msg_no_hay_devoluciones','es','no has realizado ningúna devolución'),
	(235,'misdirecciones_title','es','Mis direcciónes'),
	(238,'misdirecciones_asegurate_mod','es','Asegúrate de actualizar tu información personal si cambia'),
	(239,'form_update_but','es','Actualizar'),
	(240,'form_del_but','es','Borrar'),
	(241,'form_set_default_but','es','Establecer principal'),
	(242,'form_misdirecciones_name','es','Nombre rápido'),
	(243,'lang_page_title_checkout','es','Checkout'),
	(244,'cart_empty','es','Su carrito esta vacío.'),
	(245,'add_item_cart','es','Producto añadido al carrito'),
	(246,'cart_generado','es','Carrito generado'),
	(247,'cart_error_generar','es','No se ha podido generar el carrito, por favor intentelo en unos momentos.'),
	(248,'add_item_cart_error','es','No he podido añadir el producto al carrito.'),
	(249,'msg_cart_no_hay_compras','es','No ha realizado ninguna compra.'),
	(250,'lang_iva','es','IVA'),
	(251,'lang_iva','ca','IVA'),
	(252,'lang_iva','en','VAT'),
	(253,'lang_no_iva','es','No hay iva'),
	(254,'lang_page_title_cart','es','Carrito'),
	(255,'cart_but','es','Carrito'),
	(256,'cart_checkout_but','es','Finalizar la compra'),
	(257,'lang_cart_producto_title','es','producto'),
	(258,'lang_cart_cantidad_title','es','cantidad'),
	(259,'lang_envio','es','Envío'),
	(260,'title_lookbook','es','lookbook'),
	(261,'msg_home_welcome','es','Bienvenido'),
	(262,'msg_no_logged','es','Ya estas registrado? Aqui puedes registrarte o iniciar secion.'),
	(263,'checkout_title_adress_book','es','dirección de facturación'),
	(264,'msg_checkout_nodir','es','Por el momento no tiene ninguna dirección guardada es necesario que añada una.'),
	(265,'checkout_pago_title','es','forma de pago'),
	(266,'checkout_pedido_title','es','pedido'),
	(267,'checkout_agree_checkbox','es','acepto los términos y condiciones (+info)'),
	(268,'checkout_finalizar_but','es','finalizar compra'),
	(297,'mail_invitacion_html','en','<p>We would like to send you an invitation</p><p>You can access it by entering the following link:%site_link% </p><p>You have also been assigned a user and password <i>(Exclusive only for You.)</p><strong>User: </strong>%user_name% <br/><strong>Password: </strong>%user_pass%<br/><br/>'),
	(298,'mail_invitacion_html','ca','<p>Ens agradaria enviar-li una invitació</p><p>A l’quina por accedir-hi entrant en següent enllaç:%site_link%</p><p>També se li ha assignat un usuari i contrasenya <i>(Exclusiu només per vostè)</i>: </p> <strong>Usuari: </strong>%user_name%<br/><strong> Contrasenya: </strong>%user_pass%<br/>'),
	(300,'mail_restablecerpass_html','en','<p>We have updated your password</p><p>We remind you of your login information:<br/><strong> User: </strong>%user_name%<br/><strong> Password: </strong> %user_pass% <p>You can access it by going to the following link:%site_link%</p><br/><br/>'),
	(301,'mail_restablecerpass_html','ca','<p>Hem actualitzat la contrasenya</p><p>Et recordem les teves dades d&#39;accés: <br/><strong> Usuari: </strong>%user_name%<br/><strong> Contrasenya: </strong> %user_pass% <p><br/>En seguent link (%site_link%) hi pot accedir-hi.</p><br/><br/>'),
	(303,'mail_restablecerpass','en','Recuperació de contrasenya'),
	(304,'mail_restablecerpass','ca','Password recovery'),
	(438,'lang_label_dir','en','Address'),
	(439,'lang_label_dir','ca','direcció'),
	(441,'lang_label_city','en','city'),
	(442,'lang_label_city','ca','ciutat'),
	(444,'lang_label_region','en','Region'),
	(445,'lang_label_region','ca','Region'),
	(447,'lang_label_post','en','Postal Code'),
	(448,'lang_label_post','ca','codi postal'),
	(450,'lang_label_country','en','country'),
	(451,'lang_label_country','ca','país'),
	(453,'add_one_but','en','Add one'),
	(454,'add_one_but','ca','afegir una'),
	(456,'form_save_but','en','save'),
	(457,'form_save_but','ca','Guardar'),
	(459,'form_tel','en','telephone'),
	(460,'form_tel','ca','telèfon'),
	(462,'form_cif','en','ID Doc. (Billing)'),
	(463,'form_cif','ca','Cif, Dni, Nie (facturació)'),
	(465,'form_surname','en','Surnames'),
	(466,'form_surname','ca','Cognoms'),
	(468,'form_name','en','Name'),
	(469,'form_name','ca','Nom'),
	(471,'label_client_id','en','Client ID'),
	(472,'label_client_id','ca','Aneu del client'),
	(474,'menu_but_mis_pedidos','en','ORDER HISTORY AND DETAILS'),
	(475,'menu_but_mis_pedidos','ca','HISTORIAL DE COMANDES I DETALLS'),
	(477,'menu_but_mis_devoluciones','en','MY RETURNS'),
	(478,'menu_but_mis_devoluciones','ca','MIS DEVOLUCIONS'),
	(480,'menu_but_misdirecciones','en','MY ADDRESSES'),
	(481,'menu_but_misdirecciones','ca','LES MEVES ADRECES'),
	(483,'menu_but_misdatos','en','MY PERSONAL INFORMATION'),
	(484,'menu_but_misdatos','ca','Detalls sobre mi'),
	(486,'menu_but_logout','en','LOG OUT'),
	(487,'menu_but_logout','ca','TANCAR SESSIÓ'),
	(489,'menu_but_login','en','LOG IN'),
	(490,'menu_but_login','ca','Inicia sessió'),
	(492,'menu_but_register','en','Register'),
	(493,'menu_but_register','ca','Registrar'),
	(495,'menu_but_enviodevoluciones','en','SHIPPING & RETURNS'),
	(496,'menu_but_enviodevoluciones','ca','ENVIAMENTS I DEVOLUCIONS'),
	(498,'menu_but_terycond','en','TERMS AND CONDITIONS'),
	(499,'menu_but_terycond','ca','TERMES I CONDICIONS'),
	(501,'menu_but_poryprivcookies','en','PRIVACY POLICY AND COOKIES'),
	(502,'menu_but_poryprivcookies','ca','POLÍTICA DE PRIVACITAT I COOKIES'),
	(504,'menu_but_sobrenosotros','en','ABOUT US'),
	(505,'menu_but_sobrenosotros','ca','SOBRE NOSALTRES'),
	(507,'menu_but_contacto','en','contact'),
	(508,'menu_but_contacto','ca','contact'),
	(510,'footer_text','en','Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500. Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500'),
	(511,'footer_text','ca','Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500. Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500'),
	(513,'msg_no_hay_pedidos','en','You have not placed any orders'),
	(514,'msg_no_hay_pedidos','ca','No has realitzat cap comanda'),
	(516,'but_ir_a_la_tienda','en','Go to the store'),
	(517,'but_ir_a_la_tienda','ca','Anar a la botiga'),
	(519,'lang_page_title_mis_devoluciones','en','My returns'),
	(520,'lang_page_title_mis_devoluciones','ca','Els meus devolucions'),
	(522,'lang_page_title_mis_pedidos','en','my orders'),
	(523,'lang_page_title_mis_pedidos','ca','les meves comandes'),
	(525,'lang_page_title_mis_direcciones','en','MY ADDRESSES'),
	(526,'lang_page_title_mis_direcciones','ca','LES MEVES ADRECES'),
	(528,'msg_no_hay_devoluciones','en','You have not made any returns'),
	(529,'msg_no_hay_devoluciones','ca','no has realitzat cap devolució'),
	(531,'misdirecciones_title','en','MY ADDRESSES'),
	(532,'misdirecciones_title','ca','LES MEVES ADRECES'),
	(534,'misdirecciones_asegurate_mod','en','Be sure to update your personal information if you change'),
	(535,'misdirecciones_asegurate_mod','ca','Assegura&#39;t d&#39;actualitzar la teva informació personal si canvia'),
	(537,'form_update_but','en','Update'),
	(538,'form_update_but','ca','actualitzar'),
	(540,'form_del_but','en','Delete'),
	(541,'form_del_but','ca','esborrar'),
	(543,'form_set_default_but','en','Set Main'),
	(544,'form_set_default_but','ca','establir principal'),
	(546,'form_misdirecciones_name','en','Quick name'),
	(547,'form_misdirecciones_name','ca','nom ràpid'),
	(549,'lang_page_title_checkout','en','Checkout'),
	(550,'lang_page_title_checkout','ca','Checkout'),
	(552,'cart_empty','en','Your cart is empty.'),
	(553,'cart_empty','ca','La seva cistella està buida.'),
	(555,'add_item_cart','en','Product added to cart'),
	(556,'add_item_cart','ca','Producte afegit a la cistella'),
	(558,'cart_generado','en','Cart generated'),
	(559,'cart_generado','ca','Cistella generat'),
	(561,'cart_error_generar','en','The cart could not be generated, please try it in a few moments.'),
	(562,'cart_error_generar','ca','No s&#39;ha pogut generar el carret, si us plau intenteu en uns moments.'),
	(564,'add_item_cart_error','en','I could not add the product to the cart.'),
	(565,'add_item_cart_error','ca','No he pogut afegir el producte a la cistella.'),
	(567,'msg_cart_no_hay_compras','en','You have not made any purchases.'),
	(568,'msg_cart_no_hay_compras','ca','No ha realitzat cap compra.'),
	(573,'lang_no_iva','en','There is no VAT'),
	(574,'lang_no_iva','ca','No hi ha iva'),
	(576,'lang_page_title_cart','en','Cart'),
	(577,'lang_page_title_cart','ca','Cistella'),
	(579,'cart_but','en','Cart'),
	(580,'cart_but','ca','Cistella'),
	(582,'cart_checkout_but','en','Finish the purchase'),
	(583,'cart_checkout_but','ca','Finalitzar la compra'),
	(585,'lang_cart_producto_title','en','product'),
	(586,'lang_cart_producto_title','ca','producte'),
	(588,'lang_cart_cantidad_title','en','quantity'),
	(589,'lang_cart_cantidad_title','ca','quantitat'),
	(591,'lang_envio','en','Shipping'),
	(592,'lang_envio','ca','enviament'),
	(594,'title_lookbook','en','lookbook'),
	(595,'title_lookbook','ca','lookbook'),
	(597,'msg_home_welcome','en','Welcome'),
	(598,'msg_home_welcome','ca','Benvingut'),
	(600,'msg_no_logged','en','Already registered? Here you can register or start section.'),
	(601,'msg_no_logged','ca','Ja estàs registrat? Aqui pots registrar-te o iniciar secio.'),
	(603,'checkout_title_adress_book','en','Billing Address'),
	(604,'checkout_title_adress_book','ca','adreça de facturació'),
	(606,'msg_checkout_nodir','en','At the moment you do not have any saved addresses you need to add one.'),
	(607,'msg_checkout_nodir','ca','De moment no té cap adreça guardada cal que afegeixi un.'),
	(609,'checkout_pago_title','en','way to pay'),
	(610,'checkout_pago_title','ca','forma de pagament'),
	(612,'checkout_pedido_title','en','order'),
	(613,'checkout_pedido_title','ca','demanat'),
	(615,'checkout_agree_checkbox','en','I accept the terms and conditions (+ info)'),
	(616,'checkout_agree_checkbox','ca','accepto els termes i condicions (+ info)'),
	(618,'checkout_finalizar_but','en','Checkout'),
	(619,'checkout_finalizar_but','ca','finalitzar compra'),
	(620,'msg_no_shipping_companies','es','En estos momentos no realizamos envíos. Disculpen las molestias.'),
	(621,'msg_no_shipping_companies','en','We do not ship at this time. We apologize for the inconvenience.'),
	(622,'msg_no_shipping_companies','ca','En aquests moments no realitzem enviaments. Disculpin les molèsties.'),
	(623,'title_select_shipping_comp','es','Seleccionar compañía de envío'),
	(624,'title_select_shipping_comp','ca','Seleccionar companyia d\'enviament'),
	(625,'title_select_shipping_comp','en','Select shipping company'),
	(626,'form_num_visa','es','número de tarjeta'),
	(627,'form_num_visa','ca','número de targeta'),
	(628,'form_num_visa','en','Card number'),
	(629,'form_card_expire','es','fecha de caducidad'),
	(630,'form_card_expire','en','Date of Expiry'),
	(631,'form_card_expire','ca','data de caducitat'),
	(632,'form_month','es','mes'),
	(633,'form_month','ca','mes'),
	(634,'form_month','en','month'),
	(635,'form_year','es','año'),
	(636,'form_year','ca','any'),
	(637,'form_year','en','year'),
	(638,'form_card_ccv','es','código de seguridad (CCV)'),
	(639,'form_card_ccv','ca','codi de seguretat (CCV)'),
	(641,'form_card_ccv','en','Security code (CCV)'),
	(736,'MSG0000','es','El sistema está ocupado, inténtelo más tarde'),
	(737,'MSG0001','es','Número de pedido repetido'),
	(738,'MSG0002','es','El Bin de la tarjeta no está dado de alta en FINANET'),
	(739,'MSG0003','es','El sistema está arrancando, inténtelo en unos momentos'),
	(740,'MSG0004','es','Error de Autenticación'),
	(741,'MSG0005','es','No existe método de pago válido para su tarjeta'),
	(742,'MSG0006','es','Tarjeta ajena al servicio'),
	(743,'MSG0007','es','Faltan datos, por favor compruebe que su navegador acepta cookies'),
	(744,'MSG0008','es','Error en datos enviados. Contacte con su comercio.'),
	(745,'MSG0000','ca','El sistema està ocupat, intenti-ho més tard'),
	(746,'MSG0000','en','The system is busy, intenti-ho later'),
	(747,'MSG0001','en','Reorder number'),
	(748,'MSG0001','ca','Número de comanda repetit'),
	(749,'MSG0002','ca','El Bin de la targeta no està donat d\'alta a Finanet'),
	(750,'MSG0002','en','The Bin of the card is not registered in FINANET'),
	(752,'MSG0004','en','Authentication Error'),
	(753,'MSG0004','ca','Error d\'autenticació'),
	(754,'MSG0005','en','There is no valid payment method for your card'),
	(756,'MSG0005','ca','No hi ha mètode de pagament vàlid per a la targeta'),
	(757,'MSG0006','ca','Targeta aliena al servei'),
	(758,'MSG0006','en','Non-service card'),
	(759,'MSG0007','ca','Falten dades, si us plau comprovi que el seu navegador accepta cookies'),
	(760,'MSG0007','en','Missing data, please check that your browser accepts cookies'),
	(761,'MSG0008','en','Error in sent data. Contact your dealer.'),
	(762,'MSG0008','ca','Error en dades enviades. Contacti amb el seu comerç.'),
	(763,'checkout_success','es','La compra se ha realizado correctamente.'),
	(764,'checkout_success','ca','La compra s\'ha realitzat correctament.'),
	(765,'checkout_success','en','The purchase was successful.'),
	(766,'order_pagado','es','Pagado'),
	(767,'order_pagado','en','Paid'),
	(768,'order_pagado','ca','Pagat'),
	(769,'order_no_pagado','es','Falta por pagar'),
	(770,'order_no_pagado','en','Pending to pay'),
	(771,'order_no_pagado','ca','Falta per pagar'),
	(772,'order_entregado','es','Entregado'),
	(773,'order_entregado','ca','Entregat'),
	(774,'order_entregado','en','Delivered'),
	(775,'order_no_entregado','es','En camino'),
	(776,'order_no_entregado','ca','En camí'),
	(777,'order_no_entregado','en','Pendig delivery'),
	(778,'order_date','es','Fecha'),
	(779,'order_date','en','Date'),
	(781,'order_date','ca','Data'),
	(782,'order_pago','es','Pago'),
	(783,'order_pago','ca','Pagament'),
	(784,'order_pago','en','Payment'),
	(785,'order_estado','es','Estado'),
	(786,'order_estado','ca','Estat'),
	(787,'order_estado','en','Status'),
	(788,'order_tracking_num','es','Número de seguimiento'),
	(790,'order_tracking_num','ca','Número de seguiment'),
	(791,'order_tracking_num','en','Tracking number'),
	(792,'order_no_tracking_no','es','No asignado'),
	(793,'order_no_tracking_no','ca','No assignat'),
	(794,'order_no_tracking_no','en','Not assigned'),
	(795,'order_show_details','es','Ver detalles'),
	(796,'order_show_details','ca','Veure comanda'),
	(797,'order_show_details','en','Order details'),
	(798,'order_actions','es','Acciones'),
	(799,'order_actions','ca','Accions'),
	(800,'order_actions','en','Actions'),
	(801,'email_novalid','es','Email no válido'),
	(802,'email_novalid','ca','E-mail no vàlid'),
	(803,'email_novalid','en','Invalid Email'),
	(804,'regards','es','Saludos'),
	(805,'regards','ca','Salutacions'),
	(806,'regards','en','Regards'),
	(807,'contact_form_confirm','es','El mensaje se ha enviado correctamente'),
	(808,'contact_form_confirm','ca','El missatge s\'ha enviat correctament'),
	(809,'contact_form_confirm','en','The message has been sent successfully'),
	(810,'contact_form_error','es','Se produjo un error al enviar el mensaje, intentelo mas tarde.'),
	(811,'contact_form_error','ca','S\'ha produït un error en enviar el missatge, intenteu més tard.'),
	(812,'contact_form_error','en','There was an error sending the message, please try again later.'),
	(813,'form_but_send','es','Enviar'),
	(814,'form_but_send','ca','Enviar'),
	(815,'form_but_send','en','Send'),
	(816,'form_message','es','Mensaje'),
	(817,'form_message','ca','Missatge'),
	(818,'form_message','en','Message'),
	(819,'lang_page_title_historial','es','Historial de pedidos'),
	(820,'lang_page_title_historial','ca','Historial de comandes'),
	(821,'lang_page_title_historial','en','Orders history'),
	(822,'mail_order_confirm','es','Confirmación de pedido'),
	(823,'mail_order_confirm','ca','Confirmació de comanda'),
	(825,'mail_order_confirm','en','Order confirmation'),
	(826,'mail_order_confirm_text','es','<p>Estimado cliente:</p><p>Le comunicamos que hemos recibido su pedido y ha quedado registrada en nuestro sistema con siguiente número de referencia <strong>%ref_number%</strong>.</p><br/><br/>'),
	(827,'mail_order_confirm_text','ca','<p>Estimat client:</p>\n<p>Li comuniquem que hem rebut la seva comanda i ha quedat registrada en el nostre sistema amb següent número de referència <strong>%ref_number%</strong>.</p>\n<br/>\n<br/>'),
	(828,'mail_order_confirm_text','en','<p>Dear Customer:</p>\n<p>We inform you that we have received your order and it has been registered in our system with the following reference number <strong>%ref_number%</strong>.</p>\n<br/>\n<br/>'),
	(829,'form_motivo','es','Motivo'),
	(830,'form_motivo','ca','Motiu'),
	(831,'form_motivo','en','Reason'),
	(832,'form_order_id','es','Número del pedido'),
	(833,'form_order_id','en','Order id'),
	(834,'form_order_id','ca','Número de la comanda'),
	(835,'mail_subject_reclamacion','es','Reclamación'),
	(836,'mail_subject_reclamacion','ca','Reclamació'),
	(837,'mail_subject_reclamacion','en','Claim'),
	(838,'mail_message_reclamacion','es','El Cliente con id: <strong>%ID%</strong> ha iniciado una reclamación por el siguiente motivo: <strong>%MOTIVO%</strong><br/><br/><strong>Mensaje:</strong><br/>'),
	(839,'mail_message_reclamacion','ca','El Client amb id: <strong>%ID%</strong> ha iniciat una reclamació pel següent motiu: <strong>%MOTIVO%</strong><br/><br/><strong> Missatge:</strong><br/>'),
	(840,'mail_message_reclamacion','en','The Client with id: <strong>%ID%</strong> has initiated a claim for the next reason:<strong>%REASON%</strong><br/><br/><strong>Message:</strong><br/>'),
	(841,'micuenta_firststeps','es','Antes de realizar la campra se recomienda rellenar los campos con sus datos personales, posteriormente crear una dirección donde se va envíar.'),
	(842,'micuenta_shipponlyspain','es','Por el momento el envío solo se realizara en el territorio Español.'),
	(843,'cart_shipping_included','es','Incluido en el precio'),
	(844,'cart_shipping_included','ca','Inclòs en el preu'),
	(845,'cart_shipping_included','en','Included in the price'),
	(846,'country_list_error','es','La lista no se ha cargado bien'),
	(847,'country_list_error','ca','La llista no s\'ha carregat bé'),
	(848,'country_list_error','en','The list has not been loaded properly'),
	(849,'creditcard','en','Credit Card'),
	(850,'creditcard','es','Tarjeta de crédito'),
	(851,'creditcard','ca','Targeta de crédit'),
	(852,'no_payment_actived_message','es','<p>Ahora mismo no se puede comprar, estamos estudiando nuevas propuestas de pago.</p>'),
	(853,'no_payment_actived_message','ca','<p>Ara mateix no es pot comprar, estem estudiant noves propostes de pagament.</p>'),
	(854,'no_payment_actived_message','en','<p>You can not buy it right now, we are looking at new payment proposals.</p>'),
	(855,'pordefecto','es','Por defecto'),
	(856,'pordefecto','ca','Per defecte'),
	(857,'pordefecto','en','Default'),
	(858,'lang_page_title_pago_error','es','La transacción ha fallado'),
	(859,'lang_page_title_pago_error','ca','La transacció ha fallat'),
	(860,'lang_page_title_pago_error','en','Transaction failed'),
	(861,'lang_error_stage_leadtext','es','Error 404 - Oh no! Link roto'),
	(862,'lang_error_stage_leadtext','ca','Error 404 - Oh no! Link roto'),
	(863,'lang_error_stage_leadtext','en','Error 404 - Oh no! Link is broken'),
	(864,'back_to_home_but','es','Quiero ir a la página principal'),
	(865,'back_to_home_but','ca','Vull anar a la pàgina principal'),
	(866,'back_to_home_but','en','I want to go to the main page'),
	(867,'lang_error_stage_text','es','<p>Puede ser que el link este mal puesto, o simplemente oculto.</p>'),
	(868,'lang_error_stage_text','ca','<p>Pot ser que el link aquest mal lloc, o simplement ocult.</p>'),
	(869,'lang_error_stage_text','en','<p>It may be that the link is misplaced, or simply hidden.</p>'),
	(870,'lang_pago_error_text','es','<p>La operación de transacción ha fallado.<br/>Pruebe realizar el pago de nuevo.</p>'),
	(871,'lang_pago_error_text','ca','<p>L\'operació de transacció ha fallat.<br/>Proveu realitzar el pagament de nou.</p>'),
	(872,'lang_pago_error_text','en','<p>The transaction operation failed.<br/>Try to make the payment again.</p>'),
	(873,'lang_pago_completado_text','es','<p>Su transacción ha sido completada.<br/>En breve recibira el resumen de la compra.<br/>Muchisimas gracias.</p>'),
	(874,'lang_pago_completado_text','ca','<p>El seu transacció ha estat completada.<br/>En breu rebrà el resum de la compra.<br/>Moltíssimes gràcies.</p>'),
	(875,'lang_pago_completado_text','en','<p>Your transaction has been completed.<br/>You will shortly receive the purchase summary.<br/>Thank you very much.</p>'),
	(876,'varios_items','es','Varios productos'),
	(877,'varios_items','ca','Varis productes'),
	(878,'varios_items','en','Various products'),
	(879,'redirection','es','Redireccionando...'),
	(880,'redirection','ca','Redireccionant...'),
	(881,'redirection','en','Redirecting...'),
	(882,'payment_no_redirect','es','No puedo crear petición de pago. Problema al crear o autenticar usuario.'),
	(883,'payment_no_redirect','ca','No puc crear petició de pagament. Problema en crear o autenticar usuari.'),
	(884,'payment_no_redirect','en','I can not create payment request. Problem creating or authenticating user.'),
	(885,'lang_cart_promote_code','es','Código de promoción'),
	(886,'cart_item_apply_promocode','es','Descuento aplicado sobre un producto de'),
	(887,'cart_descuento','es','Descuento'),
	(888,'no_post_content','es','No hay contenido por el momento'),
	(889,'lang_readmore','es','Seguir leyendo'),
	(890,'menu_but_blog','es','Blog'),
	(891,'lang_newsletter_title_success','es','Mensaje enviado con éxito'),
	(892,'lang_newsletter_msg_success','es','Muchas gracias!'),
	(893,'lang_newsletter_msg_fail','es','Ya se han agotado los cupones de descuento.'),
	(894,'mail_subject_oferta','es','Cupón de descuento'),
	(895,'mail_discount_html','es','<div style=\"text-align:center;\"><p>¡Gracias por contactar con nosotros!</p>\n<p>Por favor introduce el siguiente código en la casilla código de promoción para obtener un descuento del <strong>%percent%%</strong> al hacer la compra.</p>\n<p>%desc%</p>\n<p><strong>CÓDIGO:</strong> <span style=\"color:#ff0000\">%cupon%</span></p></div>'),
	(896,'lang_newsletter_msg_fail_send','es','Por algún motivo no he podido enviar el código de descuento'),
	(897,'header_lang','es','idioma'),
	(898,'header_lang','en','lang.'),
	(899,'header_lang','ca','idioma'),
	(900,'msg_error_param','es','Error en el parámetro.'),
	(901,'msg_error_param','ca','Error en el paràmetre.'),
	(902,'msg_error_param','en','Error in the parameter.'),
	(905,'lang_color','es','Color'),
	(906,'lang_color','en','Color'),
	(907,'lang_color','ca','Color'),
	(908,'lang_size','es','Tamaño'),
	(909,'lang_size','en','Size'),
	(910,'lang_size','ca','Mida'),
	(911,'lang_select','es','Seleccionar'),
	(912,'lang_select','en','Select one'),
	(913,'lang_select','ca','Seleccionar'),
	(914,'menu_but_socialmedia','es','Social Media'),
	(915,'menu_but_socialmedia','en','Social Media'),
	(916,'lang_copy','es','Todos los derechos reservados.'),
	(917,'lang_copy','en','All rights reserved'),
	(918,'lang_copy','ca','Tots els drets reservats');

/*!40000 ALTER TABLE `lang` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla menus
# ------------------------------------------------------------

DROP TABLE IF EXISTS `menus`;

CREATE TABLE `menus` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `m_type` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `active` int(1) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `update_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `create_date` datetime DEFAULT NULL,
  `lang` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;

INSERT INTO `menus` (`id`, `m_type`, `title`, `active`, `order`, `update_date`, `create_date`, `lang`)
VALUES
	(1,1,'Header',1,0,'2018-01-13 18:58:46','2018-01-09 15:32:06','es'),
	(2,3,'Footer - condiciones',1,0,'2018-01-13 18:58:53','2018-01-09 15:33:34','es');

/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla menus_meta
# ------------------------------------------------------------

DROP TABLE IF EXISTS `menus_meta`;

CREATE TABLE `menus_meta` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `m_id` int(11) DEFAULT NULL,
  `m_key` varchar(255) DEFAULT NULL,
  `m_value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Volcado de tabla menus_structure
# ------------------------------------------------------------

DROP TABLE IF EXISTS `menus_structure`;

CREATE TABLE `menus_structure` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `m_id` int(11) DEFAULT NULL,
  `m_parent` int(11) DEFAULT NULL,
  `title` varchar(500) DEFAULT NULL,
  `url` text COMMENT 'url externa',
  `p_id` int(11) DEFAULT NULL COMMENT 'page id',
  `order` int(11) DEFAULT NULL,
  `active` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `menus_structure` WRITE;
/*!40000 ALTER TABLE `menus_structure` DISABLE KEYS */;

INSERT INTO `menus_structure` (`id`, `m_id`, `m_parent`, `title`, `url`, `p_id`, `order`, `active`)
VALUES
	(17,2,0,'','',18,0,1),
	(18,2,0,'','',19,0,1),
	(21,3,0,'','',15,0,1),
	(22,1,0,'','',10,0,1),
	(23,1,0,'','',24,4,1),
	(24,1,0,'','',23,7,1),
	(26,1,0,'','',22,1,1),
	(27,1,0,'','',25,5,1),
	(28,1,0,'Viñedos','',0,2,1),
	(29,1,0,'Cava','',0,3,1),
	(32,1,0,'Actividades I notícias','',0,8,1),
	(33,1,0,'','',26,6,1),
	(34,1,28,'','',27,0,1),
	(35,1,28,'','',28,2,1),
	(36,1,28,'','',29,1,1),
	(37,1,29,'','',30,2,1),
	(38,1,29,'','',31,3,1),
	(40,1,29,'','',33,0,1),
	(41,1,29,'','',34,1,1);

/*!40000 ALTER TABLE `menus_structure` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla menus_types
# ------------------------------------------------------------

DROP TABLE IF EXISTS `menus_types`;

CREATE TABLE `menus_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `menus_types` WRITE;
/*!40000 ALTER TABLE `menus_types` DISABLE KEYS */;

INSERT INTO `menus_types` (`id`, `title`)
VALUES
	(1,'Header'),
	(2,'Footer - login'),
	(3,'Footer - condiciones');

/*!40000 ALTER TABLE `menus_types` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla options
# ------------------------------------------------------------

DROP TABLE IF EXISTS `options`;

CREATE TABLE `options` (
  `ID` bigint(10) NOT NULL AUTO_INCREMENT,
  `options_key` varchar(255) NOT NULL,
  `options_value` longtext NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `options_key` (`options_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;

INSERT INTO `options` (`ID`, `options_key`, `options_value`, `description`)
VALUES
	(1,'description','','Meta descripcion de la pagina'),
	(2,'keywords','','Meta keywords'),
	(3,'sitetitle','Agustí Torelló Mata','Titulo'),
	(4,'sitetitlefull','Agustí Torelló Mata',NULL),
	(5,'sitetitleseo','ATM','Titulo corto para SEO'),
	(10,'dir','[{\"placeTitle\":\"\",\"dir\":\"Av. Jaume I, 107 Bx-1, 08880 Cubelles, Barcelona\",\"shortDir\":\"Av. Jaume I, 107 Bx-1\",\"gmapUrl\":\"https:\\/\\/goo.gl\\/maps\\/nwjkEmMRAho\",\"gps\":\"41.401721, 2.136905\",\"post\":\"08880\",\"country\":\"Spain\",\"city\":\"Barcelona\",\"tel\":\"+34 93 891 11 73\",\"telAlter\":\"\",\"cif\":\"47795265T\"}]',NULL),
	(13,'mailinfo','info@agustitorellomata.com','Mail de info (info@glunt.es)'),
	(15,'botmail','mensaje-automatizado@agustitorellomata.com','Mail desde donde se contesta'),
	(21,'analytics','','Analytics ID'),
	(22,'addthis','','AddThis ID'),
	(23,'gmaps_key','AIzaSyCPd8AtJAVYxjdHbQS3Ti9KzZMj9kuOasA','Google maps API Token'),
	(24,'fb','https://www.facebook.com/Cava.Agusti.Torello.Mata','Facebook'),
	(25,'tw','https://twitter.com/ATM_Cava','Twitter'),
	(26,'in','https://www.instagram.com/agustitorellomatacava','Instagram'),
	(27,'gp','https://goo.gl/maps/nwjkEmMRAho','Google Plus'),
	(28,'tr','','TripAdvisor'),
	(29,'fb_page_name','',NULL),
	(30,'fb_page_id','',NULL),
	(31,'fb_app','',NULL),
	(32,'fb_secret','',NULL),
	(33,'fb_token','',NULL),
	(34,'fb_app_token','',NULL),
	(35,'tw_costumer_key','',NULL),
	(36,'tw_costumer_secret','',NULL),
	(37,'tw_access_token','',NULL),
	(38,'tw_access_secret','',NULL),
	(39,'tw_owner','',NULL),
	(40,'tw_owner_id','',NULL),
	(41,'dm_nws','agustitorellomata.com',NULL),
	(42,'api','',NULL),
	(45,'tel','[]',NULL),
	(46,'sideMenu','',NULL),
	(47,'initial_page','home','Pagina por defecto'),
	(48,'lang','[\"es\",\"en\",\"ca\"]','Idiomas'),
	(49,'defaultLang','es','Idioma por defecto'),
	(50,'initial_page_header_type','select','Home tipo de header en la pagina principal'),
	(51,'default_iva_percentage','21','iva por defecto, se pondra en el caso de que varie el año y no se actualize a tiempo'),
	(52,'redsys_user','',NULL),
	(53,'redsys_pass','',NULL),
	(54,'redsys_sha256','',NULL),
	(55,'redsys_mode','1',NULL),
	(56,'initial_page_header_gallery_id','112','Home Gallery id de la galeria del header'),
	(57,'initial_page_header_popup_id','97','Home Gallery id del popup'),
	(58,'initial_page_header_popup_enabled','1','Home popup enable / disable'),
	(59,'redsys_active','1',NULL),
	(60,'redsys_pass_real','',NULL),
	(61,'redsys_sha256_real','',NULL),
	(62,'paypal_mode','1',NULL),
	(63,'paypal_active','1',NULL),
	(64,'redsys_service','redirect',NULL),
	(65,'paypal_apiuser_sandbox','',NULL),
	(66,'paypal_apipass_sandbox','',NULL),
	(67,'paypal_apisign_sandbox','',NULL),
	(68,'paypal_apiuser_live','',NULL),
	(69,'paypal_apipass_live','',NULL),
	(70,'paypal_apisign_live','',NULL),
	(71,'redsys_notification_type','post',NULL),
	(72,'home_destacados_cat_id','1',NULL),
	(73,'home_destacados_cant','27',NULL),
	(74,'adwords','',NULL),
	(75,'instagram_api','',NULL),
	(76,'instagram_token','',NULL),
	(77,'instagram_secret','',NULL),
	(78,'instagram_id','',NULL),
	(79,'instagram_callback','',NULL),
	(81,'fb_pixel','',NULL),
	(82,'standartEmail','<!doctype html><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"><meta name=\"viewport\" content=\"width:device-width, initial-scale:1.0\"><title>%title%</title><style type=\"text/css\">.ReadMsgBody {width: 100%;background-color: #e9eaed;} .ExternalClass {width: 100%; background-color: #e9eaed; } body {width: 100%;background-color: #ffffff;margin: 0;padding: 0;-webkit-font-smoothing: antialiased;font-family: Georgia, Times, serif;} table {border-collapse: collapse;} .mobile-only {display: none;} @media only screen and (max-width: 640px) {body[yahoo] .deviceWidth {width: 440px!important;padding: 0;} body[yahoo] .paddedblockWidth{width: 400px!important;padding: 0;} body[yahoo] .button {width: 400px!important;padding: 0;} body[yahoo] .center {text-align: center!important;} .paddingleft {padding: 20px 20px 16px 20px!important;}} @media only screen and (max-width: 479px) {body[yahoo] .deviceWidth {width: 280px!important;padding: 0;} body[yahoo] .paddedblockWidth{width: 240px!important;padding: 0;} body[yahoo] .button {width: 240px!important;padding: 0;} body[yahoo] .center {text-align: center!important;}}</style></head><body leftmargin=\"0\" topmargin=\"0\" marginwidth=\"0\" marginheight=\"0\" yahoo=\"fix\" style=\"font-family: Arial, Times, serif\"><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\"><tr><td><table width=\"580\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" class=\"deviceWidth\"><tr><td width=\"100%\" height=\"30\" padding=\"\" font-family=\"\" font-size=\"\" color=\"\" text-align=\"\" line-height=\"\">&nbsp;</td></tr></table></td></tr></table><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\"><tr><td width=\"100%\" valign=\"top\"><table width=\"580\" align=\"center\" class=\"deviceWidth\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tbody><tr><td style=\"padding: 0px 20px 20px; text-align: left; color: #6a7480; line-height: 18px; font-family: Arial, sans-serif; font-size: 14px; font-weight: normal; vertical-align: top;\" bgcolor=\"#ebebeb\"><br><p style=\"-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;margin-top:0;margin-bottom:24px;margin-right:0;margin-left:0;\">%message%<br/><br><span>%regards%</span><br><span><b>%site_name%</b></span></td></tr></tbody></table><div style=\"height: 25px\">&nbsp;</div><table width=\"100%\" border=\"0\" cellspacing=\"0\" align=\"center\"><tr><td style=\"padding: 30px\"><table width=\"580\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" class=\"deviceWidth\"><tr><td><table width=\"45%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"left\" class=\"deviceWidth\"> <tr><td valign=\"top\" style=\"font-size: 11px; color: #9197a3; font-family: Arial, sans-serif; padding-bottom: 20px; line-height: 16px;\" class=\"center\"><br>Copyright &#169; %site_name%.<br> %copyz%<br><br><span style=\"font-size:11px;color:#9197a3;font-family: Arial, sans-serif;line-height: 14px;\">%site_dir%</span><br><br></td></tr></table><table width=\"40%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"right\" class=\"deviceWidth\"><tr><td valign=\"top\" style=\"font-size: 11px; color:#9197a3; font-weight: normal; font-family: Arial, Times, serif; line-height: 16px; vertical-align: top; text-align: right\" class=\"center\">%site_logo%</td></tr></table></td></tr></table></td></tr></table></td></tr></table></body></html>',NULL),
	(83,'tooSHash','6254bd05df70f6c57df731d908873252',NULL),
	(84,'tooSType','1',NULL),
	(85,'dirDefault','0',NULL);

/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla pages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pages`;

CREATE TABLE `pages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `obj_title` varchar(255) DEFAULT NULL,
  `obj_hash` varchar(100) DEFAULT NULL,
  `type` int(11) DEFAULT '1',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `active` int(1) DEFAULT '0',
  `protected` int(1) DEFAULT '0',
  `lang` varchar(5) DEFAULT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `obj_hash` (`obj_hash`,`lang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;

INSERT INTO `pages` (`id`, `obj_title`, `obj_hash`, `type`, `create_date`, `active`, `protected`, `lang`, `update_date`)
VALUES
	(8,'Contacto','contacto',1,'2018-01-09 00:00:00',1,0,'es','2018-01-09 13:42:11'),
	(10,'Home','home',6,'2018-01-09 00:00:00',1,1,'es','2018-01-16 13:56:47'),
	(25,'Productos','productos',7,'2019-02-25 00:00:00',1,1,'es','2019-02-25 21:05:56'),
	(24,'Kripta','kripta',1,'2019-02-15 00:00:00',1,1,'es','2019-02-15 21:12:02'),
	(14,'login','login',1,'2018-02-01 00:00:00',1,1,'es','2018-02-01 12:43:56'),
	(15,'Recuperación de contraseña','recuperacion-de-contrasena',1,'2018-02-01 00:00:00',1,1,'es','2018-02-01 16:44:53'),
	(23,'Visitas','visitas',1,'2019-02-15 00:00:00',1,1,'es','2019-02-15 21:11:27'),
	(18,'Política de privacidad','politica-de-privacidad',1,'2018-02-06 00:00:00',1,1,'es','2019-02-18 12:58:04'),
	(19,'Política de cookies','politica-de-privacidad-y-cookies',1,'2018-02-06 00:00:00',1,1,'es','2019-02-18 12:58:30'),
	(22,'Filosofía','filosofia',1,'2019-02-15 00:00:00',1,1,'es','2019-02-15 21:03:58'),
	(21,'error','error',1,'2018-02-23 00:00:00',1,1,'es','2019-02-15 21:00:41'),
	(26,'Premios','premios',1,'2019-04-03 00:00:00',1,1,'es','2019-04-03 12:05:16'),
	(27,'El Origen','el-origen',1,'2019-04-04 00:00:00',1,1,'es','2019-04-08 13:28:41'),
	(28,'VITICULTURA ECOLÓGICA','viticultura-ecologica',1,'2019-04-04 00:00:00',1,1,'es','2019-04-04 22:06:09'),
	(29,'VARIEDADES AUTÓCTONAS','variedades-autoctonas',1,'2019-04-04 00:00:00',1,1,'es','2019-04-04 22:14:33'),
	(30,'Crianza','crianza',1,'2019-04-06 00:00:00',1,0,'es','2019-04-06 19:19:29'),
	(31,'Degüelle','deguelle',1,'2019-04-06 00:00:00',1,0,'es','2019-04-06 19:24:48'),
	(32,'Vinos','vinos',1,'2019-04-06 00:00:00',1,0,'es','2019-04-06 19:27:10'),
	(33,'Elaboración de los vinos','elaboracion-de-los-vinos',1,'2019-04-11 00:00:00',1,0,'es','2019-04-11 12:30:30'),
	(34,'Cupajes','cupajes',1,'2019-04-11 00:00:00',1,0,'es','2019-04-11 12:35:57');

/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla pages_lang_rel
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pages_lang_rel`;

CREATE TABLE `pages_lang_rel` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(11) DEFAULT NULL,
  `lang_type` varchar(2) DEFAULT '',
  `page_translate_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_id` (`page_id`,`page_translate_id`,`lang_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Volcado de tabla pages_meta
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pages_meta`;

CREATE TABLE `pages_meta` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `p_id` int(11) DEFAULT NULL,
  `meta_key` varchar(100) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `p_id` (`p_id`,`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `pages_meta` WRITE;
/*!40000 ALTER TABLE `pages_meta` DISABLE KEYS */;

INSERT INTO `pages_meta` (`id`, `p_id`, `meta_key`, `meta_value`)
VALUES
	(1,21,'page_content','ZmFsc2U='),
	(2,21,'seo_resumen',''),
	(3,21,'seo_checktitleonfreaturedimage','0'),
	(4,21,'seo_customtitleonfreaturedimage',''),
	(5,21,'seo_freaturedimage',''),
	(6,21,'seo_noodp','0'),
	(7,21,'seo_noydir','0'),
	(8,21,'seo_nofollow','0'),
	(9,21,'seo_noarchive','0'),
	(10,21,'seo_keywords',''),
	(11,21,'seo_description',''),
	(12,21,'seo_customimage',''),
	(13,10,'page_content','W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPlVOIENBVkEgQ09OIEFMTUE8L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz5FbCBjYXZhIEFHVVNUSSBUT1JFTExPIE1BVEEgZXMgZWwgcmVzdWx0YWRvIGRlIHVuIGNvbXByb21pc28gcGVyc29uYWwuIExhIGRlZGljYWNpw7NuIGRlIHVuYSBmYW1pbGlhIHkgdW4gZXF1aXBvIGRlIHBlcnNvbmFzIHF1ZSBoYWNlIHBvc2libGUsIGHDsW8gdHJhcyBhw7FvLCBjb3NlY2hhIHRyYXMgY29zZWNoYSwgZWwgbWlsYWdybyBkZSBlbGFib3JhciB1bm9zIGNhdmFzIGNvbiBwZXJzb25hbGlkYWQgw7puaWNhIHkgcmVjb25vY2ltaWVudG8gaW50ZXJuYWNpb25hbC4gTnVlc3Ryb3MgY2F2YXMgbmFjZW4gZGUgbGFzIG1lam9yZXMgdmnDsWFzIGRlbCBQZW5lZMOpcywgc29uIHJlc3BldHVvc29zIGNvbiBzdSB0aWVycmEgeSBjb24gbGFzIHZhcmllZGFkZXMgYXV0w7NjdG9uYXMsIGNvbiBlbCBzdWVsbyB5IGVsIGNsaW1hLCBjb24gZWwgcHJvY2VzbyB5IGxhIHRyYWRpY2nDs24uU29uIGNhdmFzIHF1ZSBldm9sdWNpb25hbiBjb24gZWwgc2VudGltaWVudG8gZGUgbGEgcGVyZmVjY2nDs24uIENhdmFzIHF1ZSB0cmFuc21pdGVuIGxvIHF1ZSBsbGV2YW4gZGVudHJvLiBTb24gY2F2YXMgY29uIGFsbWEuPC9wPiJ9fSx7InR5cGUiOiJ3LTEtMSBwYi00ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6e319LHsidHlwZSI6InctMS0xIGdjIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC9hYTgzNjllNjY5ZWFmMDA2NWI2MmVkMzllMDE3M2U1Yi5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0xIGciLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fV0='),
	(14,10,'seo_resumen',''),
	(15,10,'seo_checktitleonfreaturedimage','0'),
	(16,10,'seo_customtitleonfreaturedimage',''),
	(17,10,'seo_freaturedimage',''),
	(18,10,'seo_noodp','0'),
	(19,10,'seo_noydir','0'),
	(20,10,'seo_nofollow','0'),
	(21,10,'seo_noarchive','0'),
	(22,10,'seo_keywords',''),
	(23,10,'seo_description',''),
	(24,10,'seo_customimage',''),
	(25,22,'page_content','W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPkZJTE9TT0bDjUE8L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwYi00ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTtwMSB0eHRAaiYjMzk7PkFHVVNUw40gVE9SRUxMw5MgTUFUQSwgaGlqbyBkZSBzYXN0cmVzIHkgbcO6c2ljb3MsIHNlIGludHJvZHVqbyBkZXNkZSBtdXkgam92ZW4gZW4gZWwgbXVuZG8gZGVsIGNhdmEgY29udmlydMOobmRvbG8gZW4gc3UgcGFzacOzbiB5IHN1IHByb2Zlc2nDs24uIFBpb25lcm8sIGFwYXNpb25hZG8geSB0cmFiYWphZG9yIGluY2Fuc2FibGUgZW4gMTk1MyBpbmF1Z3Vyw7MgZW4gU2FudCBTYWR1cm7DrSBk4oCZQW5vaWEgZWwgcHJpbWVyIGxhYm9yYXRvcmlvIGRlIGFuw6BsaXNpcyBkZSB2aW5vcy4gQSBsbyBsYXJnbyBkZSBzdSB2aWRhLCBoYSBkaXJpZ2lkbyBpbXBvcnRhbnRlcyBib2RlZ2FzIGRlbCBzZWN0b3IgaW5pY2lhbmRvIGFsIG1pc21vIHRpZW1wbyBzdSBwcm9waWEgZW1wcmVzYSBlbiAxOTU5LiBFbiAxOTc5IGVsYWJvcmEgbGFzIHByaW1lcmFzIGJvdGVsbGFzIGRlIEtSSVBUQSB5IGVuIDE5OTMgbmFjZSBzdSBtYXJjYSBwZXJzb25hbCBBR1VTVMONIFRPUkVMTMOTIE1BVEEuPC9wPjxwIGNsYXNzPSYjMzk7cDEgdHh0QGomIzM5Oz5TdSB0cmF5ZWN0b3JpYSBwZXJzb25hbCBsbyBoYSBjb252ZXJ0aWRvIGVuIG9ibGlnYWRvIHJlZmVyZW50ZSBkZWwgQ0FWQTogUHJlc2lkZW50ZSBmdW5kYWRvciBkZSBIb25vciBkZSBsYSBDb2ZyYWTDrWEgZGVsIENhdmEsIFByaW1lcmEgTWVkYWxsYSBkZSBPcm8gZW5vbMOzZ2ljbyBkZWwgTWluaXN0ZXJpbyBkZSBBZ3JpY3VsdHVyYSwgTWVkYWxsYSBhbCBtw6lyaXRvIGFncsOtY29sYSBkZSBsYSBHZW5lcmFsaXRhdCBkZSBDYXRhbHVueWEuPC9wPjxwIGNsYXNzPSYjMzk7cDEgdHh0QGomIzM5Oz5Ib3kgZW4gZGlhIEFHVVNUw40gVE9SRUxMw5MgTUFUQSBlcyB1bmEgZW1wcmVzYSBmYW1pbGlhciBkZSBjb25zb2xpZGFkbyBwcmVzdGlnaW8uPC9wPiJ9fSx7InR5cGUiOiJ3LTEtMSBnYyIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6e319LHsidHlwZSI6InctMS0xIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvMjkxNDM5NzU4MDFiOTIyNWE4YmI3NGE1Njc0YmU0NWUuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJ3LTEtMSBnIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX1d'),
	(26,22,'seo_resumen',''),
	(27,22,'seo_checktitleonfreaturedimage','0'),
	(28,22,'seo_customtitleonfreaturedimage',''),
	(29,22,'seo_freaturedimage',''),
	(30,22,'seo_noodp','0'),
	(31,22,'seo_noydir','0'),
	(32,22,'seo_nofollow','0'),
	(33,22,'seo_noarchive','0'),
	(34,22,'seo_keywords',''),
	(35,22,'seo_description',''),
	(36,22,'seo_customimage',''),
	(37,23,'page_content','W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPlZJU0lUQVM8L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7cDEmIzM5Oz48Yj5QUk9QVUVTVEFTIEVOT1RVUsONU1RJQ0FTPC9iPjwvcD48cCBjbGFzcz0mIzM5O3AxJiMzOTs+PGI+TGFzIEN1YXRybyBFc3RhY2lvbmVzIERlbCBDYXZhPC9iPjwvcD48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcGItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7cDEmIzM5Oz5VbiBlc3BhY2lvIGRvbmRlIGVsIHZpc2l0YW50ZSB2aXZlIGVsIGNpY2xvIHZpdGFsIGRlbCBjYXZhIGRlc2RlIHN1IG9yaWdlbjogdXZhLCB2acOxYSwgdmlubyB5IGJ1cmJ1amFzIHNlIGZ1c2lvbmFuIGVuIHVuIHBhc2VvIHBvciBsYXMgY3VhdHJvIGVzdGFjaW9uZXMgZGVsIGHDsW8gYSB0cmF2w6lzIGRlIGxvcyBvam9zIGRlbCBjYXZhLjwvcD48cCBjbGFzcz0mIzM5O3AxJiMzOTs+VW5hIGV4cGVyaWVuY2lhIGltcGFjdGFudGUgZG9uZGUgbGEgdmnDsWEgc2UgY29udmllcnRlIGVuIGVsIGhpbG8gY29uZHVjdG9yIGRlbCBwcm9jZXNvIGRlbCBjYXZhLCBlbiB1bmEgcGFudGFsbGEgcXVlIGRlc3BpZXJ0YSB0b2RvcyBsb3Mgc2VudGlkb3MuPC9wPjxwIGNsYXNzPSYjMzk7cDEmIzM5Oz5VbiBob21lbmFqZSBhIGxhIHRpZXJyYSB5IGEgc3VzIGhvbWJyZXMsIHBvcnF1ZSBjb25zZWd1aXIgcXVlIHVuIGdyYW5vIGRlIHV2YSBzZSB0cmFuc2Zvcm1lIGVuIHVuIHZpbm8gY29uIG3DunNpY2EgeSB2aWRhIHByb3BpYSwgZXMgYWxnbyBxdWUgZXN0w6Egc29sbyBhbCBhbGNhbmNlIGRlIGxvcyBxdWUgaGFjZW4gcmVhbGlkYWQgc3VzIHN1ZcOxb3MuPGJyPk51ZXN0cm8gc3Vlw7FvIGVzIGNvbXBhcnRpciBsbyBxdWUgdml2aW1vcyBkdXJhbnRlIHRvZG8gZWwgYcOxby48L3A+In19LHsidHlwZSI6InctMS0xIGdjIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiIifX0seyJ0eXBlIjoidy0xLTEiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC80ZDY2MGRhN2IxMTg2MGNjYWVmN2ViMmFiYzUzOWNkYi5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0xIGciLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBwdC00IHBiLTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PGI+VklTSVRBUyBBIExFUyBDQVZBUzwvYj48L3A+In19LHsidHlwZSI6Im1jIHctMS0zIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48Yj5WSVNJVEEgUkVTRVJWQTwvYj48L3A+PHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PjxpPlZpc2l0YSBndWlhZGEgeSBkZWd1c3RhY2nDs24gZGUgZG9zIGNhdmFzIHkgdW4gdmlubzwvaT48L3A+PHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PlJlY29ycmlkbyBndWlhZG8gcG9yIGxhcyBpbnN0YWxhY2lvbmVzIGRlIGxhIGJvZGVnYSBkZSB2aW5pZmljYWNpw7NuIHkgcG9yIGxhcyBjYXZhcyBwYXJhIGNvbm9jZXIgbGFzIGNhcmFjdGVyw61zdGljYXMgZGVsIFBlbmVkw6hzIHkgbGFzIHBhcnRpY3VsYXJpZGFkZXMgZGVsIHByb2Nlc28gZGUgZWxhYm9yYWNpw7NuIHkgY3JpYW56YSBkZSBudWVzdHJvcyBjYXZhcy48YnI+PGJyPjxicj5EZWd1c3RhY2nDs24gY29tZW50YWRhIGRlIHVuIHZpbm8geSBkb3MgY2F2YXM6IFhJQzxicj5YYXJlbMK3bG8sIEJydXQgUmVzZXJ2YSB5IFJvc2F0IFRyZXBhdC4gPC9wPjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz48aT48YnI+PGJyPjxicj48L2k+PC9wPjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz48aT5EdXJhY2nDs246IDkwIG1pbnV0b3MuPC9pPjxicj48aT5QcmVjaW8gcG9yIHBlcnNvbmE6IDEw4oKsPC9pPjwvcD48cD48aT48L2k+PC9wPiJ9fSx7InR5cGUiOiJtYyB3LTEtMyB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PGI+VklTSVRBIEdSQU4gUkVTRVJWQTwvYj48L3A+PHAgY2xhc3M9JiMzOTtwMSB0eHRAaiYjMzk7PjxpPlZpc2l0YSBndWlhZGEgeSBkZWd1c3RhY2nDs24gZGUgdHJlcyBjYXZhcyB5IHVuIHZpbm88L2k+PC9wPjxwIGNsYXNzPSYjMzk7cDEgdHh0QGomIzM5Oz5SZWNvcnJpZG8gZ3VpYWRvIHBvciBsYXMgaW5zdGFsYWNpb25lcyBkZSBsYSBib2RlZ2EgZGUgdmluaWZpY2FjacOzbiB5IHBvciBsYXMgY2F2YXMgcGFyYSBjb25vY2VyIGxhcyBjYXJhY3RlcsOtc3RpY2FzIGRlbCBQZW5lZMOocyB5IGxhcyBwYXJ0aWN1bGFyaWRhZGVzIGRlbCBwcm9jZXNvIGRlIGVsYWJvcmFjacOzbiB5IGNyaWFuemEgZGUgbnVlc3Ryb3MgY2F2YXMuPGJyPjxicj48YnI+RGVndXN0YWNpw7NuIGNvbWVudGFkYSBkZSB1biB2aW5vIHkgdHJlcyBjYXZhczogWElDIFhhcmVswrdsbywgQnJ1dCBHcmFuIFJlc2VydmEsIEdyYW4gUmVzZXJ2YSBCYXJyaWNhIHkgUm9zYXQgVHJlcGF0PC9wPjxicj48cCBjbGFzcz0mIzM5O3AxIHR4dEBqJiMzOTs+PGk+PGJyPjxicj5EdTwvaT48aT5yPC9pPjxpPmFjacOzbjogOTAgbWludTwvaT48aT50PC9pPjxpPm9zLjxicj48L2k+PGk+UHJlY2lvIHBvciBwZXJzb25hOiAxNTwvaT48aT7igqw8L2k+PC9wPiJ9fSx7InR5cGUiOiJtYyB3LTEtMyB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PGI+VklTSVRBIFZJUDwvYj48L3A+PHAgY2xhc3M9JiMzOTtwMSYjMzk7PjxpPlQ8L2k+PGk+b3VyIHByaTwvaT48aT52PC9pPjxpPmFkbyB5IGRlZ3U8L2k+PGk+czwvaT48aT50YWNpw7NuIGRlIDUgYzwvaT48aT5hdjwvaT48aT5hcyAoaW5jbHU8L2k+PGk+eTwvaT48aT5lIGM8L2k+PGk+YTwvaT48aT50YSBkZSBLcmlwdGEpIHkgdW4gdmlubzwvaT48L3A+PHAgY2xhc3M9JiMzOTtwMSYjMzk7PlZpc2l0YSBndWlhZGEgcHJpdmFkYSBwb3IgbGFzIGluc3RhbGFjaW9uZXMgZGUgbGEgYm9kZWdhIGRlIHZpbmlmaWNhY2nDs24geSBwb3IgbGFzIGNhdmFzIHBhcmEgY29ub2NlciBsYXMgY2FyYWN0ZXLDrXN0aWNhcyBkZWwgUGVuZWTDqHMgeSBsYXMgcGFydGljdWxhcmlkYWRlcyBkZWwgcHJvY2VzbyBkZSBlbGFib3JhY2nDs24geSBjcmlhbnphIGRlIG51ZXN0cm9zIGNhdmFzLjxicj48YnI+PGJyPlNlc2nDs24gZGUgZGVndXN0YWNpw7NuIGNvbWVudGFkYSBkZSBudWVzdHJvcyBjYXZhcyBtw6FzIHJlcHJlc2VudGF0aXZvczogQnJ1dCBOYXR1cmUgR3JhbiBSZXNlcnZhLDxicj5CYXJyaWNhIEdyYW4gUmVzZXJ2YSwgQ3JpcHRhIEdyYW4gUmVzZXJ2YSB5IFJvc2F0IFRyZXBhdC4gVGFtYmnDqW4gaW5jbHV5ZSBlbCB2aW5vIFhpYyBYYXJlbMK3bG8uPGJyPjxpPjxicj5EdTwvaT48aT5yPC9pPjxpPmFjacOzbjogMiBobzwvaT48aT5yPC9pPjxpPmFzLjxicj48L2k+PGk+UHJlY2lvIHBvciBwZXJzb25hOiA1MDwvaT48aT7igqw8L2k+PC9wPjxwIGNsYXNzPSYjMzk7cDMmIzM5Oz48aT48L2k+PC9wPjxicj4ifX0seyJ0eXBlIjoidy0xLTEgcHQtNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBnYyIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6e319LHsidHlwZSI6InctMS0xIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvNWM1YWM1ZWE1ZGQzZWEzZGEyYmNjM2M5YWFiODE3NzUuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJ3LTEtMSBnIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEgcGItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fV0='),
	(38,23,'seo_resumen',''),
	(39,23,'seo_checktitleonfreaturedimage','0'),
	(40,23,'seo_customtitleonfreaturedimage',''),
	(41,23,'seo_freaturedimage',''),
	(42,23,'seo_noodp','0'),
	(43,23,'seo_noydir','0'),
	(44,23,'seo_nofollow','0'),
	(45,23,'seo_noarchive','0'),
	(46,23,'seo_keywords',''),
	(47,23,'seo_description',''),
	(48,23,'seo_customimage',''),
	(97,18,'page_content','ZmFsc2U='),
	(98,18,'seo_resumen',''),
	(99,18,'seo_checktitleonfreaturedimage','0'),
	(100,18,'seo_customtitleonfreaturedimage',''),
	(101,18,'seo_freaturedimage',''),
	(102,18,'seo_noodp','0'),
	(103,18,'seo_noydir','0'),
	(104,18,'seo_nofollow','0'),
	(105,18,'seo_noarchive','0'),
	(106,18,'seo_keywords',''),
	(107,18,'seo_description',''),
	(108,18,'seo_customimage',''),
	(109,19,'page_content','ZmFsc2U='),
	(110,19,'seo_resumen',''),
	(111,19,'seo_checktitleonfreaturedimage','0'),
	(112,19,'seo_customtitleonfreaturedimage',''),
	(113,19,'seo_freaturedimage',''),
	(114,19,'seo_noodp','0'),
	(115,19,'seo_noydir','0'),
	(116,19,'seo_nofollow','0'),
	(117,19,'seo_noarchive','0'),
	(118,19,'seo_keywords',''),
	(119,19,'seo_description',''),
	(120,19,'seo_customimage',''),
	(121,24,'page_content','W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPktSSVBUQTwvYj48L2gxPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTtwMSB0eHRAaiYjMzk7PjE5NzkgZW4gbGEgYm9kZWdhIGRlIENhbiBSb3NzZWxsIG5hY2UgS0lQVEEuIERlc3B1w6lzIGRlIDMyIGHDsW9zIGRlIGV4cGVyaWVuY2lhIEFHVVNUw40gVE9SRUxMw5MgTUFUQSBkZWNpZGUgcmVhbGl6YXIgc3UgaWx1c2nDs24uIEtSSVBUQSBwcm9jZWRlIGRlIGxvcyBtZWpvcmVzIHZpw7FlZG9zIHZpZWpvcyBkZWwgUGVuZWTDqXMsIHVuIGNvcGFqZSBleGNlcGNpb25hbCBkZSBsYXMgbWVqb3JlcyBwYXJjZWxhcyBkZSBNYWNhYmVvLCBYYXJlbMK3bG8geSBQYXJlbGxhZGEuPC9wPjxwIGNsYXNzPSYjMzk7cDEgdHh0QGomIzM5Oz5VbmEgbGFyZ2EgY3JpYW56YSBjb24gdGFww7NuIGRlIGNvcmNobyBkZSA1IGHDsW9zIGNvbW8gbcOtbmltbywgY29uc2lndWVuIHVuIGJvdXF1ZXQgw7puaWNvIHF1ZSBsbyBjb25zb2xpZGEgY29tbyB1bm8gZGUgbG9zIGdyYW5kZXMgdmlub3MgZGVsIG11bmRvLjwvcD48cCBjbGFzcz0mIzM5O3AxIHR4dEBqJiMzOTs+TGEgYm90ZWxsYSwgLXJlbWluaXNjZW5jaWFzIGRlIMOhbmZvcmEgcm9tYW5hLSwgeSBsYSBldGlxdWV0YSAtb2JyYSBkZWwgYXJ0aXN0YSBSYWZhZWwgQmFydG9sb3p6aS0gc29uIGVsIHRvcXVlIGRlIGVsZWdhbmNpYSBmaW5hbCBkZSBlc3RlIGdyYW4gY2F2YS48L3A+In19LHsidHlwZSI6InctMS0xIHB0LTQgcGItMyAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC82Y2QyZjA2ZGI4MDNkMjBlMWVjNzc4MDZhNDZiODljOC5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0xIHB0LTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvYzYwNDZlMGRmNDNiYzIzNjk1YmQ5OTkxYjAwYzUyN2YuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fV0='),
	(122,24,'seo_resumen',''),
	(123,24,'seo_checktitleonfreaturedimage','0'),
	(124,24,'seo_customtitleonfreaturedimage',''),
	(125,24,'seo_freaturedimage',''),
	(126,24,'seo_noodp','0'),
	(127,24,'seo_noydir','0'),
	(128,24,'seo_nofollow','0'),
	(129,24,'seo_noarchive','0'),
	(130,24,'seo_keywords',''),
	(131,24,'seo_description',''),
	(132,24,'seo_customimage',''),
	(625,25,'page_content','W3sidHlwZSI6InctMS0xIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PlBST0RVQ1RPUzwvaDE+In19XQ=='),
	(626,25,'seo_resumen',''),
	(627,25,'seo_checktitleonfreaturedimage','0'),
	(628,25,'seo_customtitleonfreaturedimage',''),
	(629,25,'seo_freaturedimage',''),
	(630,25,'seo_noodp','0'),
	(631,25,'seo_noydir','0'),
	(632,25,'seo_nofollow','0'),
	(633,25,'seo_noarchive','0'),
	(634,25,'seo_keywords',''),
	(635,25,'seo_description',''),
	(636,25,'seo_customimage',''),
	(685,26,'page_content','W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPlBSRU1JT1M8L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ik51ZXN0cm8gY2F2YSBnb3phIGRlbCByZWNvbm9jaW1pZW50byB5IGxhIGZpZGVsaWRhZCBkZSBjbGllbnRlcyBkZSByZWxldmFuY2lhIGludGVybmFjaW9uYWwuIEVzIHBpb25lcm8geSBlc3TDoSBwcmVzZW50ZSBlbiBsb3MgbcOhcyBzZWxlY3RvcyBlc3RhYmxlY2ltaWVudG9zIGRlIG3Dumx0aXBsZXMgcGHDrXNlcyBwb3Igc3UgY2FsaWRhZCwgcGVyc29uYWxpZGFkIHkgZXhjbHVzaXZpZGFkLiJ9fSx7InR5cGUiOiJ3LTEtMSBwYi0zIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC8zMzA4MzQ5OTcxODYzNjVhMmRmNjFkZTRjOGY1YWNlMi5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNiBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGhyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50LzU0ZWE0NzEwMzMyMjhhYWM3ODE4ODNiODdlMjRkMmY1LmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC02IHBiLTYgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aHI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvOTI4ZjUyMTczOWZiMjEyMzFlMjhkOTJmYzFmOTllNDEuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC83MjBiNWIzY2YwZGMzNjg2MDA5MTgwOWEyNGQ1M2ZmMS5wbmcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNiBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGhyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50L2YxOWY1YWQ5YWQ0MmNhN2U1YWUyZDMwYzQ1NTA0ODNjLmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC02IHBiLTYgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aHI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvZTUxOTgxN2IzOTU0YWVlNDE2NDhlYjZmMmQ3MTlhODcuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC9iYzgzZmUwNjg0ZWY0YzM1NTI5NjUwMWFjMDRjZTBmNy5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNiBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGhyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50LzUwN2M5NTEzNWE4YmYzNWU2NDExMGQyZGQxOWRjOWNiLmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC02IHBiLTYgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aHI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvZGNjZGMzNzI1ZWRmZjQ4YThkZWM4YmFkMjE5NzFhOWMuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC9lMTA3MDkyNTg5NmMyZjYyMjc1N2U1ZGRlYjgyNTI3OC5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNiBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGhyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50Lzc4NzJjNmNhYTMzNWFlMThkOWM2MDBkNjMzZmFiZDdjLmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC02IHBiLTYgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aHI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvNWY0YmY0ZDczNWQ5MjQ3ZTU1YWZjNjkxNmVmN2UxMTguanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC9lOTQzY2YyYzEyZWU3ZmU0N2EyMmUyZDE1MTU5NGQ4NS5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNiBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGhyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50L2RjNDZiNzE4Mjg1MzE0NjQ1M2IzN2ZkZjQ0OTJlZmZjLmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC02IHBiLTYgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aHI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvNDQ1M2Q3MDhkZjMxMGU5Y2IzZGU2Y2IwYzZhMWFhMTQuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC84ZmJlNWYwNWYyY2ZhZmM5MTEwODhmZjc3ZmIzMzA4My5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNiBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGhyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50LzI5NjBhMjdmMTlkYTk0OTU2ZTAzNzczNzAyODQ4N2U2LmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC02IHBiLTYgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aHI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvNWJlODJkZTljNjA0Y2E2ODdiZmQ4ZmQzZjEwZjI3YjkuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIGhzIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC81OTgzMWYyZWYzYzBkZGEzZjI2NDYxN2RiZTU3MWNiMS5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0xIHBiLTMiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fV0='),
	(686,26,'seo_resumen',''),
	(687,26,'seo_checktitleonfreaturedimage','0'),
	(688,26,'seo_customtitleonfreaturedimage',''),
	(689,26,'seo_freaturedimage',''),
	(690,26,'seo_noodp','0'),
	(691,26,'seo_noydir','0'),
	(692,26,'seo_nofollow','0'),
	(693,26,'seo_noarchive','0'),
	(694,26,'seo_keywords',''),
	(695,26,'seo_description',''),
	(696,26,'seo_customimage',''),
	(841,26,'gallery_id','25'),
	(1046,27,'page_content','W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPkVMIE9Sw41HRU48L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwYi00ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PkxhcyBjYXZhcyBlc3TDoW4gc2l0dWFkYXMgZW4gZWwgY29yYXrDs24gZGVsIFBlbmVkw6lzOiBlbiBTYW50IFNhZHVybsOtIGTigJlBbm9pYSwgY2FwaXRhbCBkZWwgQ2F2YS4gTGFzIGVzdHJ1Y3R1cmFzZ2VvbMOzZ2ljYXMgZGUgbGEgem9uYSB5IGxhIGluZmx1ZW5jaWEgZGVsIG1hciBNZWRpdGVycsOhbmVvLCBkZXRlcm1pbmFuIGxvcyBsw61taXRlcyBnZW9ncsOhZmljb3MgeSBtaWNyb2NsaW3DoXRpY29zZGUgbGFzIGRpZmVyZW50ZXMgc3Viem9uYXMgcXVlLCBlbiBzdSBjb25qdW50bywgZm9ybWFuIGVsIFBlbmVkw6lzLiBMYSBjb25maWd1cmFjacOzbiBkZSBjYWRlbmFzIG1vbnRhw7Fvc2FzOkxpdG9yYWwsIFByZWxpdG9yYWwsIOKAnGNsb3TigJ0gZGUgQm9uYXN0cmUgeSBtYWNpem8gZGUgTW9udHNlcnJhdCwgeSBsYXMgZGVwcmVzaW9uZXMgZXN0cnVjdHVyYWxlcywgZm9zYXMgZGVsIFBlbmVkw6hzLENhbnllbGxlcyB5IGVsIEZvaXgsIHByb3BvcmNpb25hbiB1bmEgZ3JhbiBkaXZlcnNpZGFkIGRlIHN1ZWxvcyBjb24gaW1wb3J0YW50ZXMgZGlmZXJlbmNpYXMgbGl0b2zDs2dpY2FzIHkgZGUgY29tcG9zaWNpw7NuIHF1ZSwganVudG8gYSBsYXMgcGVjdWxpYXJpZGFkZXMgbWljcm9jbGltw6F0aWNhcyBkZSBjYWRhIGVudG9ybm8sIGNvbnN0aXR1eWVuIHRyZXMgc3Viem9uYXMgdml0w61jb2xhcyBwZXJmZWN0YW1lbnRlIGRpZmVyZW5jaWFkYXMuPC9wPjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz5Fc3RhIGV4Y2VwY2lvbmFsIGRpdmVyc2lkYWQgZGEgbXVjaG8gZGUgc8OtIGEgbGEgdml0aWN1bHR1cmEsIGVub3JtZXMgcG9zaWJpbGlkYWRlcyBkaXZlcnNpZmljYWRvcmFzLCB5IHByb3BvcmNpb25hYSBsYSBwcsOhY3RpY2EgZW5vbMOzZ2ljYSBsYSBjYXBhY2lkYWQgZGUgY3JlYXIgcHJvZHVjdG9zIGRlIGdyYW4gc2luZ3VsYXJpZGFkLiBQb3IgZXNvIG5vIHJlc3VsdGEgZW4gYWJzb2x1dG8gZXhhZ2VyYWRvIGhhYmxhciBkZSBzdWJjb21hcmNhcyBvIGRlIHN1YnpvbmFzIHBvY28gZXh0ZW5zYXMgcXVlLCBlbiBzdSBjb25qdW50bywgY29uZm9ybWFuIGxhIHBlY3VsaWFyIGlkZW50aWRhZGRlbCBQZW5lZMOocy4gRXN0dWRpYW1vcyB5IHNlbGVjY2lvbmFtb3MgbG9zIG1lam9yZXMgdGVycmVub3MgZGUgY2FkYSBwYXJjZWxhIHBhcmEgb2J0ZW5lciBsYSBtw6F4aW1hIGV4cHJlc2nDs24sIGNhbGlkYWQgeSBwZXJzb25hbGlkYWQgZGUgbGFzIGRpZmVyZW50ZXMgdmFyaWVkYWRlcyBhdXTDs2N0b25hcy48L3A+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+TWFwYSBpbnRlcmFjdGl1PC9wPjxicj48dWwgY2xhc3M9JiMzOTtsbiBnIGd3LTEtMyYjMzk7PjxsaT48ZGl2IGNsYXNzPSYjMzk7dHh0QHImIzM5Oz48YSBocmVmPSYjMzk7I3NpZXJyYS1wcmVsaXRvcmFsJiMzOTsgcmVsPSYjMzk7bm9mb2xsb3cmIzM5Oz48Yj5TaWVycmEgUHJlbGl0b3JhbDwvYj48L2E+PC9kaXY+PC9saT48bGk+PGRpdiBjbGFzcz0mIzM5O3R4dEByJiMzOTs+PGEgaHJlZj0mIzM5OyNkZXByZXNpb24tcGVuZWRlcyYjMzk7IHJlbD0mIzM5O25vZm9sbG93JiMzOTs+PGI+RGVwcmVzacOzbiBQZW5lZMOoczwvYj48L2E+PC9kaXY+PC9saT48bGk+PGRpdiBjbGFzcz0mIzM5O3R4dEByJiMzOTs+PGEgaHJlZj0mIzM5OyNzaWVycmEtbGl0b3JhbCYjMzk7IHJlbD0mIzM5O25vZm9sbG93JiMzOTs+PGI+U2llcnJhIExpdG9yYWwgKEdhcnJhZik8L2I+PC9hPjwvZGl2PjwvbGk+PC91bD48aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvNDFlZjMyY2VjMmE0YjQ4YTUxZDEwOTg3ZWJjZGJiYmUuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNiBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGhyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGRpdiBpZD0mIzM5O3NpZXJyYS1wcmVsaXRvcmFsJiMzOTs+PHAgY2xhc3M9JiMzOTtwMSYjMzk7PjxiPlNJRVJSQSBQUkVMSVRPUkFMPC9iPjwvcD48cCBjbGFzcz0mIzM5O3AyJiMzOTs+UEFSRUxMQSB8IFRSRVBBVCB8IFNVQklSQVQgUEFSRU5UOiBERSA0MDAgQSA5MDAgTTwvcD48aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvZTE2YzQwNWVjYTE1MzllNDdmZjkyZDI0ZjE3NTM3YTguanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPjwvZGl2PiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxkaXYgaWQ9JiMzOTtkZXByZXNpb24tcGVuZWRlcyYjMzk7PjxwIGNsYXNzPSYjMzk7cDEmIzM5Oz48Yj5ERVBSRVNJw5NOIERFTCBQRU5FRMOIUzwvYj48L3A+PHAgY2xhc3M9JiMzOTtwMiYjMzk7PlhBUkVMLkxPOiBERSAyMDAgQSA0MDAgTSwgU1VFTE8gREUgQVJDSUxMQVMgWSBDQUxDw4FSRUFTPC9wPjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC8zNTAxYmU5NWU2ZjQ0N2Q4NTcwYjViOTRlNWUwNzRmOC5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+PC9kaXY+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNiBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6e319LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8ZGl2IGlkPSYjMzk7c2llcnJhLWxpdG9yYWwmIzM5Oz48cCBjbGFzcz0mIzM5O3AxJiMzOTs+PGI+U0lFUlJBIExJVE9SQUw8L2I+PC9wPjxwIGNsYXNzPSYjMzk7cDImIzM5Oz5NQUNBQkVPOiBERSAwIEEgMjAwIE0sIFNVRUxPIEdSQVZBUywgTsOTRFVMT1MgREUgQ0FMSUNIRSwgUEVORElFTlRFUyBZIFNVRUxPUyBQT0JSRVMuPC9wPjxicj48aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvOTYzNGY5Yjg4OTAyNjE4MTU4MzllOGVmYzdhMGM5YTQuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPjwvZGl2PiJ9fSx7InR5cGUiOiJ3LTEtMSBwYi02IiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX1d'),
	(1047,27,'seo_resumen',''),
	(1048,27,'seo_checktitleonfreaturedimage','0'),
	(1049,27,'seo_customtitleonfreaturedimage',''),
	(1050,27,'seo_freaturedimage',''),
	(1051,27,'seo_noodp','0'),
	(1052,27,'seo_noydir','0'),
	(1053,27,'seo_nofollow','0'),
	(1054,27,'seo_noarchive','0'),
	(1055,27,'seo_keywords',''),
	(1056,27,'seo_description',''),
	(1057,27,'seo_customimage',''),
	(1118,0,'gallery_id','32'),
	(1179,28,'page_content','W3sidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcGItMyAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7cDEgdHh0QGMmIzM5Oz48Yj5WSVRJQ1VMVFVSQSBFQ09Mw5NHSUNBPC9iPjwvcD48cCBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PC9wPjxwIGNsYXNzPSYjMzk7cDEgdHh0QGMmIzM5Oz5QcmFjdGljYW1vcyB1bmEgYWdyaWN1bHR1cmEgbmF0dXJhbCwgc29zdGVuaWJsZSwgZWNvbMOzZ2ljYSB5IHJlc3BldHVvc2EgY29uIGVsIG1lZGlvIGFtYmllbnRlLjwvcD48cCBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PC9wPjxwIGNsYXNzPSYjMzk7cDEgdHh0QGMmIzM5Oz48Yj5WaXRpY3VsdHVyYSBlY29sw7NnaWNhPC9iPjwvcD48cCBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PC9wPjxwIGNsYXNzPSYjMzk7cDIgdHh0QGMmIzM5Oz5QcmFjdGljYW1vcyB1bmEgdml0aWN1bHR1cmEgc29zdGVuaWJsZSwgZWNvbMOzZ2ljYSB5IHJlc3BldHVvc2EgY29uIGVsIG1lZGlvIGFtYmllbnRlLCBwb3IgZXNvIHRyYWJhamFtb3MmbmJzcDs8YnI+bnVlc3Ryb3MgdmnDsWVkb3MgZXhjbHVzaXZhbWVudGUgY29uIHByb2R1Y3RvcyBlY29sw7NnaWNvcy48L3A+PHAgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjwvcD4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwYi0zICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50L2ZkZWU1NmUwZjJmMWUzYzk3MzBiMDViOWNjZmE5MDlmLmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwYi0zICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTtwMSB0eHRAYyYjMzk7PjxiPkNvbnRyb2xhbW9zIGxhIHByb2R1Y2Npw7NuPC9iPjwvcD48cCBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PC9wPjxwIGNsYXNzPSYjMzk7cDIgdHh0QGMmIzM5Oz5MaW1pdGFtb3MgbGEgcHJvZHVjY2nDs24gcGFyYSBhdW1lbnRhciBsYSBjb25jZW50cmFjacOzbiBkZSBudWVzdHJhcyB1dmFzLjwvcD48cCBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PC9wPjxwIGNsYXNzPSYjMzk7cDEgdHh0QGMmIzM5Oz48Yj48YnI+PC9iPjwvcD48cCBjbGFzcz0mIzM5O3AxIHR4dEBjJiMzOTs+PGI+UmVjb2xlY3RhZG8gYSBtYW5vPC9iPjwvcD48cCBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PC9wPjxwIGNsYXNzPSYjMzk7cDIgdHh0QGMmIzM5Oz5SZWNvbGVjdGFtb3MgeSBzZWxlY2Npb25hbW9zIG1hbnVhbG1lbnRlIHV2YSBhIHV2YSBwYXJhIGdhcmFudGl6YXIgc3UgY2FsaWRhZC48L3A+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcGItMyAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC8xMGRmY2EzNmYyMDQ2YmIyYzlmZDAwNmYxYWE0MjJiMC5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcGItMyAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7cDEgdHh0QGMmIzM5Oz48Yj5MYSBWZW5kw61taWE8L2I+PC9wPjxicj4gPHAgY2xhc3M9JiMzOTtwMiB0eHRAYyYjMzk7PkluaWNpYW1vcyBsYSB2ZW5kw61taWEgZW4gZWwgbW9tZW50byDDs3B0aW1vIGRlIG1hZHVyYWNpw7NuIGRlIGNhZGEgdmFyaWVkYWQsIHBhcmEgZ2FyYW50aXphciBlbCBlcXVpbGlicmlvIGRlIGxvcyBhcm9tYXMsIGF6w7pjYXJlcyB5IGFjaWRlei48L3A+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvZTNkMzA5YzQ1MmY3ZDVjODE0ZTU1ZGU2NDg5OTk1N2IuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJ3LTEtMSBwYi0zIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX1d'),
	(1180,28,'seo_resumen',''),
	(1181,28,'seo_checktitleonfreaturedimage','0'),
	(1182,28,'seo_customtitleonfreaturedimage',''),
	(1183,28,'seo_freaturedimage',''),
	(1184,28,'seo_noodp','0'),
	(1185,28,'seo_noydir','0'),
	(1186,28,'seo_nofollow','0'),
	(1187,28,'seo_noarchive','0'),
	(1188,28,'seo_keywords',''),
	(1189,28,'seo_description',''),
	(1190,28,'seo_customimage',''),
	(1203,29,'page_content','W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0mIzM5O3AxIHR4dEBjJiMzOTs+PGI+VkFSSUVEQURFUyBBVVTDk0NUT05BUzwvYj48L3A+PHAgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjwvcD48cCBjbGFzcz0mIzM5O3AxIHR4dEBjJiMzOTs+PGI+VmFyaWVkYWRlcyBhdXTDs2N0b25hcyB0cmFkaWNpb25hbGVzIGNlcGFzIHZpZWphczwvYj48L3A+PHAgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjwvcD48cCBjbGFzcz0mIzM5O3AxIHR4dEBjJiMzOTs+TWFudGVuZW1vcyBsYSBmaWRlbGlkYWQgYSBsYXMgdmFyaWVkYWRlcyBhdXTDs2N0b25hcyB0cmFkaWNpb25hbGVzOiBtYWNhYmVvLCB4YXJlbMK3bG8geSBwYXJlbGxhZGEsIGJhc2UgZGUgbnVlc3Ryb3MgY291cGFnZXMuPC9wPiJ9fSx7InR5cGUiOiJ3LTEtMSBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGhyPiJ9fSx7InR5cGUiOiJ3LTEtNCIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxhIGhyZWY9JiMzOTsjYXJ0aWN1bG8tbWFjYWJlbyYjMzk7IGRhdGEtc2xpZGV0bz0mIzM5OyYjMzk7IHJlbD0mIzM5O25vZm9sbG93JiMzOTs+PGI+TUFDQUJFTzwvYj48L2E+PC9wPjxhIGhyZWY9JiMzOTsjYXJ0aWN1bG8tMSYjMzk7IGRhdGEtc2xpZGV0bz0mIzM5OyYjMzk7IHJlbD0mIzM5O25vZm9sbG93JiMzOTs+PGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50Lzg1MDI4Y2FlYWI1NTQ3YTNiMjNkMTRmNDk5MjUyNDQxLmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7PjwvYT48cCBjbGFzcz0mIzM5O3AxIHR4dEBjJiMzOTs+PGEgaHJlZj0mIzM5OyNhcnRpY3Vsby0xJiMzOTsgZGF0YS1zbGlkZXRvPSYjMzk7JiMzOTsgcmVsPSYjMzk7bm9mb2xsb3cmIzM5Oz5GaW51cmEgeSBlbGVnYW5jaWE8L2E+PC9wPiJ9fSx7InR5cGUiOiJ3LTEtNCIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxhIGhyZWY9JiMzOTsjYXJ0aWN1bG8teGFyZWxsbyYjMzk7IHJlbD0mIzM5O25vZm9sbG93JiMzOTs+PGI+WEFSRUwuTE88L2I+PC9hPjwvcD48cCBjbGFzcz0mIzM5O3AxJiMzOTs+PGEgaHJlZj0mIzM5OyNhcnRpY3Vsby14YXJlbGxvJiMzOTsgcmVsPSYjMzk7bm9mb2xsb3cmIzM5Oz48aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvYzQ0Y2IzNGY3YzcwN2YzOTk1ODZiZmY2OWJiN2NjYjguanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PC9hPjwvcD48cCBjbGFzcz0mIzM5O3AxIHR4dEBjJiMzOTs+PGEgaHJlZj0mIzM5OyNhcnRpY3Vsby14YXJlbGxvJiMzOTsgcmVsPSYjMzk7bm9mb2xsb3cmIzM5Oz5DdWVycG8geSBlc3RydWN0dXJhPC9hPjwvcD4ifX0seyJ0eXBlIjoidy0xLTQiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48YSBocmVmPSYjMzk7I2FydGljdWxvLXBhcmVsbGFkYSYjMzk7IHJlbD0mIzM5O25vZm9sbG93JiMzOTs+PGI+UEFSRUxMQURBPC9iPjwvYT48L3A+PGEgaHJlZj0mIzM5OyNhcnRpY3Vsby1wYXJlbGxhZGEmIzM5OyByZWw9JiMzOTtub2ZvbGxvdyYjMzk7PjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC81ZjQ4MjAwYTk5MzM0MGM1ZWYzNmRiZjQ0N2M3NDg4MC5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48L2E+PHAgY2xhc3M9JiMzOTtwMSB0eHRAYyYjMzk7PjxhIGhyZWY9JiMzOTsjYXJ0aWN1bG8tcGFyZWxsYWRhJiMzOTsgcmVsPSYjMzk7bm9mb2xsb3cmIzM5Oz5Bcm9tYSB5IGFjaWRlejwvYT48L3A+In19LHsidHlwZSI6InctMS00IiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PGEgaHJlZj0mIzM5OyNhcnRpY3Vsby10cmVwYXQmIzM5OyByZWw9JiMzOTtub2ZvbGxvdyYjMzk7PjxiPlRSRVBBVDwvYj48L2E+PC9wPjxhIGhyZWY9JiMzOTsjYXJ0aWN1bG8tdHJlcGF0JiMzOTsgcmVsPSYjMzk7bm9mb2xsb3cmIzM5Oz48aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvZjA0MDk4MDhhYTQwOTYyN2IwNGM3MzQ2Mjc4ZDBjMGYuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PC9hPjxwIGNsYXNzPSYjMzk7cDEgdHh0QGMmIzM5Oz48YSBocmVmPSYjMzk7I2FydGljdWxvLXRyZXBhdCYjMzk7IHJlbD0mIzM5O25vZm9sbG93JiMzOTs+RmludXJhIHkgZWxlZ2FuY2lhPC9hPjwvcD4ifX0seyJ0eXBlIjoidy0xLTEgcGItNiIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6e319LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8ZGl2IGlkPSYjMzk7YXJ0aWN1bG8tbWFjYWJlbyYjMzk7PjxwIGNsYXNzPSYjMzk7cDEmIzM5Oz48Yj5NQUNBQkVPPC9iPjwvcD48cCBjbGFzcz0mIzM5O3AxJiMzOTs+PGI+RmludXJhIHkgZWxlZ2FuY2lhPC9iPjwvcD48cCBjbGFzcz0mIzM5O3AyJiMzOTs+RGUgbGEgem9uYSBsaXRvcmFsIGRlbCBHYXJyYWYgY29uIGFyb21hcyBhZnJ1dGFkb3MgeSBkZSBtYW56YW5hIHZlcmRlLCBhcG9ydGEgZmludXJhIHkgZWxlZ2FuY2lhIGFsIGN1cGFqZSBkZSBudWVzdHJvcyBjYXZhcy48L3A+PGJyPjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC84MDFiNzVhZWEzMjQ3ODk0YjYxZWMxYWI5NTJkYWVmYy5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+PGJyPjxwIGNsYXNzPSYjMzk7cDEmIzM5Oz48L3A+PHVsIGNsYXNzPSYjMzk7ZyBndy0xLTMmIzM5Oz48bGk+PGI+UGFpc2FqZTogU2l0Z2VzJm5ic3A7PGJyPjwvYj5TaWVycmEgTGl0b3JhbCAoTWFjaXpvIGRlbCBHYXJyYWYpPC9saT48bGk+PGI+QWx0aXR1ZDombmJzcDs8YnI+PC9iPkRlIDAgYSAyMDAgbTwvbGk+PGxpPjxiPlN1ZWxvOiZuYnNwOzxicj48L2I+R3JhdmFzLCBuw7NkdWxvcyBkZSBjYWxpY2hlLCBwZW5kaWVuZXRzLCBzdWVsb3MgcG9icmVzPC9saT48L3VsPjwvZGl2PiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxkaXYgaWQ9JiMzOTthcnRpY3Vsby14YXJlbGxvJiMzOTs+PHAgY2xhc3M9JiMzOTtwMSYjMzk7PjxiPlhBUkVMLkxPPC9iPjwvcD48cCBjbGFzcz0mIzM5O3AyJiMzOTs+PGI+Q3VlcnBvIHkgZXN0cnVjdHVyYTwvYj48L3A+PHAgY2xhc3M9JiMzOTtwMyYjMzk7PkEgMjAwIG0gZGUgYWx0aXR1ZCBlbiBsYSBkZXByZXNpw7NuIGRlbCBQZW5lZMOocywgZGUgY2Fyw6FjdGVyIG3DoXMgdmVnZXRhbCwgYXBvcnRhIGN1ZXJwbyB5IGVzdHJ1Y3R1cmEgYWwgY3VwYWplIGRlIG51ZXN0cm9zIGNhdmFzLjwvcD48YnI+PGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50LzkwOTZlOTJlYzJmMzlhMzA2YWZlNWQ3M2E5YmY4NjUxLmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj48YnI+PHAgY2xhc3M9JiMzOTtwMSYjMzk7PjwvcD48dWwgY2xhc3M9JiMzOTtnIGd3LTEtMyYjMzk7PjxsaT48Yj5QYWlzYWplOiZuYnNwOzxicj48L2I+TWFjaXpvIGRlIE1vbnRzZXJyYXQ8L2xpPjxsaT48Yj5BbHRpdHVkOiZuYnNwOzxicj48L2I+RW50cmUgMjAwIHkgNDAwIG08L2xpPjxsaT48Yj5TdWVsbzombmJzcDs8YnI+PC9iPkFyY2lsbGFzIGRlIHRpcG8gY2FsY8OhcmVvPC9saT48L3VsPjwvZGl2PiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxkaXYgaWQ9JiMzOTthcnRpY3Vsby1wYXJlbGxhZGEmIzM5Oz48cCBjbGFzcz0mIzM5O3AxJiMzOTs+PGI+UEFSRUxMQURBPC9iPjwvcD48cCBjbGFzcz0mIzM5O3AyJiMzOTs+PGI+QXJvbWEgeSBhY2lkZXo8L2I+PC9wPjxwIGNsYXNzPSYjMzk7cDMmIzM5Oz5FbiBlbCBBbHQgUGVuZWTDqHMsIGRlIHZpw7FlZG9zIHNpdHVhZG9zIGEgbcOhcyBkZSA0MDAgbSwgaW1wcmltZSBhbCB2aW5vIGFyb21hcyBhIGZydXRhIHRyb3BpY2FsLCBhcG9ydGFuZG8gYWNpZGV6IHkgZnJlc2NvciBhbCBjdXBhamUgZGUgbnVlc3Ryb3MgY2F2YXMuPC9wPjxicj48aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvMDk2MDFiZmFhMjY3YTE4MzY2OTU2ODQ0NmE4NDhhMGUuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPjxicj48cCBjbGFzcz0mIzM5O3AxJiMzOTs+PC9wPjx1bCBjbGFzcz0mIzM5O2cgZ3ctMS0zJiMzOTs+PGxpPjxiPlBhaXNhamU6Jm5ic3A7PGJyPjwvYj5DYXN0aWxsbyBkZSBNZWRpb25hLCBzLiBYSUlJPC9saT48bGk+PGI+QWx0aXR1ZDombmJzcDs8YnI+PC9iPkVudHJlIDQwMCB5IDkwMCBtPC9saT48bGk+PGI+U3VlbG86Jm5ic3A7PGJyPjwvYj5BcmVuaXRhcyB5IHBpemFycmFzPC9saT48L3VsPjwvZGl2PiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxkaXYgaWQ9JiMzOTthcnRpY3Vsby10cmVwYXQmIzM5Oz48cCBjbGFzcz0mIzM5O3AxJiMzOTs+PGI+VFJFUEFUPC9iPjwvcD48cCBjbGFzcz0mIzM5O3AyJiMzOTs+PGI+RmludXJhIHkgZnJlc2N1cmE8L2I+PC9wPjxwIGNsYXNzPSYjMzk7cDMmIzM5Oz5FbiBlbCBBbHQgUGVuZWTDqHMsIGRlIHZpw7FlZG9zIHNpdHVhZG9zIGEgbcOhcyBkZSA0MDAgbSwgY29uIGFyb21hcyBkZSBmcnV0b3Mgcm9qb3MgZG9uZGUgc29icmVzYWxlIGxhIGZyZXNhLCBhcG9ydGEgZmludXJhIHkgZnJlc2N1cmEgYSBudWVzdHJvIGNhdmEgcm9zYWRvLjwvcD48aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvZDI3ZmFjNDdiN2MwNmY4ZjhlY2IyZjA5ZWI3YjIzYmUuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPjxicj48cCBjbGFzcz0mIzM5O3AxJiMzOTs+PC9wPjx1bCBjbGFzcz0mIzM5O2cgZ3ctMS0zJiMzOTs+PGxpPjxiPlBhaXNhamU6PGJyPjwvYj5DYXN0aWxsbyBkZSBNZWRpb25hLCBzLiBYSUlJPC9saT48bGk+PGI+QWx0aXR1ZDo8YnI+PC9iPkVudHJlIDQwMCB5IDkwMCBtPC9saT48bGk+PGI+U3VlbG86PGJyPjwvYj5BcmVuaXRhcyB5IHBpemFycmFzPC9saT48L3VsPjwvZGl2PiJ9fSx7InR5cGUiOiJ3LTEtMSBwYi0zIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX1d'),
	(1204,29,'seo_resumen',''),
	(1205,29,'seo_checktitleonfreaturedimage','0'),
	(1206,29,'seo_customtitleonfreaturedimage',''),
	(1207,29,'seo_freaturedimage',''),
	(1208,29,'seo_noodp','0'),
	(1209,29,'seo_noydir','0'),
	(1210,29,'seo_nofollow','0'),
	(1211,29,'seo_noarchive','0'),
	(1212,29,'seo_keywords',''),
	(1213,29,'seo_description',''),
	(1214,29,'seo_customimage',''),
	(1299,30,'page_content','W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPkNSSUFOWkE8L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTtwMSYjMzk7PkVuIGxhIHByb2Z1bmRpZGFkIGRlIGxhcyBjYXZhcyAscHJvdGVnaWRhcyBkZSBsYSBsdXosIGNvbiB1bmEgaHVtZWRhZCB5IHRlbXBlcmF0dXJhIGNvbnN0YW50ZSwgc2UgcHJvZHVjZSBlbCBtaWxhZ3JvOiBlbiBjYWRhIGJvdGVsbGEgbmFjZXLDoW4gbGVudGEgeSBwYWNpZW50ZW1lbnRlIGxhcyBmaW5hcyBidXJidWphcyBxdWUgc2UgdHJhbnNmb3JtYW4gZW4gdW4gY2F2YSBjb21wbGVqbyB5IGV4Y2VwY2lvbmFsLiZuYnNwOzxicj48L3A+PHAgY2xhc3M9JiMzOTtwMSYjMzk7PkVsYWJvcmFtb3MgZXhjbHVzaXZhbWVudGUgUkVTRVJWQVMgeSBHUkFOIFJFU0VSVkFTIHBvcnF1ZSBzb2xvIGxhcyBsYXJnYXMgY3JpYW56YXMgYXBvcnRhbiBsYSBjb21wbGVqaWRhZCBkZWwgYm91cXVldCB5IGxhIGZpbmEgaW50ZWdyYWNpw7NuIGRlbCBjYXJiw7NuaWNvIGRlIG51ZXN0cm9zIGNhdmFzLjwvcD48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvNGJkMjhiMmE4MGYzZDNhOWIwOTU5NDI0MWM4ODVkNTUuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJ3LTEtMSBwYi02IiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX1d'),
	(1300,30,'seo_resumen',''),
	(1301,30,'seo_checktitleonfreaturedimage','0'),
	(1302,30,'seo_customtitleonfreaturedimage',''),
	(1303,30,'seo_freaturedimage',''),
	(1304,30,'seo_noodp','0'),
	(1305,30,'seo_noydir','0'),
	(1306,30,'seo_nofollow','0'),
	(1307,30,'seo_noarchive','0'),
	(1308,30,'seo_keywords',''),
	(1309,30,'seo_description',''),
	(1310,30,'seo_customimage',''),
	(1335,31,'page_content','W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPkRFR8OcRUxMRTwvYj48L2gxPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiJUcmFzIGHDsW9zIGRlIGNyaWFuemEgZWwgZGVnw7xlbGxlIGVzIGVsIG1vbWVudG8gZmluYWwgZW4gcXVlIHNlIGRlc2NvcmNoYSBsYSBib3RlbGxhIHBhcmEgZWxpbWluYXIgbGFzIGzDrWFzLiBFc3RhIG1pc21hIGJvdGVsbGEgZXMgbGEgcXVlIGxsZWdhcsOhIGEgbGEgbWVzYSBkZWwgY29uc3VtaWRvci5MYSBmZWNoYSBkZSBkZWfDvGVsbGUgaW1wcmVzYSBlbiBjYWRhIGV0aXF1ZXRhLCBlcyBsYSBpbmZvcm1hY2nDs24gaW1wcmVzY2luZGlibGUgcGFyYSBjb25vY2VyIGVsIG1vbWVudG8gZW4gcXVlIGhhIGZpbmFsaXphZG8gbGEgY3JpYW56YS4gRWwgY2F2YSBlc3RhcsOhIGEgcGFydGlyIGRlIGVudG9uY2VzIGVuIMOzcHRpbWFzIGNvbmRpY2lvbmVzIHBhcmEgc3UgZGVndXN0YWNpw7NuIDxicj48YnI+PGI+Q2FkYSBib3RlbGxhLCB1biBjb21wcm9taXNvIHBlcnNvbmFsPC9iPjxicj48YnI+TnVlc3Ryb3MgY2F2YXMgc29uIGxhIGV4cHJlc2nDs24gZGUgdW5hIHV2YSwgdW4gdGVycml0b3JpbyB5IHVuYSBhw7FhZGEuIFBvciBlc28sIHRvZGFzIG51ZXN0cmFzIGJvdGVsbGFzIGxsZXZhbiBlbCBhw7FvIGRlIGNvc2VjaGEgeSBsYSBmZWNoYSBkZSBkZWfDvGVsbGUuLiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvMWFlYTI0OGQ2NDQwMjQyZjk1MDI0YWJhYTcyNzA3ZjQuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJ3LTEtMSBwYi02IiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX1d'),
	(1336,31,'seo_resumen',''),
	(1337,31,'seo_checktitleonfreaturedimage','0'),
	(1338,31,'seo_customtitleonfreaturedimage',''),
	(1339,31,'seo_freaturedimage',''),
	(1340,31,'seo_noodp','0'),
	(1341,31,'seo_noydir','0'),
	(1342,31,'seo_nofollow','0'),
	(1343,31,'seo_noarchive','0'),
	(1344,31,'seo_keywords',''),
	(1345,31,'seo_description',''),
	(1346,31,'seo_customimage',''),
	(1359,32,'page_content','W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPlZJTk9TPC9iPjwvaDE+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcGItMyAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48Yj5YSUM8L2I+PGJyPjxicj5Kb3ZlbiwgZnJlc2NvIHkgYWZydXRhZG8sIGVzIHVuIFhhcmVswrdsbyBmZXJtZW50YWRvIGEgMTbCuiB5IGNyaWFuemEgZGUgNjAgZMOtYXMgZW4gc3VzIGzDrWFzLiBVbiBqb3ZlbiBkZWwgYcOxbzwvcD4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwYi0zICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGRpdiBjbGFzcz0mIzM5O21jJiMzOTs+PGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50LzJkOWFiNTU3N2QzMTMwMDU3Yzg5YmU1Nzg1ZDA1ZmRlLmpwZyYjMzk7IGNsYXNzPSYjMzk7bWMgZGlzcCYjMzk7PjwvZGl2PiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PGI+QVBUScOAPC9iPjxicj48YnI+VmlubyBkZSBjcmlhbnphLCBjaWVuIHBvciBjaWVuIE1hY2FiZW8gZmVybWVudGFkbyBlbiBiYXJyaWNhcyBudWV2YXMgZGUgcm9ibGUgZnJhbmPDqXMuPC9wPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvYzM4NmJjYjhmMjJiNDRlZmQ1YWY4NjBkMjBjYjFjMzAuanBnJiMzOTsgY2xhc3M9JiMzOTttYyBkaXNwJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJ3LTEtMSBwYi02IiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX1d'),
	(1360,32,'seo_resumen',''),
	(1361,32,'seo_checktitleonfreaturedimage','0'),
	(1362,32,'seo_customtitleonfreaturedimage',''),
	(1363,32,'seo_freaturedimage',''),
	(1364,32,'seo_noodp','0'),
	(1365,32,'seo_noydir','0'),
	(1366,32,'seo_nofollow','0'),
	(1367,32,'seo_noarchive','0'),
	(1368,32,'seo_keywords',''),
	(1369,32,'seo_description',''),
	(1370,32,'seo_customimage',''),
	(1503,33,'page_content','W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPkVMQUJPUkFDScOTTiBERSBMT1MgVklOT1M8L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiUmVhbGl6YW1vcyB1biBwcmVuc2FkbyBzdWF2ZSB5IGVuIHBlcXVlw7FvcyBkZXDDs3NpdG9zLCB2aW5pZmljYW1vcyBwb3Igc2VwYXJhZG8gY2FkYSB2YXJpZWRhZCBkZSBjYWRhIHBhcmNlbGEgcGFyYSBwZXJzb25hbGl6YXIgY2FkYSB1bm8gZGUgbnVlc3Ryb3Mgdmlub3MuPGJyPjxicj5EdXJhbnRlIDMgbWVzZXMgbG9zIHZpbm9zIHZhbiBtYWR1cmFuZG8gZW4gbnVlc3Ryb3MgZGVww7NzaXRvcyBhIHRlbXBlcmF0dXJhIGNvbnRyb2xhZGEuIn19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvOWNhZmQ2NDhjOGFkY2NhNTI5YzE1Y2YxNjY1MzJmNWMuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJ3LTEtMSBwYi02IiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX1d'),
	(1504,33,'seo_resumen',''),
	(1505,33,'seo_checktitleonfreaturedimage','0'),
	(1506,33,'seo_customtitleonfreaturedimage',''),
	(1507,33,'seo_freaturedimage',''),
	(1508,33,'seo_noodp','0'),
	(1509,33,'seo_noydir','0'),
	(1510,33,'seo_nofollow','0'),
	(1511,33,'seo_noarchive','0'),
	(1512,33,'seo_keywords',''),
	(1513,33,'seo_description',''),
	(1514,33,'seo_customimage',''),
	(1528,34,'page_content','W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPkNVUEFKRVM8L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwYi0zICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTtwMSYjMzk7PkxhIGV4cGVyaWVuY2lhIGRlbCBlbsOzbG9nbyBlcyBsYSBwaWVkcmEgYW5ndWxhciBwYXJhIGNvbnNlZ3VpciBsYSBidWVuYSBjb21iaW5hY2nDs24gZGUgbG9zIDMgdmlub3MsIE1hY2FiZW8sIFhhcmVswrdsbywgUGFyZWxsYWRhLiBFc3RlIGNvcGFqZSBkZXRlcm1pbmFyw6EgbGEgcGVyc29uYWxpZGFkIGRlIG51ZXN0cm9zIGZ1dHVyb3MgY2F2YXMuPC9wPjxicj4ifX0seyJ0eXBlIjoidy0xLTEgcGItNiIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6e319XQ=='),
	(1529,34,'seo_resumen',''),
	(1530,34,'seo_checktitleonfreaturedimage','0'),
	(1531,34,'seo_customtitleonfreaturedimage',''),
	(1532,34,'seo_freaturedimage',''),
	(1533,34,'seo_noodp','0'),
	(1534,34,'seo_noydir','0'),
	(1535,34,'seo_nofollow','0'),
	(1536,34,'seo_noarchive','0'),
	(1537,34,'seo_keywords',''),
	(1538,34,'seo_description',''),
	(1539,34,'seo_customimage','');

/*!40000 ALTER TABLE `pages_meta` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla pages_types
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pages_types`;

CREATE TABLE `pages_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `tmpl_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `pages_types` WRITE;
/*!40000 ALTER TABLE `pages_types` DISABLE KEYS */;

INSERT INTO `pages_types` (`id`, `title`, `tmpl_name`)
VALUES
	(1,'Página','pages_details'),
	(2,'Articulo',NULL),
	(3,'Blog - post',NULL),
	(4,'Faq',NULL),
	(5,'Actualidad',NULL),
	(6,'Home','home'),
	(7,'Producto - Cuadrícula','product_grid');

/*!40000 ALTER TABLE `pages_types` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla product
# ------------------------------------------------------------

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order` int(11) DEFAULT '0',
  `cat_id` int(11) DEFAULT NULL,
  `lang_data` text,
  `active` int(11) DEFAULT NULL,
  `menu_title` varchar(100) DEFAULT NULL,
  `hash` varchar(255) DEFAULT '',
  `gallery_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;

INSERT INTO `product` (`id`, `order`, `cat_id`, `lang_data`, `active`, `menu_title`, `hash`, `gallery_id`)
VALUES
	(1,0,23,'{\"es\":\"S&ograve;lid Blanc\",\"en\":\"S&ograve;lid Blanc\",\"ca\":\"S&ograve;lid Blanc\"}',1,'Sòlid Blanc','solid-blanc',2),
	(2,1,23,'{\"es\":\"S&ograve;lid Rosat\",\"en\":\"S&ograve;lid Rosat\",\"ca\":\"S&ograve;lid Rosat\"}',1,'SÒLID ROSAT','solid-rosat',3),
	(3,0,NULL,'{\"es\":\"Bals&aacute;micos de cava\",\"en\":\"Bals&aacute;micos de cava\",\"ca\":\"Bals&aacute;micos de cava\"}',1,'BALSÁMICOS DE CAVA','balsamicos-de-cava',5),
	(4,0,NULL,'{\"es\":\"Sec de Cava\",\"en\":\"Sec de Cava\",\"ca\":\"Sec de Cava\"}',1,'SEC DE CAVA','sec-de-cava',4),
	(5,0,24,'{\"es\":\"Marc de Cava  L\'Esperit\",\"en\":\"Marc de Cava  L\'Esperit\",\"ca\":\"Marc de Cava  L\'Esperit\"}',1,'Marc de Cava L’ESPERIT','marc-de-cava-lesperit',6),
	(6,0,NULL,'{\"es\":\"Xic\",\"en\":\"Xic\",\"ca\":\"Xic\"}',1,'XIC','xic',7),
	(7,0,NULL,'{\"es\":\"Apti&agrave;\",\"en\":\"Apti&agrave;\",\"ca\":\"Apti&agrave;\"}',1,'APTIÀ','aptia',8),
	(8,0,NULL,'{\"es\":\"Kripta 2007 40 aniversari\",\"en\":\"Kripta 2007\",\"ca\":\"Kripta 2007\"}',1,'KRIPTA 2007 40 aniversari','kripta-2007',9),
	(9,0,NULL,'{\"es\":\"Kripta\",\"en\":\"Kripta\",\"ca\":\"Kripta\"}',1,'KRIPTA','kripta',10),
	(10,0,NULL,'{\"es\":\"Magnum Gran Reserva\",\"en\":\"Magnum Gran Reserva\",\"ca\":\"Magnum Gran Reserva\"}',1,'MAGNUM GRAN RESERVA','magnum-gran-reserva',11),
	(11,0,NULL,'{\"es\":\"Gran Reserva Barrica\",\"en\":\"Gran Reserva Barrica\",\"ca\":\"Gran Reserva Barrica\"}',1,'GRAN RESERVA BARRICA','gran-reserva-barrica',12),
	(12,0,NULL,'{\"es\":\"Brut Nature Gran Reserva\",\"en\":\"Brut Nature Gran Reserva\",\"ca\":\"Brut Nature Gran Reserva\"}',1,'BRUT NATURE GRAN RESERVA','brut-nature-gran-reserva',13),
	(13,0,NULL,'{\"es\":\"Brut Gran Reserva\",\"en\":\"Brut Gran Reserva\",\"ca\":\"Brut Gran Reserva\"}',1,'BRUT GRAN RESERVA','brut-gran-reserva',14),
	(14,0,NULL,'{\"es\":\"Brut Reserva\",\"en\":\"Brut Reserva\",\"ca\":\"Brut Reserva\"}',1,'BRUT RESERVA','brut-reserva',15),
	(15,0,NULL,'{\"es\":\"Rosat Trepat\",\"en\":\"Rosat Trepat\",\"ca\":\"Rosat Trepat\"}',1,'ROSAT TREPAT','rosat-trepat',16),
	(16,8,NULL,'{\"es\":\"375 Brut Gran Reserva\",\"en\":\"375 Brut Gran Reserva\",\"ca\":\"375 Brut Gran Reserva\"}',1,'375 BRUT GRAN RESERVA','375-brut-gran-reserva',17),
	(17,9,NULL,'{\"es\":\"375 Rosat Trepat\",\"en\":\"375 Rosat Trepat\",\"ca\":\"375 Rosat Trepat\"}',1,'375 ROSAT TREPAT','375-rosat-trepat',18);

/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla product_color
# ------------------------------------------------------------

DROP TABLE IF EXISTS `product_color`;

CREATE TABLE `product_color` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang_data` text,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `product_color` WRITE;
/*!40000 ALTER TABLE `product_color` DISABLE KEYS */;

INSERT INTO `product_color` (`id`, `lang_data`, `order`)
VALUES
	(12,'{\"es\":\"-sin especificaci&oacute;n-\",\"en\":\"-without specification-\",\"ca\":\"-sense especificaci&oacute;n-\"}',NULL);

/*!40000 ALTER TABLE `product_color` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla product_meta
# ------------------------------------------------------------

DROP TABLE IF EXISTS `product_meta`;

CREATE TABLE `product_meta` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `p_id` int(11) DEFAULT NULL,
  `m_key` varchar(250) DEFAULT NULL,
  `m_value` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `p_id` (`p_id`,`m_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `product_meta` WRITE;
/*!40000 ALTER TABLE `product_meta` DISABLE KEYS */;

INSERT INTO `product_meta` (`id`, `p_id`, `m_key`, `m_value`)
VALUES
	(1,8,'page_is_link','content/dabe15cd3493c251afc06bc06fcc226a.pdf'),
	(2,8,'lang_content','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(3,8,'lang_envio_extra','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(4,8,'show_button_addcart','0'),
	(6,8,'seo_noodp','0'),
	(7,8,'seo_noydir','0'),
	(8,8,'seo_nofollow','0'),
	(9,8,'seo_noarchive','0'),
	(10,8,'seo_keywords',''),
	(11,8,'seo_description',''),
	(12,8,'seo_customimage',''),
	(13,9,'lang_content','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(14,9,'lang_envio_extra','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(15,9,'show_button_addcart','0'),
	(16,9,'page_is_link','content/16a07adb5b396d5dafa7560b28d61c2b.pdf'),
	(17,9,'seo_noodp','0'),
	(18,9,'seo_noydir','0'),
	(19,9,'seo_nofollow','0'),
	(20,9,'seo_noarchive','0'),
	(21,9,'seo_keywords',''),
	(22,9,'seo_description',''),
	(23,9,'seo_customimage',''),
	(24,10,'lang_content','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(25,10,'lang_envio_extra','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(26,10,'show_button_addcart','0'),
	(27,10,'page_is_link','content/64aa75e7673d3133d1e578bd9b7828f5.pdf'),
	(28,10,'seo_noodp','0'),
	(29,10,'seo_noydir','0'),
	(30,10,'seo_nofollow','0'),
	(31,10,'seo_noarchive','0'),
	(32,10,'seo_keywords',''),
	(33,10,'seo_description',''),
	(34,10,'seo_customimage',''),
	(35,11,'lang_content','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(36,11,'lang_envio_extra','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(37,11,'show_button_addcart','0'),
	(38,11,'page_is_link','content/31a7782884f18159680dea1d80a74a10.pdf'),
	(39,11,'seo_noodp','0'),
	(40,11,'seo_noydir','0'),
	(41,11,'seo_nofollow','0'),
	(42,11,'seo_noarchive','0'),
	(43,11,'seo_keywords',''),
	(44,11,'seo_description',''),
	(45,11,'seo_customimage',''),
	(46,12,'lang_content','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(47,12,'lang_envio_extra','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(48,12,'show_button_addcart','0'),
	(49,12,'page_is_link','content/4072de9b75548f5b8fd591f6273e0424.pdf'),
	(50,12,'seo_noodp','0'),
	(51,12,'seo_noydir','0'),
	(52,12,'seo_nofollow','0'),
	(53,12,'seo_noarchive','0'),
	(54,12,'seo_keywords',''),
	(55,12,'seo_description',''),
	(56,12,'seo_customimage',''),
	(57,13,'lang_content','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(58,13,'lang_envio_extra','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(59,13,'show_button_addcart','0'),
	(60,13,'page_is_link','content/ef5ce2fbf5c65bd1ef38b639dd7327ef.pdf'),
	(61,13,'seo_noodp','0'),
	(62,13,'seo_noydir','0'),
	(63,13,'seo_nofollow','0'),
	(64,13,'seo_noarchive','0'),
	(65,13,'seo_keywords',''),
	(66,13,'seo_description',''),
	(67,13,'seo_customimage',''),
	(68,14,'lang_content','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(69,14,'lang_envio_extra','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(70,14,'show_button_addcart','0'),
	(71,14,'page_is_link','content/37198b4a2fb4df345c83d021a3498aee.pdf'),
	(72,14,'seo_noodp','0'),
	(73,14,'seo_noydir','0'),
	(74,14,'seo_nofollow','0'),
	(75,14,'seo_noarchive','0'),
	(76,14,'seo_keywords',''),
	(77,14,'seo_description',''),
	(78,14,'seo_customimage',''),
	(79,15,'lang_content','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(80,15,'lang_envio_extra','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(81,15,'show_button_addcart','0'),
	(82,15,'page_is_link','content/396520cc76b611a92b978bba1889eed5.pdf'),
	(83,15,'seo_noodp','0'),
	(84,15,'seo_noydir','0'),
	(85,15,'seo_nofollow','0'),
	(86,15,'seo_noarchive','0'),
	(87,15,'seo_keywords',''),
	(88,15,'seo_description',''),
	(89,15,'seo_customimage',''),
	(90,6,'lang_content','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(91,6,'lang_envio_extra','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(92,6,'show_button_addcart','0'),
	(93,6,'page_is_link','content/0856ac2570412ad0bb4d470c28a5b502.pdf'),
	(94,6,'seo_noodp','0'),
	(95,6,'seo_noydir','0'),
	(96,6,'seo_nofollow','0'),
	(97,6,'seo_noarchive','0'),
	(98,6,'seo_keywords',''),
	(99,6,'seo_description',''),
	(100,6,'seo_customimage',''),
	(101,7,'lang_content','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(102,7,'lang_envio_extra','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(103,7,'show_button_addcart','0'),
	(104,7,'page_is_link','content/e0558260da2703d4dc5ab612dabf8eb5.pdf'),
	(105,7,'seo_noodp','0'),
	(106,7,'seo_noydir','0'),
	(107,7,'seo_nofollow','0'),
	(108,7,'seo_noarchive','0'),
	(109,7,'seo_keywords',''),
	(110,7,'seo_description',''),
	(111,7,'seo_customimage',''),
	(134,5,'lang_content','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(135,5,'lang_envio_extra','{\"es\":\"\",\"en\":\"\",\"ca\":\"\"}'),
	(136,5,'show_button_addcart','0'),
	(137,5,'page_is_link',''),
	(138,5,'seo_noodp','0'),
	(139,5,'seo_noydir','0'),
	(140,5,'seo_nofollow','0'),
	(141,5,'seo_noarchive','0'),
	(142,5,'seo_keywords',''),
	(143,5,'seo_description',''),
	(144,5,'seo_customimage','');

/*!40000 ALTER TABLE `product_meta` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla product_size
# ------------------------------------------------------------

DROP TABLE IF EXISTS `product_size`;

CREATE TABLE `product_size` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang_data` text,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `product_size` WRITE;
/*!40000 ALTER TABLE `product_size` DISABLE KEYS */;

INSERT INTO `product_size` (`id`, `lang_data`, `order`)
VALUES
	(8,'{\"es\":\"-sin especificaci&oacute;n-\",\"en\":\"-without specification-\",\"ca\":\"-sense especificaci&oacute;n-\"}',NULL);

/*!40000 ALTER TABLE `product_size` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla product_stock
# ------------------------------------------------------------

DROP TABLE IF EXISTS `product_stock`;

CREATE TABLE `product_stock` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `prid` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT '0',
  `color_id` int(11) DEFAULT '0',
  `gallery_id` int(11) DEFAULT NULL,
  `precio_coste` float DEFAULT NULL,
  `precio_tachado` float DEFAULT NULL,
  `precio_venta` float DEFAULT NULL,
  `stock_min` int(11) DEFAULT NULL,
  `stock_base` int(11) DEFAULT NULL,
  `stock_count` int(11) DEFAULT NULL,
  `peso` float DEFAULT NULL,
  `size_y` int(11) DEFAULT NULL COMMENT 'arriba-abajo',
  `size_x` int(11) DEFAULT NULL COMMENT 'izq-der',
  `item_base` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `prid` (`prid`,`size_id`,`color_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `product_stock` WRITE;
/*!40000 ALTER TABLE `product_stock` DISABLE KEYS */;

INSERT INTO `product_stock` (`id`, `prid`, `size_id`, `color_id`, `gallery_id`, `precio_coste`, `precio_tachado`, `precio_venta`, `stock_min`, `stock_base`, `stock_count`, `peso`, `size_y`, `size_x`, `item_base`)
VALUES
	(1,1,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(2,2,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(3,3,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(4,4,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(5,5,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(6,6,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(7,7,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(8,8,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(9,9,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(10,10,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(11,11,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(12,12,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(13,13,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(14,14,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(15,15,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(16,16,8,12,NULL,0,0,0,0,0,0,0,0,0,1),
	(17,17,8,12,NULL,0,0,0,0,0,0,0,0,0,1);

/*!40000 ALTER TABLE `product_stock` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla user_type
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_type`;

CREATE TABLE `user_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `user_type` WRITE;
/*!40000 ALTER TABLE `user_type` DISABLE KEYS */;

INSERT INTO `user_type` (`id`, `title`, `level`)
VALUES
	(1,'Default',1),
	(2,'Comprador',15),
	(11,'Creator (superadmin)',100);

/*!40000 ALTER TABLE `user_type` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(60) NOT NULL DEFAULT '',
  `user_pass` text NOT NULL,
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_registred` datetime DEFAULT NULL,
  `user_activation_key` varchar(65) NOT NULL DEFAULT '',
  `user_status` int(3) NOT NULL DEFAULT '0',
  `user_add_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `user_email` (`user_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`ID`, `user_name`, `user_pass`, `user_email`, `user_registred`, `user_activation_key`, `user_status`, `user_add_date`)
VALUES
	(9999,'211','0138db6833e72a16271aba2ca4f179bc8225ef9b5eb879d1177db6271ffd29ea218be5472f9415aa84a7c93fc7349308d06ad460cfe490eb14198b69f6874fa5','hello@dm211.com','0000-00-00 00:00:00','bcc2a152c5cd79ed342f02614cb6dc49',1,'2019-02-15 20:51:48'),
	(10000,'admin-albert','8fb43acb896a9780b574df4dfcdaa079db9ab93a722966dd394af822d4772f47e73188ebded070e24bfa03cf649174e6011ca4eacee99a7281b77d1f84f3b862','albertventosadesign@gmail.com',NULL,'',1,'2019-04-03 11:54:06');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla users_login_ban
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users_login_ban`;

CREATE TABLE `users_login_ban` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `isBanned` int(11) DEFAULT '0',
  `u_ip` varchar(50) DEFAULT NULL,
  `count_attempt` int(11) DEFAULT NULL,
  `time_sep` timestamp NULL DEFAULT NULL,
  `ban_time` timestamp NULL DEFAULT NULL,
  `u_name` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Volcado de tabla users_meta
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users_meta`;

CREATE TABLE `users_meta` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `meta_key` varchar(65) NOT NULL DEFAULT '',
  `meta_value` text NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `user_id` (`user_id`,`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `users_meta` WRITE;
/*!40000 ALTER TABLE `users_meta` DISABLE KEYS */;

INSERT INTO `users_meta` (`ID`, `user_id`, `meta_key`, `meta_value`)
VALUES
	(1,9999,'user_level','100'),
	(2,9999,'user_access','1'),
	(5,10000,'user_access','1'),
	(6,10000,'user_level','100');

/*!40000 ALTER TABLE `users_meta` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla users_status
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users_status`;

CREATE TABLE `users_status` (
  `ID` bigint(9) NOT NULL AUTO_INCREMENT,
  `user_status` int(3) NOT NULL,
  `status_value` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `users_status` WRITE;
/*!40000 ALTER TABLE `users_status` DISABLE KEYS */;

INSERT INTO `users_status` (`ID`, `user_status`, `status_value`)
VALUES
	(1,0,'No activo'),
	(2,1,'Activo'),
	(3,2,'Baneado'),
	(4,3,'Eliminado');

/*!40000 ALTER TABLE `users_status` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
