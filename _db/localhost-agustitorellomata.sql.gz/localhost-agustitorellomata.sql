-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Servidor: 10.200.2.15
-- Tiempo de generación: 24-09-2020 a las 11:08:53
-- Versión del servidor: 10.1.45-MariaDB-0+deb9u1
-- Versión de PHP: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `torelloweb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `apps_countries`
--

CREATE TABLE IF NOT EXISTS `apps_countries` (
  `id` int(11) NOT NULL,
  `country_code` varchar(4) NOT NULL DEFAULT '',
  `country_name` varchar(100) NOT NULL DEFAULT '',
  `active` int(2) DEFAULT '0',
  `order` int(2) DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=253 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `apps_countries`
--

INSERT INTO `apps_countries` (`id`, `country_code`, `country_name`, `active`, `order`) VALUES
(1, 'AF', 'Afghanistan', 0, 0),
(2, 'AL', 'Albania', 0, 0),
(4, 'DS', 'American Samoa', 0, 0),
(6, 'AO', 'Angola', 0, 0),
(7, 'AI', 'Anguilla', 0, 0),
(9, 'AG', 'Antigua and Barbuda', 0, 0),
(10, 'AR', 'Argentina', 0, 0),
(11, 'AM', 'Armenia', 0, 0),
(12, 'AW', 'Aruba', 0, 0),
(13, 'AU', 'Australia', 0, 0),
(14, 'AT', 'Austria', 1, 0),
(15, 'AZ', 'Azerbaijan', 0, 0),
(16, 'BS', 'Bahamas', 0, 0),
(17, 'BH', 'Bahrain', 0, 0),
(18, 'BD', 'Bangladesh', 0, 0),
(19, 'BB', 'Barbados', 0, 0),
(20, 'BY', 'Belarus', 0, 0),
(21, 'BE', 'Belgium', 1, 0),
(22, 'BZ', 'Belize', 0, 0),
(23, 'BJ', 'Benin', 0, 0),
(24, 'BM', 'Bermuda', 0, 0),
(25, 'BT', 'Bhutan', 0, 0),
(26, 'BO', 'Bolivia', 0, 0),
(27, 'BA', 'Bosnia and Herzegovina', 1, 0),
(28, 'BW', 'Botswana', 0, 0),
(30, 'BR', 'Brazil', 0, 0),
(32, 'BN', 'Brunei Darussalam', 0, 0),
(33, 'BG', 'Bulgaria', 1, 0),
(34, 'BF', 'Burkina Faso', 0, 0),
(35, 'BI', 'Burundi', 0, 0),
(37, 'CM', 'Cameroon', 0, 0),
(38, 'CA', 'Canada', 0, 0),
(39, 'CV', 'Cape Verde', 0, 0),
(40, 'KY', 'Cayman Islands', 0, 0),
(42, 'TD', 'Chad', 0, 0),
(43, 'CL', 'Chile', 0, 0),
(44, 'CN', 'China', 0, 0),
(47, 'CO', 'Colombia', 0, 0),
(48, 'KM', 'Comoros', 0, 0),
(49, 'CG', 'Congo', 0, 0),
(50, 'CK', 'Cook Islands', 0, 0),
(51, 'CR', 'Costa Rica', 0, 0),
(52, 'HR', 'Croatia (Hrvatska)', 1, 0),
(53, 'CU', 'Cuba', 0, 0),
(54, 'CY', 'Cyprus', 1, 0),
(55, 'CZ', 'Czech Republic', 1, 0),
(56, 'DK', 'Denmark', 1, 0),
(57, 'DJ', 'Djibouti', 0, 0),
(58, 'DM', 'Dominica', 0, 0),
(59, 'DO', 'Dominican Republic', 0, 0),
(60, 'TP', 'East Timor', 0, 0),
(61, 'EC', 'Ecuador', 0, 0),
(62, 'EG', 'Egypt', 0, 0),
(63, 'SV', 'El Salvador', 0, 0),
(64, 'GQ', 'Equatorial Guinea', 0, 0),
(65, 'ER', 'Eritrea', 0, 0),
(66, 'EE', 'Estonia', 1, 0),
(69, 'FO', 'Faroe Islands', 0, 0),
(70, 'FJ', 'Fiji', 0, 0),
(71, 'FI', 'Finland', 1, 0),
(72, 'FR', 'France', 1, 0),
(74, 'GF', 'French Guiana', 0, 0),
(75, 'PF', 'French Polynesia', 0, 0),
(77, 'GA', 'Gabon', 0, 0),
(78, 'GM', 'Gambia', 0, 0),
(79, 'GE', 'Georgia', 0, 0),
(80, 'DE', 'Germany', 1, 0),
(81, 'GH', 'Ghana', 0, 0),
(83, 'GK', 'Guernsey', 0, 0),
(84, 'GR', 'Greece', 1, 0),
(85, 'GL', 'Greenland', 0, 0),
(87, 'GP', 'Guadeloupe', 0, 0),
(88, 'GU', 'Guam', 0, 0),
(89, 'GT', 'Guatemala', 0, 0),
(90, 'GN', 'Guinea', 0, 0),
(91, 'GW', 'Guinea-Bissau', 0, 0),
(93, 'HT', 'Haiti', 0, 0),
(95, 'HN', 'Honduras', 0, 0),
(96, 'HK', 'Hong Kong', 0, 0),
(97, 'HU', 'Hungary', 1, 0),
(98, 'IS', 'Iceland', 1, 0),
(99, 'IN', 'India', 0, 0),
(100, 'IM', 'Isle of Man', 0, 0),
(101, 'ID', 'Indonesia', 0, 0),
(102, 'IR', 'Iran (Islamic Republic of)', 0, 0),
(103, 'IQ', 'Iraq', 0, 0),
(104, 'IE', 'Ireland', 1, 0),
(105, 'IL', 'Israel', 1, 0),
(106, 'IT', 'Italy', 1, 0),
(107, 'CI', 'Ivory Coast', 0, 0),
(108, 'JE', 'Jersey', 0, 0),
(109, 'JM', 'Jamaica', 0, 0),
(110, 'JP', 'Japan', 0, 0),
(111, 'JO', 'Jordan', 0, 0),
(112, 'KZ', 'Kazakhstan', 0, 0),
(113, 'KE', 'Kenya', 0, 0),
(118, 'KW', 'Kuwait', 0, 0),
(120, 'LA', 'Lao People''s Democratic Republic', 0, 0),
(121, 'LV', 'Latvia', 1, 0),
(122, 'LB', 'Lebanon', 0, 0),
(123, 'LS', 'Lesotho', 0, 0),
(124, 'LR', 'Liberia', 0, 0),
(125, 'LY', 'Libyan Arab Jamahiriya', 0, 0),
(126, 'LI', 'Liechtenstein', 1, 0),
(127, 'LT', 'Lithuania', 1, 0),
(128, 'LU', 'Luxembourg', 1, 0),
(129, 'MO', 'Macau', 0, 0),
(130, 'MK', 'Macedonia', 1, 0),
(131, 'MG', 'Madagascar', 0, 0),
(132, 'MW', 'Malawi', 0, 0),
(133, 'MY', 'Malaysia', 0, 0),
(134, 'MV', 'Maldives', 0, 0),
(135, 'ML', 'Mali', 0, 0),
(136, 'MT', 'Malta', 1, 0),
(137, 'MH', 'Marshall Islands', 0, 0),
(139, 'MR', 'Mauritania', 0, 0),
(140, 'MU', 'Mauritius', 0, 0),
(141, 'TY', 'Mayotte', 0, 0),
(142, 'MX', 'Mexico', 0, 0),
(143, 'FM', 'Micronesia, Federated States of', 0, 0),
(144, 'MD', 'Moldova, Republic of', 0, 0),
(145, 'MC', 'Monaco', 1, 0),
(146, 'MN', 'Mongolia', 0, 0),
(147, 'ME', 'Montenegro', 1, 0),
(149, 'MA', 'Morocco', 0, 0),
(150, 'MZ', 'Mozambique', 0, 0),
(152, 'NA', 'Namibia', 0, 0),
(154, 'NP', 'Nepal', 0, 0),
(156, 'AN', 'Netherlands Antilles', 1, 0),
(158, 'NZ', 'New Zealand', 1, 0),
(159, 'NI', 'Nicaragua', 0, 0),
(160, 'NE', 'Niger', 0, 0),
(161, 'NG', 'Nigeria', 0, 0),
(165, 'NO', 'Norway', 1, 0),
(166, 'OM', 'Oman', 0, 0),
(167, 'PK', 'Pakistan', 0, 0),
(168, 'PW', 'Palau', 0, 0),
(169, 'PS', 'Palestine', 0, 0),
(170, 'PA', 'Panama', 0, 0),
(172, 'PY', 'Paraguay', 0, 0),
(173, 'PE', 'Peru', 0, 0),
(174, 'PH', 'Philippines', 0, 0),
(176, 'PL', 'Poland', 1, 0),
(177, 'PT', 'Portugal', 1, 0),
(178, 'PR', 'Puerto Rico', 0, 0),
(179, 'QA', 'Qatar', 0, 0),
(180, 'RE', 'Reunion', 0, 0),
(181, 'RO', 'Romania', 1, 0),
(182, 'RU', 'Russian Federation', 1, 0),
(183, 'RW', 'Rwanda', 0, 0),
(184, 'KN', 'Saint Kitts and Nevis', 0, 0),
(185, 'LC', 'Saint Lucia', 0, 0),
(187, 'WS', 'Samoa', 0, 0),
(188, 'SM', 'San Marino', 0, 0),
(190, 'SA', 'Saudi Arabia', 0, 0),
(191, 'SN', 'Senegal', 0, 0),
(192, 'RS', 'Serbia', 1, 0),
(193, 'SC', 'Seychelles', 0, 0),
(194, 'SL', 'Sierra Leone', 0, 0),
(195, 'SG', 'Singapore', 0, 0),
(196, 'SK', 'Slovakia', 0, 0),
(197, 'SI', 'Slovenia', 1, 0),
(199, 'SO', 'Somalia', 0, 0),
(200, 'ZA', 'South Africa', 0, 0),
(202, 'ES', 'Spain (España)', 1, 1),
(203, 'LK', 'Sri Lanka', 0, 0),
(206, 'SD', 'Sudan', 0, 0),
(207, 'SR', 'Suriname', 0, 0),
(209, 'SZ', 'Swaziland', 0, 0),
(210, 'SE', 'Sweden', 1, 0),
(211, 'CH', 'Switzerland', 1, 0),
(213, 'TW', 'Taiwan', 0, 0),
(215, 'TZ', 'Tanzania, United Republic of', 0, 0),
(216, 'TH', 'Thailand', 0, 0),
(217, 'TG', 'Togo', 0, 0),
(220, 'TT', 'Trinidad and Tobago', 0, 0),
(222, 'TR', 'Turkey', 1, 0),
(223, 'TM', 'Turkmenistan', 0, 0),
(226, 'UG', 'Uganda', 0, 0),
(227, 'UA', 'Ukraine', 1, 0),
(228, 'AE', 'United Arab Emirates', 0, 0),
(229, 'GB', 'United Kingdom', 1, 0),
(230, 'US', 'United States', 0, 0),
(232, 'UY', 'Uruguay', 0, 0),
(233, 'UZ', 'Uzbekistan', 0, 0),
(234, 'VU', 'Vanuatu', 0, 0),
(235, 'VA', 'Vatican City State', 0, 0),
(236, 'VE', 'Venezuela', 0, 0),
(237, 'VN', 'Vietnam', 0, 0),
(238, 'VG', 'Virgin Islands (British)', 0, 0),
(239, 'VI', 'Virgin Islands (U.S.)', 0, 0),
(240, 'WF', 'Wallis and Futuna Islands', 0, 0),
(242, 'YE', 'Yemen', 0, 0),
(245, 'ZM', 'Zambia', 0, 0),
(246, 'ZW', 'Zimbabwe', 0, 0),
(247, 'ESAN', 'Andorra (Spain)', 1, 0),
(248, 'ESMA', 'Palma de Mallorca (Spain)', 1, 0),
(249, 'ESBA', 'Baleares (Spain)', 1, 0),
(250, 'ESPA', 'Las Palmas y Tenerife (Spain)', 1, 0),
(251, 'ESCA', 'Canarias Menores (Spain)', 1, 0),
(252, 'ESCE', 'Ceuta y Melilla (Spain)', 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) unsigned NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `hash` varchar(255) DEFAULT NULL,
  `lang_data` text,
  `menu_name` varchar(100) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `category`
--

INSERT INTO `category` (`id`, `parent_id`, `order`, `hash`, `lang_data`, `menu_name`) VALUES
(23, 0, 5, 'cava-texturitzat', '{"es":"CAVA TEXTURITZADO","en":"CAVA TEXTURITZAT","ca":"CAVA TEXTURITZAT"}', 'CAVA TEXTURITZAT'),
(19, 0, 0, 'cavas', '{"es":"Cavas","en":"Cavas","ca":"Caves"}', 'Cavas'),
(20, 0, 1, 'vinos-penedes', '{"es":"Vinos Pened\\u00e8s","en":"Wines","ca":"Vins"}', 'Vinos Penedès'),
(21, 0, 3, 'l’esperit', '{"es":"L&rsquo;Esperit","en":"L&rsquo;Esperit","ca":"L&rsquo;Esperit"}', 'L’Esperit'),
(22, 0, 4, 'vinagres', '{"es":"Vinagres","en":"Vinegars","ca":"Vinagres"}', 'Vinagres'),
(24, 0, 2, 'productes-gourmet', '{"es":"Productos Gourmet","en":"Gourmet","ca":"Productes Gourmet"}', 'Productes Gourmet');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `code` varchar(2) DEFAULT NULL,
  `locale` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `countries`
--

INSERT INTO `countries` (`code`, `locale`) VALUES
('af', 'af_ZA'),
('ar', 'ar'),
('bg', 'bg_BG'),
('ca', 'ca_ES'),
('cs', 'cs_CZ'),
('cy', 'cy_GB'),
('da', 'da_DK'),
('de', 'de_DE'),
('el', 'el_GR'),
('en', 'en_US'),
('es', 'es_ES'),
('et', 'et_EE'),
('eu', 'eu'),
('fa', 'fa_IR'),
('fi', 'fi_FI'),
('fr', 'fr_FR'),
('he', 'he_IL'),
('hr', 'hr_HR'),
('hu', 'hu_HU'),
('id', 'id_ID'),
('is', 'is_IS'),
('it', 'it_IT'),
('ja', 'ja_JP'),
('km', 'km_KH'),
('ko', 'ko_KR'),
('lt', 'lt_LT'),
('lv', 'lv_LV'),
('mn', 'mn_MN'),
('nb', 'nb_NO'),
('nl', 'nl_NL'),
('nn', 'nn_NO'),
('pl', 'pl_PL'),
('pt', 'pt_PT'),
('ro', 'ro_RO'),
('ru', 'ru_RU'),
('sk', 'sk_SK'),
('sl', 'sl_SI'),
('sr', 'sr_RS'),
('sv', 'sv_SE'),
('th', 'th_TH'),
('tr', 'tr_TR'),
('uk', 'uk_UA'),
('vi', 'vi_VN'),
('zh', 'zh_CN');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `distribuidores`
--

CREATE TABLE IF NOT EXISTS `distribuidores` (
  `id` int(11) NOT NULL,
  `idioma` tinyint(4) NOT NULL,
  `padre` int(11) NOT NULL,
  `poblacion` varchar(200) CHARACTER SET latin1 NOT NULL,
  `distribuidores` text CHARACTER SET latin1 NOT NULL,
  `orden` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=382 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `distribuidores`
--

INSERT INTO `distribuidores` (`id`, `idioma`, `padre`, `poblacion`, `distribuidores`, `orden`) VALUES
(71, 2, 0, 'Europe', '', 1),
(69, 0, 0, 'Europa', '', 1),
(70, 1, 0, 'Europa', '', 1),
(51, 0, 0, 'Puerto Rico', '<h1>B. FERNANDEZ &amp; HNOS , INC</h1>\r\n<p>Sr. Juan A. Teixidor<br />P.O.BOX: 363629<br />SAN JUAN -PR 00936-3629<br />PUERTO RICO<br />(787) 288.7272<br />www.bfernandez.com<br />cristina.teixidor@bfernandez.com<br />www.almacendelvinopr.com<br />juan.teixidor@bfernandez.com<br />katerina.sanchez@bfernandez.com<br />tanya.trelles@bfernandez.com</p>', 12),
(52, 1, 0, 'Puerto Rico', '<h1>B. FERNANDEZ &amp; HNOS , INC</h1>\r\n<p>Sr. Juan A. Teixidor<br />P.O.BOX: 363629<br />SAN JUAN -PR 00936-3629<br />PUERTO RICO<br />(787) 288.7272<br />www.bfernandez.com<br />cristina.teixidor@bfernandez.com<br />www.almacendelvinopr.com<br />juan.teixidor@bfernandez.com<br />katerina.sanchez@bfernandez.com<br />tanya.trelles@bfernandez.com</p>\r\n<p>&nbsp;</p>', 12),
(53, 2, 0, 'Puerto Rico', '<h1>B. FERNANDEZ &amp; HNOS , INC</h1>\r\n<p>Sr. Juan A. Teixidor<br />P.O.BOX: 363629<br />SAN JUAN -PR 00936-3629<br />PUERTO RICO<br />(787) 288.7272<br />www.bfernandez.com<br />cristina.teixidor@bfernandez.com<br />www.almacendelvinopr.com<br />juan.teixidor@bfernandez.com<br />katerina.sanchez@bfernandez.com<br />tanya.trelles@bfernandez.com</p>\r\n<p>&nbsp;</p>', 12),
(54, 0, 0, 'Brasil', '<h1>&nbsp;</h1>\r\n<p><strong style="font-size: 11.818181991577148px;">Se busca importador.</strong></p>\r\n<p><br /><br /><br /></p>\r\n<p>&nbsp;</p>', 5),
(55, 1, 0, 'Brasil', '<h1></h1>\r\n<p><strong>Es busca importador.</strong><br /><br /></p>\r\n<p>&nbsp;</p>', 5),
(56, 2, 0, 'Brazil', '<h1></h1>\r\n<p><strong>Looking for importer.</strong><br /><br /></p>', 5),
(57, 0, 0, 'Israel', '<h1>Contacto</h1>\r\n<p>e-mail: info@agustitorellomata.com</p>\r\n<p>Tel&eacute;fono: 00 34 93 891 11 73</p>\r\n<p>&nbsp;</p>', 8),
(58, 1, 0, 'Israel', '<h1>Contacte</h1>\r\n<p>e-mail: info@agustitorellomata.com</p>\r\n<p>Tel&egrave;fon: 00 34 93 891 11 73</p>', 8),
(59, 2, 0, 'Israel', '<h1>Contact</h1>\r\n<p>&nbsp;e-mail: info@agustitorellomata.com</p>\r\n<p>Phone: 00 34 93 891 11 73</p>', 8),
(319, 0, 0, 'República Dominicana', '<h1></h1>\r\n<h1>BRAVO S.A</h1>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">Montserrat Alonso<br />Av. Winston Churchill, 1452<br />39408 Santo Domingo&nbsp;<br />Tel.: 650 491 300<br /><br /></p>', 13),
(320, 1, 0, 'República Dominicana', '<h1>\r\n<h1>BRAVO S.A</h1>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">Montserrat Alonso<br />Av. Winston Churchill, 1452<br />39408 Santo Domingo&nbsp;<br />Tel.: 650 491 300</p>\r\n</h1>', 13),
(321, 2, 0, 'Dominican Republic', '<h1>\r\n<h1>BRAVO S.A</h1>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">Montserrat Alonso<br />Av. Winston Churchill, 1452<br />39408 Santo Domingo&nbsp;<br />Tel.: 650 491 300</p>\r\n</h1>', 13),
(63, 0, 0, 'Singapur', '<h1>ALFA INTERNATIONAL PTE, LTD.</h1>\r\n<p>Susy Santoso<br />39 KEPPEL ROAD<br />#02-01E SINGAPORE 089065<br />SINGAPORE<br />00.65.622.23.977<br />www.ewineasia.com<br />susy@ewineasia.com</p>', 14),
(64, 1, 0, 'Singapur', '<h1>ALFA INTERNATIONAL PTE, LTD.</h1>\r\n<p>Susy Santoso<br />39 KEPPEL ROAD<br />#02-01E SINGAPORE 089065<br />SINGAPORE<br />00.65.622.23.977<br />www.ewineasia.com<br />susy@ewineasia.com</p>\r\n<p>&nbsp;</p>', 14),
(65, 2, 0, 'Singapore', '<h1>ALFA INTERNATIONAL PTE, LTD.</h1>\r\n<p>Susy Santoso<br />39 KEPPEL ROAD<br />#02-01E SINGAPORE 089065<br />SINGAPORE<br />00.65.622.23.977<br />www.ewineasia.com<br />susy@ewineasia.com</p>\r\n<p>&nbsp;</p>', 14),
(66, 0, 0, 'Australia', '<h1>THE SPANISH ACQUISITION</h1>\r\n<p>Mr. Scott Wasley<br />P.O.BOX 1259 COLLINGWOOD<br />VIC 3066<br />AUSTRALIA<br />+61 (3) 9495 6373<br />www.thespanishacquisition.com<br />dougie@thespanishacquisition.com</p>\r\n<p>&nbsp;</p>', 4),
(67, 1, 0, 'Australia', '<h1>THE SPANISH ACQUISITION</h1>\r\n<p>Mr. Scott Wasley<br />P.O.BOX 1259 COLLINGWOOD<br />VIC 3066<br />AUSTRALIA<br />+61 (3) 9495 6373<br />www.thespanishacquisition.com<br />dougie@thespanishacquisition.com</p>\r\n<p>&nbsp;</p>', 4),
(68, 2, 0, 'Australia', '<h1>THE SPANISH ACQUISITION</h1>\r\n<p>Mr. Scott Wasley<br />P.O.BOX 1259 COLLINGWOOD<br />VIC 3066<br />AUSTRALIA<br />+61 (3) 9495 6373<br />www.thespanishacquisition.com<br />dougie@thespanishacquisition.com</p>', 4),
(72, 0, 69, 'Noruega', '<h1>VINATURA AS</h1>\r\n<p>Mr. K Johansen Vidar<br />DAMSGARD 55<br />4318<br />SANDNES<br />NORUEGA<br />00.47.90.21.87.77<em><strong>&nbsp;</strong></em><br /><br /></p>\r\n<h1>GASTRONAUT AS<br />(Productos gastron&oacute;micos)</h1>\r\n<p>Mr. Dag Odegaard<br />VAKASVEIEN 9<br />1395<br />HVALSTAD<br />NORUEGA<br />00.47.66.77.80.60<em><strong>&nbsp;</strong></em><br />dag@gastronaut.no</p>', 29),
(73, 1, 70, 'Noruega', '<h1>VINATURA AS</h1>\r\n<p>Mr. K Johansen Vidar<br />DAMSGARD 55<br />4318<br />SANDNES<br />NORUEGA<br />00.47.90.21.87.77<em><strong>&nbsp;</strong></em><br /><br /></p>\r\n<h1>GASTRONAUT AS<br /> (Productes gastron&ograve;mics)</h1>\r\n<p>Mr. Dag Odegaard<br />VAKASVEIEN 9<br />1395<br />HVALSTAD<br />NORUEGA<br />00.47.66.77.80.60<em><strong>&nbsp;</strong></em><br />dag@gastronaut.no</p>', 29),
(74, 2, 71, 'Norway', '<h1>VINATURA AS</h1>\r\n<p>Mr. K Johansen Vidar<br />DAMSGARD 55<br />4318<br />SANDNES<br />NORUEGA<br />00.47.90.21.87.77<em><strong>&nbsp;</strong></em><br /><br /></p>\r\n<h1>GASTRONAUT AS<br /> (Gastronomic goods)</h1>\r\n<p>Mr. Dag Odegaard<br />VAKASVEIEN 9<br />1395<br />HVALSTAD<br />NORUEGA<br />00.47.66.77.80.60<em><strong>&nbsp;</strong></em><br />dag@gastronaut.no</p>', 27),
(75, 0, 69, 'Finlandia', '<h1>TAMPEREEN VIINITUKKU OY</h1>\r\n<p>Mr. Marko Horto<br />VALTTINTLE, 8<br />33980<br />PIRKKALA<br />FINLANDIA<br />+358 (0)10 3090 800<br />www.tampereenviinitukku.fi<br />marko.horto@tampereenviinitukku.fi</p>', 22),
(76, 1, 70, 'Finlàndia', '<h1>TAMPEREEN VIINITUKKU OY</h1>\r\n<p>Mr. Marko Horto<br />VALTTINTLE, 8<br />33980<br />PIRKKALA<br />FINL&Agrave;NDIA<br />+358 (0)10 3090 800<br />www.tampereenviinitukku.fi<br />marko.horto@tampereenviinitukku.fi</p>', 22),
(77, 2, 71, 'Finland', '<h1>TAMPEREEN VIINITUKKU OY</h1>\r\n<p>Mr. Marko Horto<br />VALTTINTLE, 8<br />33980<br />PIRKKALA<br />FINLAND<br />+358 (0)10 3090 800<br />www.tampereenviinitukku.fi<br />marko.horto@tampereenviinitukku.fi</p>', 19),
(78, 0, 69, 'Suecia', '<h1>VI&Ntilde;A ESPA&Ntilde;OLA AB</h1>\r\n<p>Mr. Mariano Rodriguez<br /> ROSLAGSGATAN 36<br /> S-113 55<br /> STOCKHOLM<br /> SUECIA<br /> +46 (8) 673 2024<br /> www.tempranillo.se<br /> sebastian@tempranillo.se</p>', 33),
(79, 1, 69, 'Suècia', '<h1>VI&Ntilde;A ESPA&Ntilde;OLA AB</h1>\r\n<p>Mr. Mariano Rodriguez<br /> ROSLAGSGATAN 36<br /> S-113 55<br /> STOCKHOLM<br /> SU&Egrave;CIA<br /> +46 (8) 673 2024<br /> www.tempranillo.se<br /> sebastian@tempranillo.se</p>\r\n<p>&nbsp;</p>', 33),
(80, 2, 71, 'Sweden', '<h1>VI&Ntilde;A ESPA&Ntilde;OLA AB</h1>\r\n<p>Mr. Mariano Rodriguez<br /> ROSLAGSGATAN 36<br /> S-113 55<br /> STOCKHOLM<br /> SWEDEN<br /> +46 (8) 673 2024<br /> www.tempranillo.se<br /> sebastian@tempranillo.se</p>', 32),
(81, 0, 69, 'Lituania', '<p><strong>UAB "DUDA IR KOMPANIJA"</strong></p>\r\n<p><em>Sr. Arunas Starkus</em></p>\r\n<p>STUMBRU str. 15</p>\r\n<p>Vilnius LT-03116</p>\r\n<p>LITUANIA</p>\r\n<p>00.37.05.213.8431</p>\r\n<p><em>&nbsp;</em></p>', 28),
(82, 1, 70, 'Lituània', '<p><strong>UAB "DUDA IR KOMPANIJA"</strong></p>\r\n<p><em>Sr. Arunas Starkus</em></p>\r\n<p>STUMBRU str. 15</p>\r\n<p>Vilnius LT-03116</p>\r\n<p>LITU&Agrave;NIA</p>\r\n<p>00.37.05.213.8431</p>', 28),
(83, 2, 71, 'Lithuania', '<p><strong>UAB "DUDA IR KOMPANIJA"</strong></p>\r\n<p><em>Mr. Arunas Starkus</em></p>\r\n<p>STUMBRU str.15</p>\r\n<p>Vilnius LT-03116</p>\r\n<p>LITHUANIA</p>\r\n<p>00.37.05.213.8431</p>', 26),
(84, 0, 69, 'Rusia', '<h1></h1>\r\n<p><strong>Se busca importador.</strong><br /><br /><br /><br /><br /><br /><br /></p>', 32),
(85, 1, 70, 'Rússia', '<p><strong>Es busca importador.</strong><br /><br /><br /><br /><br /><br /></p>', 32),
(86, 2, 71, 'Russia', '<p><strong style="font-size: 11.818181991577148px;">Looking for importer.</strong></p>\r\n<p>&nbsp;</p>', 30),
(87, 0, 69, 'Dinamarca', '<h1>THEIS VINE APS</h1>\r\n<p>Mr. John K. Larsen<br />BREDGADE 23<br />1260<br />KOBENHAVN K<br />DINAMARCA<br />+(45) 6266 1120<br />www.theis-vine.dk<br />post@theis-vine.dk</p>', 19),
(88, 1, 70, 'Dinamarca', '<h1>THEIS VINE APS</h1>\r\n<p>Mr. John K. Larsen<br />BREDGADE 23<br />1260<br />KOBENHAVN K<br />DINAMARCA<br />+(45) 6266 1120<br />www.theis-vine.dk<br />post@theis-vine.dk</p>', 19),
(89, 2, 69, 'Denmark', '<h1>THEIS VINE APS</h1>\r\n<p>Mr. John K. Larsen<br />BREDGADE 23<br />1260<br />KOBENHAVN K<br />DENMARK<br />+(45) 6266 1120<br />www.theis-vine.dk<br />post@theis-vine.dk</p>', 19),
(90, 0, 69, 'Irlanda', '<h1>Se busca importador</h1>', 26),
(91, 1, 69, 'Irlanda', '<h1>Es busca importador</h1>', 26),
(92, 2, 71, 'Ireland', '<h1>Looking for importer</h1>', 24),
(93, 0, 69, 'Gran Bretaña', '<h1>GEORGES BARBIER OF LONDON LTD.</h1>\r\nMr. Georges Barbier\r\n267 LEE HIGH ROAD\r\nSE12 8RU\r\nLONDON\r\nGRAN BRETAÑA\r\n+44 (208) 852 5801\r\n<a href="mailto:georgesbarbier@f2s.com">georgesbarbier@f2s.com</a>\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n<h1>GREY´S FINE FOODS</h1>\r\nMr. Javier de la Hormaza\r\nUnit 20M Marston Moor Business Park\r\nTockwith, YO26 7QF\r\nNorth Yorkshire, UK\r\n+44(0) 798 560 3005\r\n+44 (0) 1423 358 159\r\n\r\n<a href="mailto:alvaro.delportillo@greypearl.co.uk">info@greysfinefoods.com</a>\r\n\r\n<a href="http://www.greysfinefoods.com/">www.greysfinefoods.com</a>', 24),
(94, 1, 70, 'Gran Bretanya', '<h1>GEORGES BARBIER OF LONDON LTD.</h1>\r\nMr. Georges Barbier\r\n267 LEE HIGH ROAD\r\nSE12 8RU\r\nLONDON\r\nGRAN BRETAÑA\r\n+44 (208) 852 5801\r\n<a href="mailto:georgesbarbier@f2s.com">georgesbarbier@f2s.com</a>\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n<h1>GREY´S FINE FOODS</h1>\r\nMr. Javier de la Hormaza\r\nUnit 20M Marston Moor Business Park\r\nTockwith, YO26 7QF\r\nNorth Yorkshire, UK\r\n+44(0) 798 560 3005\r\n+44 (0) 1423 358 159\r\n\r\n<a href="mailto:alvaro.delportillo@greypearl.co.uk">info@greysfinefoods.com</a>\r\n\r\n<a href="http://www.greysfinefoods.com/">www.greysfinefoods.com</a>\r\n<div><strong> </strong></div>\r\n&nbsp;\r\n\r\n&nbsp;', 24),
(340, 2, 0, 'Japan', '<h1>SU-KORUNI CO., LTD.</h1>\r\n<p><strong>SAORI TAKIGUCHI</strong></p>\r\n<p>1-8-6, Shimbashi, Minato-ku, Tokio</p>\r\n<p>105-0004 Japan</p>\r\n<p>Telf +81 3 3573 4181</p>\r\n<p>Fax +81 3 3573 6070</p>\r\n<p>takiguchi@sukoruni.co.jp</p>\r\n<p>&nbsp;</p>', 9),
(95, 2, 71, 'Great Britain', '<h1>GEORGES BARBIER OF LONDON LTD.</h1>\r\nMr. Georges Barbier\r\n267 LEE HIGH ROAD\r\nSE12 8RU\r\nLONDON\r\nGRAN BRETAÑA\r\n+44 (208) 852 5801\r\n<a href="mailto:georgesbarbier@f2s.com">georgesbarbier@f2s.com</a>\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n<h1>GREY´S FINE FOODS</h1>\r\nMr. Javier de la Hormaza\r\nUnit 20M Marston Moor Business Park\r\nTockwith, YO26 7QF\r\nNorth Yorkshire, UK\r\n+44(0) 798 560 3005\r\n+44 (0) 1423 358 159\r\n\r\n<a href="mailto:alvaro.delportillo@greypearl.co.uk">info@greysfinefoods.com</a>\r\n\r\n<a href="http://www.greysfinefoods.com/">www.greysfinefoods.com</a>\r\n<div><strong> </strong></div>\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\n<strong> </strong>\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\n&nbsp;', 22),
(338, 0, 0, 'Japón', '<h1>SU-KORUNI CO., LTD.</h1>\r\n<p><strong>SAORI TAKIGUCHI</strong></p>\r\n<p>1-8-6, Shimbashi, Minato-ku, Tokio</p>\r\n<p>105-0004 Jap&oacute;n</p>\r\n<p>Telf +81 3 3573 4181</p>\r\n<p>Fax +81 3 3573 6070</p>\r\n<p>takiguchi@sukoruni.co.jp</p>\r\n<p>&nbsp;</p>', 9),
(339, 1, 0, 'Japó', '<h1>SU-KORUNI CO., LTD.</h1>\r\n<p><strong>SAORI TAKIGUCHI</strong></p>\r\n<p>1-8-6, Shimbashi, Minato-ku, Tokio</p>\r\n<p>105-0004 Jap&oacute;</p>\r\n<p>Telf +81 3 3573 4181</p>\r\n<p>Fax +81 3 3573 6070</p>\r\n<p>takiguchi@sukoruni.co.jp</p>\r\n<p>&nbsp;</p>', 9),
(96, 0, 69, 'Holanda', '<h1>PALLAS WINES B.V.</h1>\r\n<p>Mr. Joep Speet<br />BREDEWEG 23-50- DIST.DOELWIJK<br />2742 KZ<br />WADDINXVEEN<br />HOLANDA<br />+31 180 635128<br />www.pallaswines.nl<br />joep@pallaswines.nl</p>', 25),
(97, 1, 70, 'Holanda', '<h1>PALLAS WINES B.V.</h1>\r\n<p>Mr. Joep Speet<br />BREDEWEG 23-50- DIST.DOELWIJK<br />2742 KZ<br />WADDINXVEEN<br />HOLANDA<br />+31 180 635128<br />www.pallaswines.nl<br />joep@pallaswines.nl</p>', 25),
(98, 2, 71, 'Holland', '<h1>PALLAS WINES B.V.</h1>\r\n<p>Mr. Joep Speet<br />BREDEWEG 23-50- DIST.DOELWIJK<br />2742 KZ<br />WADDINXVEEN<br />HOLLAND<br />+31 180 635128<br />www.pallaswines.nl<br />joep@pallaswines.nl</p>', 23),
(99, 0, 69, 'Polonia', '<h1>DOM WINA SP Z.O.O.</h1>\r\n<p>Mr. Artur Boruta<br />UL BALICKA 255<br />30-198<br />CRACOVIA<br />POLONIA<br />+48 (12) 638 1380<br />www.domwina.pl<br />domwina@domwina.pl</p>', 30),
(100, 1, 70, 'Polònia', '<h1>DOM WINA SP Z.O.O.</h1>\r\n<p>Mr. Artur Boruta<br />UL BALICKA 255<br />30-198<br />CRACOVIA<br />POL&Ograve;NIA<br />+48 (12) 638 1380<br />www.domwina.pl<br />domwina@domwina.pl</p>', 30),
(101, 2, 71, 'Poland', '<h1>DOM WINA SP Z.O.O.</h1>\r\n<p>Mr. Artur Boruta<br />UL BALICKA 255<br />30-198<br />CRACOVIA<br />POLAND<br />+48 (12) 638 1380<br />www.domwina.pl<br />domwina@domwina.pl</p>', 28),
(102, 0, 69, 'Alemania', 'A.VIANI IMPORTE GmbH\r\n<h1>(Productos gastronómicos)</h1>\r\nMr. A. Viani\r\nROBERT BOSCH BREITE, 17\r\n37079\r\nGOTTINGEN\r\nALEMANIA\r\n+49 (551) 505 5145\r\nwww.viani.de\r\ninfo@viani.de\r\n<h1>WEIN - BASTION</h1>\r\nSchillerstrasse,1\r\n\r\n89077 ULM\r\n\r\nTf. 4973166993\r\n\r\n<a href="mailto:info@wein-bastion.de">info@wein-bastion.de</a>\r\n<em><strong>\r\n</strong></em>', 14),
(103, 1, 70, 'Alemanya', '&nbsp;\r\n<h1>A.VIANI IMPORTE GmbH\r\n(Productes gastronòmics)</h1>\r\nMr. A. Viani\r\nROBERT BOSCH BREITE, 17\r\n37079\r\nGOTTINGEN\r\nALEMANIA\r\n+49 (551) 505 5145<em><strong> </strong></em>\r\nwww.viani.de\r\ninfo@viani.de\r\n<h1>WEIN - BASTION</h1>\r\nSchillerstrasse,1\r\n\r\n89077 ULM\r\n\r\nTf. 4973166993\r\n\r\n<a href="mailto:info@wein-bastion.de">info@wein-bastion.de</a>\r\n\r\n&nbsp;', 14),
(104, 2, 71, 'Germany', '&nbsp;\r\n<h1>A.VIANI IMPORTE GmbH\r\n(Gastronomic goods)</h1>\r\nMr. A. Viani\r\nROBERT BOSCH BREITE, 17\r\n37079\r\nGOTTINGEN\r\nALEMANIA\r\n+49 (551) 505 5145<em><strong> </strong></em>\r\nwww.viani.de\r\ninfo@viani.de\r\n<h1>WEIN - BASTION</h1>\r\nSchillerstrasse,1\r\n\r\n89077 ULM\r\n\r\nTf. 4973166993\r\n\r\n<a href="mailto:info@wein-bastion.de">info@wein-bastion.de</a>\r\n\r\n&nbsp;', 21),
(105, 0, 69, 'Bélgica', '<h1>Guy Dresselaers</h1>\r\nElvino\r\n\r\nLeopold I-laan 77\r\n\r\nB8000 Brugge\r\n\r\n0032 475 672953\r\n\r\n<a href="mailto:guy@elvino.be">guy@elvino.be</a>', 17),
(106, 1, 70, 'Bèlgica', '<h1>Guy Dresselaers</h1>\r\nElvino\r\n\r\nLeopold I-laan 77\r\n\r\nB8000 Brugge\r\n\r\n0032 475 672953\r\n\r\n<a href="mailto:guy@elvino.be">guy@elvino.be</a>', 17),
(107, 2, 71, 'Belgium', '<h1>Guy Dresselaers</h1>\r\nElvino\r\n\r\nLeopold I-laan 77\r\n\r\nB8000 Brugge\r\n\r\n0032 475 672953\r\n\r\n<a href="mailto:guy@elvino.be">guy@elvino.be</a>', 16),
(108, 0, 69, 'Suiza', '<h1>PAUL ULLRICH AG</h1>\r\n<p>Mr. Adrian Baumgartner<br />LAUFENSTRASSE 16<br />4018<br />BASEL<br />SUIZA<br />00.41.61.338.90.90<br />www.ullrich.ch<br />adrian.baumgartner@ullrich.ch</p>\r\n<h1><br />TONY NAVARRO</h1>\r\n<p>Mr. Tony Navarro<br />OBERE Z&Auml;UNE, 19<br />8001<br />Z&Uuml;RICH<br />SUIZA<br />01-262 52 00/01/06</p>', 34),
(109, 1, 70, 'Suïssa', '<h1>PAUL ULLRICH AG</h1>\r\n<p>Mr. Adrian Baumgartner<br />LAUFENSTRASSE 16<br />4018<br />BASEL<br />SU&Iuml;SSA<br />00.41.61.338.90.90<br />www.ullrich.ch<br />adrian.baumgartner@ullrich.ch</p>\r\n<h1><br />TONY NAVARRO</h1>\r\n<p>Mr. Tony Navarro<br />OBERE Z&Auml;UNE, 19<br />8001<br />Z&Uuml;RICH<br />SU&Iuml;SSA<br />01-262 52 00/01/06</p>', 34),
(110, 2, 71, 'Switzerland', '<h1>PAUL ULLRICH AG</h1>\r\n<p>Mr. Adrian Baumgartner<br />LAUFENSTRASSE 16<br />4018<br />BASEL<br />SWITZERLAND<br />00.41.61.338.90.90<br />www.ullrich.ch<br />adrian.baumgartner@ullrich.ch</p>\r\n<h1><br />TONY NAVARRO</h1>\r\n<p>Mr. Tony Navarro<br />OBERE Z&Auml;UNE, 19<br />8001<br />Z&Uuml;RICH<br />SWITZERLAND<br />01-262 52 00/01/06</p>', 33),
(111, 0, 69, 'Austria', '<h1>POHL &amp; LINGENHEL SELECTION Hmbh</h1>\r\n<p>Mr. Johannes Lingenhel<br />AM NASCHMARKT 167<br />A-1060<br />WIEN<br />AUSTRIA<br />+43 2235 20469<br />www.poehlamnaschmarkt.at<br />ejohannes@poehl.at</p>\r\n<p>&nbsp;</p>\r\n<h1>WEIN.DEPOT NOITZ</h1>\r\n<p>Mr. Franz Noitz<br />R&ouml;merstrasse 169<br />A-3511<br />PALT<br />AUSTRIA<br />+43 2732 85656<br />+43 2732 85656-4<br />www.wein-handlung.at<br />wein.depot@aon.at</p>', 16),
(112, 1, 70, 'Àustria', '<h1>POHL &amp; LINGENHEL SELECTION Hmbh</h1>\r\n<p>Mr. Johannes Lingenhel<br />AM NASCHMARKT 167<br />A-1060<br />WIEN<br />AUSTRIA<br />+43 2235 20469<br />www.poehlamnaschmarkt.at<br />ejohannes@poehl.at</p>\r\n<h1>WEIN.DEPOT NOITZ</h1>\r\n<p>Mr. Franz Noitz<br />R&ouml;merstrasse 169<br />A-3511<br />PALT<br />AUSTRIA<br />+43 2732 85656<br />+43 2732 85656-4<br /> www.wein-handlung.at<br />wein.depot@aon.at</p>', 16),
(304, 0, 69, 'Chequia', '<h1>SABORES, S.R.O.</h1>\r\n<p>Mr. Traian Urban<br />NAD OHRADON, 13<br />13000<br />PRAHA 33<br />CHEQUIA<br />420.608.710.827<br />www.sabores.cz<br />urban@sabores.cz<br />www.delikatesy-online.cz</p>', 18),
(305, 2, 71, 'Czech Republic', '<h1>SABORES, S.R.O.</h1>\r\n<p>Mr. Traian Urban<br />NAD OHRADON, 13<br />13000<br />PRAHA 33<br />CZECH REPUBLIC<br />420.608.710.827<br />www.sabores.cz<br />urban@sabores.cz<br />www.delikatesy-online.cz</p>', 17),
(306, 1, 70, 'Txèquia', '<h1>SABORES, S.R.O.</h1>\r\n<p>Mr. Traian Urban<br />NAD OHRADON, 13<br />13000<br />PRAHA 33<br />TX&Egrave;QUIA<br />420.608.710.827<br />www.sabores.cz<br />urban@sabores.cz<br />www.delikatesy-online.cz</p>', 35),
(113, 2, 71, 'Austria', '<h1>POHL &amp; LINGENHEL SELECTION Hmbh</h1>\r\n<p>Mr. Johannes Lingenhel<br />AM NASCHMARKT 167<br />A-1060<br />WIEN<br />AUSTRIA<br />+43 2235 20469<br />www.poehlamnaschmarkt.at<br />ejohannes@poehl.at</p>\r\n<p>&nbsp;</p>\r\n<h1>WEIN.DEPOT NOITZ</h1>\r\n<p>Mr. Franz Noitz<br />R&ouml;merstrasse 169<br />A-3511<br />PALT<br />AUSTRIA<br />+43 2732 85656<br />+43 2732 85656-4<br /> www.wein-handlung.at<br />wein.depot@aon.at</p>', 15),
(36, 0, 0, 'Canadá', '<h1>ENOTRI WINE MARKETING, INC.</h1>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">Mr. Eberhard Tamm\r\n412, 52304 Range Road 233\r\nAB T8B1C9\r\nSherwood Park - ALBERTA\r\nCANADA\r\n+1 780 416 1804\r\neberhard@enotri.com</p>\r\n\r\n<h1>TWC IMPORTS</h1>\r\nMr. Richard Kitowski\r\n18205 KENNEDY RD., BOX 36\r\nL7K 3L3\r\nCALEDON - ONTARIO\r\nCANADA\r\n(416) 809 9463\r\nric@thewinecoaches.com\r\n<h1>PASSION GOURMET CA</h1>\r\nMr. Jose Lopez\r\n42029 SPS ROY\r\nH2W 2T3\r\nMONTRÉAL - QUEBEC\r\nwww.passiongourmet.ca\r\njose@passiongourmet.ca\r\n<h1>DESIRS DE PROVENCE INC\r\n(Productos gastronómicos)</h1>\r\nMr. Robert Valois\r\n435 AVENUE MERCILLE\r\nJ4P 2L6\r\nSAINT-LAMBERT-QUEBEC\r\nCANADA<strong><em> </em></strong>\r\n(450) 671 6861\r\nrobertvalois@videotron.ca\r\n<h1>PASQUALE BROS DOWNTOWN LTD\r\n(Productos gastronómicos)</h1>\r\nMrs. Anna Marie Kalcevich\r\n16 GOODRICH RD\r\nON M8Z 4Z8\r\nETOBICOKE\r\nONTARIO CANADA\r\nwww.pasqualebros.com\r\ngoodfood@pasqualebros.com', 6),
(37, 1, 0, 'Canadà', '<h1>ENOTRI WINE MARKETING, INC</h1>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">Mr. Eberhard Tamm<br />412, 52304 Range Road 233<br />AB T8B 1C9<br />Sherwood Park - ALBERTA<br />CANADA<br />+1 780 416 1804<br />eberhard@enotri.com</p>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">&nbsp;</p>\r\n<h1>TWC IMPORTS</h1>\r\n<p>Mr. Richard Kitowski<br />18205 KENNEDY RD., BOX 36<br />L7K 3L3<br />CALEDON - ONTARIO<br />CANADA<br />(416) 809 9463<br />ric@thewinecoaches.com</p>\r\n<h1><br />PASSION GOURMET CA</h1>\r\n<p>Mr. Jose Lopez<br />42029 SPS ROY<br />H2W 2T3<br />MONTR&Eacute;AL - QUEBEC<br />www.passiongourmet.ca<br />jose@passiongourmet.ca</p>\r\n<h1><br />DESIRS DE PROVENCE INC<br />(Productes gastron&ograve;mics)</h1>\r\n<p>Mr. Robert Valois<br />435 AVENUE MERCILLE<br />J4P 2L6<br />SAINT-LAMBERT-QUEBEC<br />CANADA<strong><em>&nbsp;</em></strong><br />(450) 671 6861<br />robertvalois@videotron.ca</p>\r\n<h1><br />PASQUALE BROS DOWNTOWN LTD<br />(Productes gastron&ograve;mics)</h1>\r\n<p>Mrs. Anna Marie Kalcevich<br />16 GOODRICH RD<br />ON M8Z 4Z8<br />ETOBICOKE<br />ONTARIO CANADA<strong><em>&nbsp;</em></strong><br />www.pasqualebros.com<br />goodfood@pasqualebros.com</p>', 6),
(38, 2, 0, 'Canadá', '<p>&nbsp;</p>\r\n<h1>ENOTRI WINE MARKETING, INC.</h1>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">Mr. Eberhard Tamm<br />412, 52304 Range Road, 233<br />AB T8B1C9<br />Sherwood Park - ALBERTA<br />CANADA<br />+1 780 416 1804<br />eberhard@enotri.com</p>\r\n<h1>TWC IMPORTS</h1>\r\n<p>Mr. Richard Kitowski<br />18205 KENNEDY RD., BOX 36<br />L7K 3L3<br />CALEDON - ONTARIO<br />CANADA<br />(416) 809 9463<br />ric@thewinecoaches.com</p>\r\n<h1><br />PASSION GOURMET CA</h1>\r\n<p>Mr. Jose Lopez<br />42029 SPS ROY<br />H2W 2T3<br />MONTR&Eacute;AL - QUEBEC<br />www.passiongourmet.ca<br />jose@passiongourmet.ca</p>\r\n<h1><br />DESIRS DE PROVENCE INC<br />(Gastronomic goods)</h1>\r\n<p>Mr. Robert Valois<br />435 AVENUE MERCILLE<br />J4P 2L6<br />SAINT-LAMBERT-QUEBEC<br />CANADA<strong><em>&nbsp;</em></strong><br />(450) 671 6861<br />robertvalois@videotron.ca</p>\r\n<h1><br />PASQUALE BROS DOWNTOWN LTD<br />(Gastronomic goods)</h1>\r\n<p>Mrs. Anna Marie Kalcevich<br />16 GOODRICH RD<br />ON M8Z 4Z8<br />ETOBICOKE<br />ONTARIO CANADA<strong><em>&nbsp;</em></strong><br />www.pasqualebros.com<br />goodfood@pasqualebros.com</p>', 6),
(42, 0, 0, 'EUA', '<strong>MONOVERDE IMPORTS LLC</strong>\r\n\r\nSr. John Cancilla\r\n230 MADISON ST-ST1C\r\nOAKLAND, CA 9460-4520\r\nEE.UU.\r\n91 714 08 65\r\n1 (626) 414-4150\r\n\r\n<strong>ANDREW BELL SELECTION/ WINE SYMPHONY INC.</strong>\r\n\r\nMr. Andrew Bell\r\n580 BROADWAY, SUITE 716\r\nNEW YORK , NY 10012\r\nEE.UU.\r\n(212) 897-4125\r\nwww.winesymphonyinc.com\r\noffice@winesymphonyinc.com\r\n\r\n<strong style="font-size: 12px;">K.L.KELLER IMPORTS</strong>\r\n\r\nMrs. Kitty L. Keller\r\n230 MADISON ST.\r\n94607\r\nOAKLAND CALIFORNIA\r\nEE.UU.\r\n+1 (510) 839 7890\r\nwww.klkellerimports.com\r\nklkeller@ix.netcom.com\r\n\r\n<strong>\r\nOLE OLE FOODS INC.\r\n(Productos gastronómicos)</strong>\r\n\r\nMr. Conrad Adillon\r\n54 SCHUYLER STREET\r\nNJ 07109 BELLEVILLE - NJ\r\nEE.UU.<strong><em> </em></strong>\r\n(973) 759 0333\r\nwww.oleolefoods.com\r\nconrad@oleolefoods.com\r\n\r\n&nbsp;\r\n\r\n<strong>Hidalgo Imports\r\n</strong><a href="http://www.hidalgoimports.com/">www.hidalgoimports.com</a>\r\n6020 NW 84th Ave.\r\nMiami, FL 33166\r\n305 477 7737\r\n305 477 4471 fax\r\n<a href="file:///C:/Users/Enoturisme/Desktop/antonio@hidalgoimports.com">antonio@hidalgoimports.com</a>\r\n\r\n<strong>Kiddie Kiddie LLC </strong>\r\n2010 Washington Blvd\r\nBaltimore, MD 21230\r\nUSA\r\n301-322-4503 Ext. 139\r\n\r\n&nbsp;\r\n\r\n&nbsp;', 7),
(45, 1, 0, 'Mèxic', '<h1>INTERSYBARITE</h1>\r\n<p>Mr. Andres Gay<br />CALLE DOS 217<br />9070<br />GRANJAS SAN ANTONIO- MEXICO DF<br />MEXICO<br />+52 55 568 587 82<br />www.intersybarite.com<br />agay@intersybarite.com</p>\r\n<p>&nbsp;</p>', 10),
(43, 1, 0, 'EUA', '<p><strong>MONOVERDE IMPORTS LLC</strong></p>\r\n<p>Sr. John Cancilla<br /> 230 MADISON ST-ST1C<br /> OAKLAND, CA 9460-4520<br /> EE.UU.<br /> 91 714 08 65<br /> 1 (626) 414-4150</p>\r\n<p><strong>ANDREW BELL SELECTION/ WINE SYMPHONY INC.</strong></p>\r\n<p>Mr. Andrew Bell<br /> 580 BROADWAY, SUITE 716<br /> NEW YORK , NY 10012<br /> EE.UU.<br /> (212) 897-4125<br /> www.winesymphonyinc.com<br /> office@winesymphonyinc.com</p>\r\n<p><strong style="font-size: 12px;">K.L.KELLER IMPORTS</strong></p>\r\n<p>Mrs. Kitty L. Keller<br /> 230 MADISON ST.<br /> 94607<br /> OAKLAND CALIFORNIA<br /> EE.UU.<br /> +1 (510) 839 7890<br /> www.klkellerimports.com<br /> klkeller@ix.netcom.com</p>\r\n<p><strong><br /> OLE OLE FOODS INC.<br /> (Productos gastron&oacute;micos)</strong></p>\r\n<p>Mr. Conrad Adillon<br /> 54 SCHUYLER STREET<br /> NJ 07109 BELLEVILLE - NJ<br /> EE.UU.<strong><em>&nbsp;</em></strong><br /> (973) 759 0333<br /> www.oleolefoods.com<br /> conrad@oleolefoods.com</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Hidalgo Imports <br /> </strong><a href="http://www.hidalgoimports.com/">www.hidalgoimports.com</a><br /> 6020 NW 84th Ave.<br /> Miami, FL 33166<br /> 305 477 7737<br /> 305 477 4471 fax<br /> <a href="file:///C:/Users/Enoturisme/Desktop/antonio@hidalgoimports.com">antonio@hidalgoimports.com</a><br /> <br /> <br /> <strong>Kiddie Kiddie LLC </strong><br /> 2010 Washington Blvd<br /> Baltimore, MD 21230<br /> USA<br /> 301-322-4503 Ext. 139<br /> <br /></p>\r\n<p>&nbsp;</p>', 7),
(44, 2, 0, 'EUA', '<h1>\r\n<p><strong>MONOVERDE IMPORTS LLC</strong></p>\r\n<p>Sr. John Cancilla<br /> 230 MADISON ST-ST1C<br /> OAKLAND, CA 9460-4520<br /> EE.UU.<br /> 91 714 08 65<br /> 1 (626) 414-4150</p>\r\n<p><strong>ANDREW BELL SELECTION/ WINE SYMPHONY INC.</strong></p>\r\n<p>Mr. Andrew Bell<br /> 580 BROADWAY, SUITE 716<br /> NEW YORK , NY 10012<br /> EE.UU.<br /> (212) 897-4125<br /> www.winesymphonyinc.com<br /> office@winesymphonyinc.com</p>\r\n<p>&nbsp;</p>\r\n<p><strong> K.L.KELLER IMPORTS</strong></p>\r\n<p>Mrs. Kitty L. Keller<br /> 230 MADISON ST.<br /> 94607<br /> OAKLAND CALIFORNIA<br /> EE.UU.<br /> +1 (510) 839 7890<br /> www.klkellerimports.com<br /> klkeller@ix.netcom.com</p>\r\n<p><strong><br /> OLE OLE FOODS INC.<br /> (Productos gastron&oacute;micos)</strong></p>\r\n<p>Mr. Conrad Adillon<br /> 54 SCHUYLER STREET<br /> NJ 07109 BELLEVILLE - NJ<br /> EE.UU.<strong><em>&nbsp;</em></strong><br /> (973) 759 0333<br /> www.oleolefoods.com<br /> conrad@oleolefoods.com</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Hidalgo Imports <br /> </strong><a href="http://www.hidalgoimports.com/">www.hidalgoimports.com</a><br /> 6020 NW 84th Ave.<br /> Miami, FL 33166<br /> 305 477 7737<br /> 305 477 4471 fax<br /> <a href="file:///C:/Users/Enoturisme/Desktop/antonio@hidalgoimports.com">antonio@hidalgoimports.com</a><br /> <br /> <br /> <strong>Kiddie Kiddie LLC </strong><br /> 2010 Washington Blvd<br /> Baltimore, MD 21230<br /> USA<br /> 301-322-4503 Ext. 139<br /> <br /></p>\r\n<p>&nbsp;</p>\r\n<p class="MsoNormal" style="margin-top: 4.5pt; margin-right: 0cm; margin-bottom: 9.0pt; margin-left: 0cm; line-height: normal; mso-outline-level: 1;">&nbsp;</p>\r\n<p class="MsoNormal" style="margin-bottom: 12.0pt;"><span lang="EN-US">&nbsp;</span></p>\r\n<p class="MsoNormal"><span lang="EN-US">&nbsp;</span></p>\r\n</h1>', 7),
(46, 0, 0, 'México', '<h1>INTERSYBARITE</h1>\r\n<p>Mr. Andres Gay<br />CALLE DOS 217<br />9070<br />GRANJAS SAN ANTONIO- MEXICO DF<br />MEXICO<br />+52 55 568 587 82<br />www.intersybarite.com<br />agay@intersybarite.com</p>', 10),
(47, 2, 0, 'México', '<h1>INTERSYBARITE</h1>\r\n<p>Mr. Andres Gay<br />CALLE DOS 217<br />9070<br />GRANJAS SAN ANTONIO- MEXICO DF<br />MEXICO<br />+52 55 568 587 82<br />www.intersybarite.com<br />agay@intersybarite.com</p>', 10),
(342, 1, 0, 'Colòmbia', '<p>\r\n<h1>CLOS, LTDA</h1>\r\n<p style="font-size: 11.818181991577148px;">Sr. Juan Antonio Zuleta<br />CRA 4# 69-13 OF 302<br />BOGOT&Aacute; - COL&Ograve;MBIA<br />Tel. 634 821 891</p>\r\n</p>', 6),
(374, 0, 69, 'Hungria', '<h1 style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">Comerciante de Vinos</h1>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">Szeredi Zsolt</p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">www.vinocastillo.com</p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">H-1089 Budapest, Diószeghy S. u. 44/b</p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">+36 30 98 38 018</p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">comerciantedevino@gmail.com</p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;"></p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;"></p>', 50),
(376, 2, 71, 'Hungria', '<h1 style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">Comerciante de Vinos</h1>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">Szeredi Zsolt</p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">www.vinocastillo.com</p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">H-1089 Budapest, Diószeghy S. u. 44/b</p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">+36 30 98 38 018</p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">comerciantedevino@gmail.com</p>\r\n<p style="margin: 0cm 0cm 7.5pt; line-height: 12.75pt; text-align: left;"></p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;"></p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;"></p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;"></p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;"></p>', 50),
(379, 0, 0, 'Venezuela', '<h1>DI - MASI VINOS</h1>\r\n<p>Sr. Franco Masi</p>\r\n<p>Av. Fentre Av. G. Principal de la Carlota</p>\r\n<p>Qta. n&ordm; 1 Urbanizaci&oacute;n La Carlota Caracas</p>\r\n<ol>\r\n<li style="text-align: left;">Venezuela</li>\r\n</ol>\r\n<p style="font-size: 12px;">(0212) 234 - 1369</p>\r\n<p>www.di-masi.com</p>', 60),
(378, 1, 70, 'Hungria', '<h1 style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">Comerciante de Vinos</h1>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">Szeredi Zsolt</p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">www.vinocastillo.com</p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">H-1089 Budapest, Diószeghy S. u. 44/b</p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">+36 30 98 38 018</p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;">comerciantedevino@gmail.com</p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;"></p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;"></p>\r\n<p style="line-height: 12.75pt; margin: 0cm 0cm 7.5pt 0cm;"></p>', 50),
(380, 1, 0, 'Venezuela', '<h1>DI - MASI VINOS</h1>\r\n<p style="font-size: 12px;">Sr. Franco Masi</p>\r\n<p style="font-size: 12px;">Av. Fentre Av. G. Principal de la Carlota</p>\r\n<p style="font-size: 12px;">Qta. n&ordm; 1 Urbanizaci&oacute;n La Carlota Caracas</p>\r\n<ol style="font-size: 12px;">\r\n<li style="text-align: left;">Venezuela</li>\r\n</ol>\r\n<p style="font-size: 12px;">(0212) 234 - 1369</p>\r\n<p style="font-size: 12px;">www.di-masi.com</p>', 60),
(381, 2, 0, 'Venezuela', '<h1>DI - MASI VINOS</h1>\r\n<p style="font-size: 12px;">Sr. Franco Masi</p>\r\n<p style="font-size: 12px;">Av. Fentre Av. G. Principal de la Carlota</p>\r\n<p style="font-size: 12px;">Qta. nº 1 Urbanización La Carlota Caracas</p>\r\n\r\n<ol style="font-size: 12px;">\r\n	<li style="text-align: left;">Venezuela</li>\r\n</ol>\r\n<p style="font-size: 12px;">(0212) 234 - 1369</p>\r\n<p style="font-size: 12px;">www.di-masi.com</p>', 60),
(341, 0, 0, 'Colombia', '<p>&nbsp;</p>\r\n<h1>CLOS, LTDA</h1>\r\n<p style="font-size: 11.818181991577148px;">Sr. Juan Antonio Zuleta<br />CRA 4# 69-13 OF 302<br />BOGOT&Aacute; - COLOMBIA<br />Tel. 634 821 891<br /><br /></p>\r\n<p>&nbsp;</p>', 6),
(298, 0, 0, 'Argentina', '<h1>LA CAVA ESCONDIDA, S.A.</h1>\r\n<p>Mr. Santiago Uman<br />CERVI&Ntilde;O 3926 15&ordm;A (1425)<br />C.A.B.A. ARGENTINA<br />ARGENTINA<br />suman@lacavaescondida.com</p>', 3),
(299, 1, 0, 'Argentina', '<h1>LA CAVA ESCONDIDA, S.A.</h1>\r\n<p>Mr. Santiago Uman<br />CERVI&Ntilde;O 3926 15&ordm;A (1425)<br />C.A.B.A. ARGENTINA<br />ARGENTINA<br />suman@lacavaescondida.com</p>', 3),
(300, 2, 0, 'Argentina', '<h1>LA CAVA ESCONDIDA, S.A.</h1>\r\n<p>Mr. Santiago Uman<br />CERVI&Ntilde;O 3926 15&ordm;A (1425)<br />C.A.B.A. ARGENTINA<br />ARGENTINA<br />suman@lacavaescondida.com</p>', 3),
(301, 0, 0, 'Nueva Zelanda', '<h1>WINE CIRCLE LTD</h1>\r\n<p>Mr. Chris Carrad<br />SHOP 2, 329 A<br />SH16<br />HUAPAI (AUCKLAND)<br />NUEVA ZELANDA<br />www.winecircle.co.nz<br />winecircle@xtra.co.nz</p>\r\n<p>&nbsp;</p>', 11),
(302, 1, 0, 'Nova Zelanda', '<h1>WINE CIRCLE LTD</h1>\r\n<p>Mr. Chris Carrad<br />SHOP 2, 329 A<br />SH16<br />HUAPAI (AUCKLAND)<br />NUEVA ZELANDA<br />www.winecircle.co.nz<br />winecircle@xtra.co.nz</p>', 11),
(303, 2, 0, 'New Zealand', '<h1>WINE CIRCLE LTD</h1>\r\n<p>Mr. Chris Carrad<br />SHOP 2, 329 A<br />SH16<br />HUAPAI (AUCKLAND)<br />NUEVA ZELANDA<br />www.winecircle.co.nz<br />winecircle@xtra.co.nz</p>', 11),
(307, 0, 69, 'Eslovaquia', '<h1>EBAC SPOL.S R.O.</h1>\r\n<p>Mr. Boris Kosut<br />LEVICKA CESTA, 3<br />949 01<br />NITRA<br />ESLOVAQUIA<br />+421 (37) 655 7741<br />www.vinodeivini.sk<br />ebac@ebak.sk</p>', 20),
(308, 1, 70, 'Eslovàquia', '<h1>EBAC SPOL.S R.O.</h1>\r\n<p>Mr. Boris Kosut<br />LEVICKA CESTA, 3<br />949 01<br />NITRA<br />ESLOVAQUIA<br />+421 (37) 655 7741<br />www.vinodeivini.sk<br />ebac@ebak.sk</p>', 20),
(309, 2, 71, 'Slovakia', '<p>EBAC SPOL.S R.O.<br />Mr. Boris Kosut<br />LEVICKA CESTA, 3<br />949 01<br />NITRA<br />SLOVAKIA<br />+421 (37) 655 7741<br />www.vinodeivini.sk<br />ebac@ebak.sk</p>', 31),
(310, 0, 69, 'Estonia', '<h1>LIVIKO</h1>\r\n<p>Mr. Merli Hilimon<br />MASINA, 11<br />10141<br />TALLIN<br />ESTONIA<br />+372 66 78 052<br />merli.hilimon@liviko.ee</p>', 21),
(311, 1, 70, 'Estònia', '<h1>LIVIKO</h1>\r\n<p>Mr. Merli Hilimon<br />MASINA, 11<br />10141<br />TALLIN<br />EST&Ograve;NIA<br />+372 66 78 052<br />merli.hilimon@liviko.ee</p>', 21),
(312, 2, 71, 'Estonia', '<h1>LIVIKO</h1>\r\n<p>Mr. Merli Hilimon<br />MASINA, 11<br />10141<br />TALLIN<br />ESTONIA<br />+372 66 78 052<br />merli.hilimon@liviko.ee</p>', 18),
(313, 0, 69, 'Francia', '<h1>Contacto</h1>\r\n<h1>\r\n<p style="font-size: 12px; font-weight: normal;">e-mail: info@agustitorellomata.com</p>\r\n<p style="font-size: 12px; font-weight: normal;">Tel&eacute;fono: 00 34 93 891 11 73</p>\r\n</h1>', 23),
(344, 1, 0, 'Xina', '<p>&nbsp;</p>\r\n<h1>\r\n<blockquote style="font-size: 11.818181991577148px; font-weight: normal; line-height: 10.909090995788574px;"><strong style="font-size: 11.818181991577148px;">HONG KONG</strong></blockquote>\r\n</h1>\r\n<h1>EURO LINK GLOBAL</h1>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">Sra. Mariona Isern<br />4A Hang Lung House<br />HONG KONG - LA XINA<br />Telf. +852 3478 3882<br />Fax +852 3478 3880</p>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">&nbsp;</p>\r\n<blockquote style="font-size: 11.818181991577148px; font-weight: normal; line-height: 10.909090995788574px;">\r\n<p style="font-size: 11.818181991577148px;"><strong style="font-size: 11.818181991577148px;">PEQU&Iacute;N</strong></p>\r\n</blockquote>\r\n<h1>PASION INTERNATIONAL TRADING Co., LTD</h1>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">Sr. Alberto Pascual<br />32 Baiziwan Road, 3 A-506<br />PEQU&Iacute;N - LA XINA<br />Telf. 00.86.10.582.64.710<br />alberto@puente-asia.com</p>', 15),
(314, 1, 70, 'França', '<h1>Contacte</h1>\r\n<h1>\r\n<p style="font-size: 12px; font-weight: normal;">e-mail: info@agustitorellomata.com</p>\r\n<p style="font-size: 12px; font-weight: normal;">Tel&egrave;fon: 00 34 93 891 11 73</p>\r\n</h1>', 23),
(315, 2, 71, 'France', '<h1>Contact</h1>\r\n<h1>\r\n<p style="font-size: 12px; font-weight: normal;">e-mail: info@agustitorellomata.com</p>\r\n<p style="font-size: 12px; font-weight: normal;">Phone: 00 34 93 891 11 73</p>\r\n</h1>', 20),
(328, 0, 0, 'Filipinas', '<h1><strong>TERRY SELECTION, INC.</strong>&nbsp;</h1>\r\n<p>(Formerly Gourmet and Wine Experts, Inc.)</p>\r\n<p>Bldg. 14 La Fuerza Compound<br />2241 Don Chino Roces Ave.,<br />1231 Makati City, Philippines</p>\r\n<p>Tel Nos.: <br />(+632) 843 &ndash; 8897<br />(+632) 843 &ndash; 9395<br />(+632) 843 &ndash; 9139<br />loc. 402</p>\r\n<p>Fax No.:<br /> (+632) 843 &ndash; 8907</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 7),
(329, 1, 0, 'Filipines', '<h1><strong>TERRY SELECTION, INC.</strong>&nbsp;</h1>\r\n<p>(Formerly Gourmet and Wine Experts, Inc.)</p>\r\n<p>Bldg. 14 La Fuerza Compound<br />2241 Don Chino Roces Ave.,<br />1231 Makati City, Philippines</p>\r\n<p>Tel Nos.: <br />(+632) 843 &ndash; 8897<br />(+632) 843 &ndash; 9395<br />(+632) 843 &ndash; 9139<br />loc. 402</p>\r\n<p>Fax No.:<br /> (+632) 843 &ndash; 8907</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 7),
(330, 2, 0, 'Philippines', '<h1><strong>TERRY SELECTION, INC.</strong>&nbsp;</h1>\r\n<p>(Formerly Gourmet and Wine Experts, Inc.)</p>\r\n<p>Bldg. 14 La Fuerza Compound<br />2241 Don Chino Roces Ave.,<br />1231 Makati City, Philippines</p>\r\n<p>Tel Nos.: <br />(+632) 843 &ndash; 8897<br />(+632) 843 &ndash; 9395<br />(+632) 843 &ndash; 9139<br />loc. 402</p>\r\n<p>Fax No.:<br /> (+632) 843 &ndash; 8907</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 11),
(343, 2, 0, 'Colombia', '<p>\r\n<h1>CLOS, LTDA</h1>\r\n<p style="font-size: 11.818181991577148px;">Mr. Juan Antonio Zuleta<br />CRA 4# 69-13 OF 302<br />BOGOT&Aacute; - COLOMBIA<br />Phone number: 634 821 891</p>\r\n</p>', 6),
(345, 0, 0, 'China', '<p>&nbsp;</p>\r\n<h1>\r\n<blockquote style="font-size: 11.818181991577148px; font-weight: normal; line-height: 10.909090995788574px;"><strong style="font-size: 11.818181991577148px;">HONG KONG</strong></blockquote>\r\n</h1>\r\n<h1>EURO LINK GLOBAL</h1>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">Sra. Mariona Isern<br />4A Hang Lung House<br />HONG KONG - CHINA<br />Telf. +852 3478 3882<br />Fax +852 3478 3880</p>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">&nbsp;</p>\r\n<blockquote style="font-size: 11.818181991577148px; font-weight: normal; line-height: 10.909090995788574px;">\r\n<p style="font-size: 11.818181991577148px;"><strong style="font-size: 11.818181991577148px;">PEQU&Iacute;N</strong></p>\r\n</blockquote>\r\n<h1>PASION INTERNATIONAL TRADING Co., LTD</h1>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">Sr. Alberto Pascual<br />32 Baiziwan Road, 3 A-506<br />PEQU&Iacute;N - CHINA<br />Telf. 00.86.10.582.64.710<br />alberto@puente-asia.com</p>\r\n<p>&nbsp;</p>', 15),
(346, 2, 0, 'China', '<p>&nbsp;</p>\r\n<h1>\r\n<blockquote style="font-size: 11.818181991577148px; font-weight: normal; line-height: 10.909090995788574px;"><strong style="font-size: 11.818181991577148px;">HONG KONG</strong></blockquote>\r\n</h1>\r\n<h1>EURO LINK GLOBAL</h1>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">Sra. Mariona Isern<br />4A Hang Lung House<br />HONG KONG - CHINA<br />Phone number: +852 3478 3882<br />Fax +852 3478 3880</p>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">&nbsp;</p>\r\n<blockquote style="font-size: 11.818181991577148px; font-weight: normal; line-height: 10.909090995788574px;">\r\n<p style="font-size: 11.818181991577148px;"><strong style="font-size: 11.818181991577148px;">BEIJING</strong></p>\r\n</blockquote>\r\n<h1>PASION INTERNATIONAL TRADING Co., LTD</h1>\r\n<p style="font-size: 11.818181991577148px; font-weight: normal;">Sr. Alberto Pascual<br />32 Baiziwan Road, 3 A-506<br />BEIJING - CHINA<br />Phone number: 00.86.10.582.64.710<br />alberto@puente-asia.com</p>\r\n<p>&nbsp;</p>', 15),
(359, 0, 117, 'Melilla', '<blockquote style="font-size: 12px;"><strong style="font-size: 12px;">MELILLA<br /></strong></blockquote>\r\n<h1>MELIANSE S.L.</h1>\r\n<p style="font-size: 12px;">ANGEL PELAEZ<br />C/ Mejico, 38<br />52003 MELILLA<br />Tel.: 952 696 072<br />Fax: 952 678 433<br />melianse@hotmail.com</p>', 40),
(360, 1, 117, 'Melilla', '<blockquote style="font-size: 12px;"><strong style="font-size: 12px;">MELILLA<br /></strong></blockquote>\r\n<h1>MELIANSE S.L.</h1>\r\n<p style="font-size: 12px;">ANGEL PELAEZ<br />C/ Mejico, 38<br />52003 MELILLA<br />Tel.: 952 696 072<br />Fax: 952 678 433<br />melianse@hotmail.com</p>', 40),
(361, 2, 117, 'Melilla', '<blockquote style="font-size: 12px;"><strong style="font-size: 12px;">MELILLA<br /></strong></blockquote>\r\n<h1>MELIANSE S.L.</h1>\r\n<p style="font-size: 12px;">ANGEL PELAEZ<br />C/ Mejico, 38<br />52003 MELILLA<br />Tel.: 952 696 072<br />Fax: 952 678 433<br />melianse@hotmail.com</p>', 40),
(365, 2, 71, 'Cyprus', '<h1>Tierra de Campos Fuente Escondida</h1>\r\n<p style="font-size: 12px; text-align: justify;">Mr. David Castrillo<br />Ammochostou str 27</p>\r\n<p style="font-size: 12px; text-align: justify;">1016 Medieval</p>\r\n<p style="font-size: 12px; text-align: justify;">Nicosia<br /><span style="font-size: 10.0pt;">357.99523127</span><br />www.tierradecamposcyprus.com</p>', 14),
(363, 0, 69, 'Chipre', '<h1>Tierra de Campos Fuente Escondida</h1>\r\n<p style="font-size: 12px; text-align: justify;">Mr. David Castrillo<br />Ammochostou str 27</p>\r\n<p style="font-size: 12px; text-align: justify;">1016 Medieval</p>\r\n<p style="font-size: 12px; text-align: justify;">Nicosia<br /><span style="font-size: 10.0pt;">357.99523127</span><br />www.tierradecamposcyprus.com</p>', 14),
(364, 1, 70, 'Xipre', '<h1>Tierra de Campos Fuente Escondida</h1>\r\n<p style="font-size: 12px; text-align: justify;">Mr. David Castrillo<br />Ammochostou str 27</p>\r\n<p style="font-size: 12px; text-align: justify;">1016 Medieval</p>\r\n<p style="font-size: 12px; text-align: justify;">Nicosia<br /><span style="font-size: 10.0pt;">357.99523127</span><br />www.tierradecamposcyprus.com</p>', 14);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `objects` text
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `gallery`
--

INSERT INTO `gallery` (`id`, `title`, `objects`) VALUES
(1, 'cavas-grid', NULL),
(2, 'solid-blanc', '[{"alt":"","title":"","isThumb":0,"id":"99690d21c78c91f992280e9faa6fd631","img":"content\\/f625de8d03aca1c8e948bf535ee1773e.jpg","thumb":"content\\/0.96436700-15506983151e575edd609d72496a6d324df5b0b753w_450h_.jpg","type":"image"},{"alt":"","title":"solid-blanc.jpg","isThumb":0,"id":"25a5ac71df7bbb4565164bc58fab5201","img":"content\\/1c58be4b38e0e8c7148bad288a3b7ddf.jpg","thumb":"content\\/0.04307000-15541050610c282261c947c1af44d7a9914348b9edw_450h_.jpg","type":"image"},{"alt":"","title":"SOLID BLANC.jpg","isThumb":"1","id":"955d40c4f99466b78deb68940dae1293","img":"content\\/e8bef9d5dd32dc3fcadf302ebb14ef19.jpg","thumb":"content\\/0.59708400-15816825773584c757e63a94f4c803eda3b9e835e9w_450h_.jpg","type":"image"}]'),
(3, 'solid-rosat', '[{"alt":"","title":"","isThumb":0,"id":"2fc18991fe4ac727bb6ade222766994e","img":"content\\/b9d21ef3146696538359c8aa1bbd7ff6.jpg","thumb":"content\\/0.04095800-1550698320ec4a2a7ed061248ba9bd39284c0f26caw_450h_.jpg","type":"image"},{"alt":"","title":"solid-rosat.jpg","isThumb":0,"id":"a5e5b0233867dff50cd1f6d50d5b07a2","img":"content\\/73bc092b55701058f5442776fd7ba51b.jpg","thumb":"content\\/0.73465100-1554105073c9c0b44ec80386e4f89226b4febb148dw_450h_.jpg","type":"image"},{"alt":"","title":"SOLID ROSAT.jpg","isThumb":"1","id":"469e88bbd37f13b209c09930d874e52b","img":"content\\/c97d3f756917758436e09e671aae5a44.jpg","thumb":"content\\/0.01180700-1581682696910c868739a0f4d85d340f0a0cdbd99bw_450h_.jpg","type":"image"}]'),
(4, 'vinagres-cava', '[{"alt":"","title":"","isThumb":0,"id":"98d95f4a32403c98f57a5f8bd4308a99","img":"content\\/963cfa3ae746d8092d84d4e66737d081.jpg","thumb":"content\\/0.52435600-1550698400955b9c8de3d440b62507d5e5e33daf26w_450h_.jpg","type":"image"},{"alt":"","title":"sec-de-cava.jpg","isThumb":0,"id":"4a6607c680cd687c143c157f71e019da","img":"content\\/1284ffb35ffad59648ed4b5bbeb83c97.jpg","thumb":"content\\/0.34345400-155410511566093eab9f85ad8100ddd4b40addddf0w_450h_.jpg","type":"image"},{"alt":"","title":"VINEAGRE SEC DE CAVA web.jpg","isThumb":"1","id":"7f2eb0dff4417a71929a8659b0d12bae","img":"content\\/a3e8241f111e12df910894519d19cad3.jpg","thumb":"content\\/0.74592700-1581682469f8a6db80b595860bf3e591e053c834a0w_450h_.jpg","type":"image"}]'),
(5, 'vinagres-balsamic', '[{"alt":"","title":"","isThumb":0,"id":"3d25e5575be48b1d5e03b432441d6db2","img":"content\\/e960577e8d9b49894773237e3e23d8b0.jpg","thumb":"content\\/0.54607300-1550698404e15995347ff4d9aab0e0b1b68d78c1f1w_450h_.jpg","type":"image"},{"alt":"","title":"balsa\\u0300mic-de-cava.jpg","isThumb":0,"id":"e50ede17200b5f3e5a78499c70ff9e6f","img":"content\\/4bb8345f56cdf5987f70a736cd64e251.jpg","thumb":"content\\/0.26934000-155410509362bedc8502c33169bca6b2a96fa6182cw_450h_.jpg","type":"image"},{"alt":"","title":"VINAGRE BALSA\\u0301MICO DE CAVA web.jpg","isThumb":"1","id":"5ddf799e902cbe009245d4701576754d","img":"content\\/855420d0e8c7b02985fd0e2c2f91fecd.jpg","thumb":"content\\/0.09946500-158168217769f13b039ff71630eaeb5e4a93ae68f6w_450h_.jpg","type":"image"}]'),
(6, 'lesperit', '[{"alt":"","title":"","isThumb":0,"id":"0454a7e2af1cc3fc2c5a6cb9656e1d10","img":"content\\/c5696cf1135312cb37afb90730c068b4.jpg","thumb":"content\\/0.29581900-15506984527d41b1433c49e9b0b7aac437664ca305w_450h_.jpg","type":"image"},{"alt":"","title":"l''esperit.jpg","isThumb":0,"id":"0e1ed73ac0a30bd1eb0796c4ab728259","img":"content\\/16860e164c184437b9af2f10e2ce7e30.jpg","thumb":"content\\/0.23415600-1554105027a1b5d48c3aa60fba94eacdc3a9a473a2w_450h_.jpg","type":"image"},{"alt":"","title":"MARC DE CAVA L''ESPERIT.jpg","isThumb":"1","id":"90ef04b68d71ac52a7433f7538e493bf","img":"content\\/ffb201192ac5d41ef1c946c89a077ca1.jpg","thumb":"content\\/0.16336500-1581681923fb2bc16cac791f3446b0ecdf4336393fw_450h_.jpg","type":"image"}]'),
(7, 'eco-xic', '[{"alt":"","title":"","isThumb":0,"id":"a632a3a5caf620a98ddfe2c9b88028cb","img":"content\\/a97a3b273e55b41784ba09eb7aca6806.jpg","thumb":"content\\/0.35814300-15506984890f1290606696d59a12f132437d002617w_450h_.jpg","type":"image"},{"alt":"","title":"agusti\\u0301-torello\\u0301-mata-Xic.jpg","isThumb":"1","id":"fbb7b0f19a2dc730336b93aa309b3384","img":"content\\/15b5bc027c6f485cc10f4604361eda87.jpg","thumb":"content\\/0.42139800-1554105133fee8253b30e0e5bc062de19fbc8be4bcw_450h_.jpg","type":"image"}]'),
(8, 'eco-aptia', '[{"alt":"","title":"","isThumb":0,"id":"d62245be15b4b50e45398af1112e4d64","img":"content\\/3bae6e5c3ad339373378237904199eb6.jpg","thumb":"content\\/0.46445300-1550698497e7204fc4ed416e417c7ae04ea86cf092w_450h_.jpg","type":"image"},{"alt":"","title":"espantallops.jpg","isThumb":0,"id":"8ad3aaf67ab4756c84b330dec555b743","img":"content\\/0eb72fe7b59f5d320f1bbf7cee69c17c.jpg","thumb":"content\\/0.89734200-1580470386535fb991e1e137967ac9f3d25036681bw_450h_.jpg","type":"image"},{"alt":"","title":"ESPANTALLOPS.jpg","isThumb":"1","id":"b729959191dc2a83d9a13cfabe921237","img":"content\\/cc889d423a7c077525518fa0c3c15ad4.jpg","thumb":"content\\/0.65911400-15816828032a3e059755336b5c6524c6a1b504f623w_450h_.jpg","type":"image"}]'),
(9, 'cavas-kripta-gran', '[{"alt":"","title":"","isThumb":0,"id":"7987e4a1595a4d3fe437154db50b2299","img":"content\\/2f0f2bc12c5b6189777f82c99a170244.jpg","thumb":"content\\/0.41723000-15506985565698570b03b868b39e9c140ad13b959fw_450h_.jpg","type":"image"},{"alt":"","title":"kripta-gran-an\\u0303ada.jpg","isThumb":"1","id":"20d25627eb1f551e58a93c3facc2b7a0","img":"content\\/c4dea3e99169e6094a768fce8ca385e6.jpg","thumb":"content\\/0.63203700-1554104927f03cbd12afdede9c0673dfb848811f6bw_450h_.jpg","type":"image"}]'),
(10, 'cavas-kripta', '[{"alt":"","title":"","isThumb":0,"id":"bd75f387f94a843d9e5be5c57a2d0ac4","img":"content\\/73177aa11f35d467041760b00c3fb119.jpg","thumb":"content\\/0.48742800-155069857061a8e6dcea8654bc1893e29bcfcfd1d8w_450h_.jpg","type":"image"},{"alt":"","title":"kripta.jpg","isThumb":"1","id":"b19fc8b10e302faa73375c92470d7872","img":"content\\/4e5ebd21f61251ad3bbf268d07e37072.jpg","thumb":"content\\/0.49509100-155410494179da4c33caee614887ef6aac01b192ddw_450h_.jpg","type":"image"}]'),
(11, 'cavas-magnum', '[{"alt":"","title":"","isThumb":0,"id":"fb85f62d0c8263a3641169b869c3ef1e","img":"content\\/bfa5a1fec88fc03509bccb96a43fbe4e.jpg","thumb":"content\\/0.91951100-15506985938ff37844a3b41beb4e35c62174dd0ae4w_450h_.jpg","type":"image"},{"alt":"","title":"magnum-gran-reserva.jpg","isThumb":"1","id":"de15eddb96370bfd215392d853aeffaf","img":"content\\/b840bec442590e4465fd4ff3602dc40d.jpg","thumb":"content\\/0.09904400-1554104956d48e1f968205de1561dd1625d40528a2w_450h_.jpg","type":"image"}]'),
(12, 'cavas-gran-res-barrica', '[{"alt":"","title":"","isThumb":0,"id":"4dd555528204856139bcd21f75083783","img":"content\\/7b075e98f7705c3b5531fa867800c66f.jpg","thumb":"content\\/0.11785400-1550698647f1c96ff59c09fa90fbb8438dd8ac5d35w_450h_.jpg","type":"image"},{"alt":"","title":"gran-reserva-barrica.jpg","isThumb":"1","id":"9d2497ceb99ef86981d5cff8016805a0","img":"content\\/274d166b48aff4fec8ae3a96ae5658ba.jpg","thumb":"content\\/0.01962600-15541048902813a992365a035ef851bafb99c8cf5aw_450h_.jpg","type":"image"}]'),
(13, 'cavas-brut-nat-res', '[{"alt":"","title":"","isThumb":0,"id":"8b2b1d490ca1484a486c927bd52f22f7","img":"content\\/3fa25b18f3debca68d9c9be6ba4f4d0f.jpg","thumb":"content\\/0.38525600-1550698675bccb3763e5c0eb7935f0034fdbad4a6fw_450h_.jpg","type":"image"},{"alt":"","title":"brut-nature-gran-reserva.jpg","isThumb":0,"id":"c2692e0b9db3b041821294fccebbe177","img":"content\\/e0d2b38df2510691e5c4f971a37716bd.jpg","thumb":"content\\/0.96211300-1554104845d5b7f3daa6f3c8fa88541894cf4e662fw_450h_.jpg","type":"image"},{"alt":"","title":"atm_ubac_gr_75cl.jpg","isThumb":0,"id":"980baafe7dd5ce5acabf31276c110c92","img":"content\\/4dc98ffad70c5aa649156fb470c51ec6.jpg","thumb":"content\\/0.08421700-15749690651855850a9bc884da05446ee670bdd9afw_450h_.jpg","type":"image"},{"alt":"","title":"ubac-brut.jpg","isThumb":0,"id":"9becaaafe0fe3a6e4965df3d8456d20b","img":"content\\/9c8556a53627a86877def4330fe49937.jpg","thumb":"content\\/0.06969500-15804702983ad1747898ba7001d03ef8e00fd25ac5w_450h_.jpg","type":"image"},{"alt":"","title":"ubac gran reserva copia.jpg","isThumb":0,"id":"cf7ba5ceb4e1e5d102f878d35f08e6d1","img":"content\\/9c49ac9c2e2dbc0bc66f07f6f16f0b82.jpg","thumb":"content\\/0.50552500-15816736074005b8689ffb57b7eca0e4f52a714452w_450h_.jpg","type":"image"},{"alt":"","title":"UBAC GRAN RESERVA.jpg","isThumb":"1","id":"2eda84a02fb9f5da163f3357aa2af948","img":"content\\/84d52a1f482fee11b4b1c3ec6f674e12.jpg","thumb":"content\\/0.32496000-158201893716b4d6172c11e46757c7c6f829741731w_450h_.jpg","type":"image"}]'),
(14, 'cavas-brut-gran-res', '[{"alt":"","title":"","isThumb":0,"id":"6e6cebc0a8fdf15238dfec81773ea865","img":"content\\/bd0942f12f9884061c7027bf03b44bd4.jpg","thumb":"content\\/0.00587400-155069869894031d9fd60077e06e75489152702a51w_450h_.jpg","type":"image"},{"alt":"","title":"brut-gran-reserva.jpg","isThumb":"1","id":"e327a20c56498b1358b595edc92e144a","img":"content\\/6dcc7e2e5b30264028c9bacc3b29fb1e.jpg","thumb":"content\\/0.62486800-1554104828da1bcf5432cf92fd75874918d0fe519ew_450h_.jpg","type":"image"}]'),
(15, 'cavas-brut-res', '[{"alt":"","title":"","isThumb":0,"id":"a8affc2f971436b3086ee51b47d6ea06","img":"content\\/b64e36a79d1ce06bc990ed52b5600acb.jpg","thumb":"content\\/0.59562200-1550698716b20bf3375e3cceb9362661d7a8f2be1dw_450h_.jpg","type":"image"},{"alt":"","title":"brut-reserva.jpg","isThumb":"1","id":"c87008aa827dd37c5527190aae26cfad","img":"content\\/4ae9650c070678b81c1772613ec6c602.jpg","thumb":"content\\/0.44443400-1554104863481740c7184d254b5aa40976060a9cc5w_450h_.jpg","type":"image"}]'),
(16, 'cavas-rosat-trepat', '[{"alt":"","title":"","isThumb":0,"id":"95b0b8c99b2b9875cd17d7af25172455","img":"content\\/d86799efa882eca1f2bdde1ce8b243b0.jpg","thumb":"content\\/0.90882400-15506987320fd0abf6339bd05b4a8bec0b16d5b7f3w_450h_.jpg","type":"image"},{"alt":"","title":"rosat-trepat.jpg","isThumb":"1","id":"ca4699698593ce3c627d34963e96efe0","img":"content\\/3cfc9eb2e5c4acf3be11a902fc418e56.jpg","thumb":"content\\/0.04652600-15541049735b6b79b1ec60b1724ef08463b5c5afa4w_450h_.jpg","type":"image"}]'),
(17, 'cavas-375-brut', '[{"alt":"","title":"","isThumb":0,"id":"4479e7ca3470047e173fab745dc41a5f","img":"content\\/2e3fdc1581a92deb2fe913fd8a641aef.jpg","thumb":"content\\/0.51184200-15506987531b0bf9edf67d40aabaabd1e913799c6aw_450h_.jpg","type":"image"},{"alt":"","title":"375-Brut-Gran-Reserva.jpg","isThumb":"1","id":"6a6f9d48da61e4f9f5a8ecf6eac76159","img":"content\\/e64888c02f0065931239b88e7a1a68ae.jpg","thumb":"content\\/0.97406400-155410478083702f6ed5fb5b43d8d66de8592b6edcw_450h_.jpg","type":"image"}]'),
(18, 'cavas-375-rosat', '[{"alt":"","title":"","isThumb":0,"id":"e465be4eb30896282c39a6681087e98f","img":"content\\/42d7f2f05617475e1b53173dfa1c2c62.jpg","thumb":"content\\/0.61335400-1550698757a2e74bfb0f5601ab07fa213d1568315fw_450h_.jpg","type":"image"},{"alt":"","title":"375-Rosat-Trepat.jpg","isThumb":"1","id":"a25c907a517807ae5ba0d0c65388aeca","img":"content\\/da2e052102cff606847196aeced35bba.jpg","thumb":"content\\/0.27184400-1554104806137e9a9b3a14256b862237c4455e7dabw_450h_.jpg","type":"image"}]'),
(19, 'pantalla-home', '[{"alt":"","title":"HA3A2260.jpg","isThumb":0,"id":"98bddf17da2d92d080668d2fd0ab6790","img":"content\\/83e6eb47f513f7d080f5ef9d56e7df45.jpg","thumb":"content\\/0.26105500-15821097949757ea5e6745d4c3ecf0aea0362a0516w_450h_.jpg","type":"image"}]'),
(20, 'pantalla-filosofia', '[{"isThumb":0,"img":"content\\/29143975801b9225a8bb74a5674be45e.jpg","thumb":"content\\/0.51334900-15506994892709e51f6795ab6e7dabf8f7358d4609w_450h_.jpg","alt":"","title":"","type":"image","id":"8af9d1e9e6d9a9eca0c33016ef7d2105"}]'),
(21, 'pantalla-visitas', '[{"isThumb":0,"img":"content\\/b64c0d15ace5a1d98afc2448cc92e396.jpg","thumb":"content\\/0.04365900-1550699533088bd795456c4349418ecd085abb12f6w_450h_.jpg","alt":"","title":"","type":"image","id":"3d9cd99929cdaf0953191ea057736b77"},{"isThumb":0,"img":"content\\/4d660da7b11860ccaef7eb2abc539cdb.jpg","thumb":"content\\/0.01899700-1554104013dfe7783c68e1ad8f3518ba1a48c91fadw_450h_.jpg","alt":"","title":"peu-4-estaciones-400px.jpg","type":"image","id":"af5d5bc8c68a366f85af86c4d4ac0af8"},{"isThumb":0,"img":"content\\/5c5ac5ea5dd3ea3da2bcc3c9aab81775.jpg","thumb":"content\\/0.31771900-15541040149f6d604d32a0ce1a209c4b6b29694d37w_450h_.jpg","alt":"","title":"peu-4-estaciones.jpg","type":"image","id":"3f02a8f5f788ccf78f6d7e2a845d2466"}]'),
(22, 'pantalla-visitas-slider', '[{"isThumb":0,"img":"content\\/0741cce43ac942b25f10649dadbae278.jpg","thumb":"content\\/0.45622000-1550699542ddd9149a01d17d3f91bba62bc6c4aa36w_450h_.jpg","alt":"","title":"","type":"image","id":"3875b0d4c53da599ed7f2c09af953478"}]'),
(23, 'pantalla-kripta', '[{"alt":"","title":"KRIPTA-sediment-Can-Rosell-web.jpg","isThumb":0,"id":"8676026997ae5fd7e793ff6fc2d8ebed","img":"content\\/e196365f7e407c7b678d701f2095bad5.jpg","thumb":"content\\/0.40119600-1555328552a2e2d1b8497d82485aa570b0f5f4371aw_450h_.jpg","type":"image"},{"alt":"","title":"foto bodega Kripta web.jpg","isThumb":0,"id":"e8b426b53ce9be5ba6a5a696fcf4b058","img":"content\\/64f5b2c8666fd1c7d2bc2c42ea55f93a.jpg","thumb":"content\\/0.02655700-15923188677e1a2d292cc6371224caaf0472b81d33w_450h_.jpg","type":"image"},{"isThumb":0,"img":"content\\/bda49731b94bbe83deee11ebdf064f3b.jpg","thumb":"content\\/0.00274100-1599844462e6a0de3b1976593c121c39e139941385w_450h_.jpg","alt":"","title":"Bodega Kripta.jpg","type":"image","id":"85aca5903a45c46242f7aa909b256bf6"},{"isThumb":0,"img":"content\\/89de98c1acde818c2077236fc33cb568.jpg","thumb":"content\\/0.20037700-159984446242941681f77a5cecdfa6efa32b2b6451w_450h_.jpg","alt":"","title":"Kripta presentacio\\u0301.jpg","type":"image","id":"2ffea0eb5b49fdb16de43352de1401ce"}]'),
(24, 'documentos', '[{"isThumb":0,"img":"content\\/31a7782884f18159680dea1d80a74a10.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"BARRICA 2012 Esp.pdf","type":"file","id":"40f1bf14fde866ad0038b77e1fa8ef70"},{"isThumb":0,"img":"content\\/ef5ce2fbf5c65bd1ef38b639dd7327ef.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"BRUT GRAN RESERVA 2012 Esp.pdf","type":"file","id":"d46c23c0e7c94c57f64de01794e0966f"},{"isThumb":0,"img":"content\\/3135e9ee60c869c19d7c26d1ce3572be.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"BRUT NATURE 2012 Esp.pdf","type":"file","id":"3fae7b4780c3f103755df2b709cf8539"},{"isThumb":0,"img":"content\\/37198b4a2fb4df345c83d021a3498aee.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"BRUT RVA 2015 Esp.pdf","type":"file","id":"b11f2f4a59bcb3195c16916bd803e433"},{"isThumb":0,"img":"content\\/dabe15cd3493c251afc06bc06fcc226a.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"KRIPTA 2007 - 40 ANIVERSARIO Esp.pdf","type":"file","id":"3d9168b18a9c327f6fa5599f01039a89"},{"isThumb":0,"img":"content\\/16a07adb5b396d5dafa7560b28d61c2b.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"KRIPTA.pdf","type":"file","id":"a8f128a9a9148f94adc2f6a351a1f915"},{"isThumb":0,"img":"content\\/64aa75e7673d3133d1e578bd9b7828f5.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"MAGNUM 2010 Esp.pdf","type":"file","id":"0bec77be8dcd1cf162295b476ca44cd4"},{"isThumb":0,"img":"content\\/396520cc76b611a92b978bba1889eed5.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"ROSAT 2016 Esp.pdf","type":"file","id":"2393effd261b8ac86d417a9456d5f46a"},{"isThumb":0,"img":"content\\/e0558260da2703d4dc5ab612dabf8eb5.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"VI APTIA 2016 CAST-ANG.pdf","type":"file","id":"1dfe30a76968ba557a417c53a26972b9"},{"isThumb":0,"img":"content\\/0856ac2570412ad0bb4d470c28a5b502.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"VI XIC 2018 Esp.pdf","type":"file","id":"ad7dd8625236299785bb05932bf43d3e"},{"isThumb":0,"img":"content\\/46101b77917b26cfa784cd8cb27b60c5.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"XIC VERMELL 2016 Esp-Ang.pdf","type":"file","id":"37c26676c4733e88213ff18badcb263a"},{"isThumb":0,"img":"content\\/4072de9b75548f5b8fd591f6273e0424.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"BRUT NATURE GRAN RESERVA 2012 Esp.pdf","type":"file","id":"07263fe9381f67d8e2d4e4609ad47c36"},{"isThumb":0,"img":"content\\/4551f8dd06889173cd7e692249c98c6d.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"VI XIC VERMELL 2017CAT.pdf","type":"file","id":"614f9fdf229f21671fcca3929a10f270"},{"isThumb":0,"img":"content\\/b5e265a12695838b040541292c0a71ba.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"ROSAT 2016 .pdf","type":"file","id":"c6077dd961fc5d4be13d3b4e244080c4"},{"isThumb":0,"img":"content\\/a4e38ce985e8900c0a36aaf228f7b5c6.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"BRUT RVA 2016 .pdf","type":"file","id":"59e4641d0136f321676052255e2aed0d"},{"isThumb":0,"img":"content\\/88c951ead0618423a09008041eb7b281.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"BRUT NATURE 2013.pdf","type":"file","id":"656e24d66360d13333efacf7c4ac32e0"},{"isThumb":0,"img":"content\\/d861ecf20733bb8ea9f654c67ddd7b64.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"BARRICA 2014 Cat.pdf","type":"file","id":"b7f89ee00e2c89b544b72bbe5553859d"},{"isThumb":0,"img":"content\\/74e7a340b7d83240d7799d6b704592fa.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"VI XIC 2018.pdf","type":"file","id":"66355b2e923240b9d864f0275ca3344f"},{"isThumb":0,"img":"content\\/3f6610cf8f067ef45b38108075e4c396.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"KRIPTA 2010 Cat.pdf","type":"file","id":"ffd2e23a99d793fa1e7ca7c77f220e2e"},{"isThumb":0,"img":"content\\/5772718050b6fce234b57cce7b849f71.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"MAGNUM 2013.pdf","type":"file","id":"74f0088da1f35eb8969140281343ee2a"},{"isThumb":0,"img":"content\\/c544b94c7b5939fc4e872ee03ebfdd80.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"UBAC GR 2014 Cat.pdf","type":"file","id":"154d9de31e2ef95a428bded44630ba18"},{"isThumb":0,"img":"content\\/cbdbfff86cf3388a0af7450d2949a58b.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"VI ESPANTALLOPS 2017.pdf","type":"file","id":"7e9aa735ec4e7d311de7f4ed3451a805"},{"isThumb":0,"img":"content\\/fb2581a3805deccea33f47bbc3f25033.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"receptes solid.pdf","type":"file","id":"88fa79488b424509fa56a511e6ba6df5"},{"isThumb":0,"img":"content\\/29be07e2c7fd4fc4f1f478b7d66f4566.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"VI XIC ROSAT 2018 CAT.pdf","type":"file","id":"add20a60d87e5ecbdb3c8894e2d2d772"},{"isThumb":0,"img":"content\\/820ffe1683a76e858de3b918e4176252.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"ROSAT 2017 Cat.pdf","type":"file","id":"f8ef6ca0dfcb90bae08a21755c0ab2da"},{"isThumb":0,"img":"content\\/e97d2dbbd2feead67b0849f96296e130.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"MAGNUM 2014 Cat.pdf","type":"file","id":"a1bb458a238a5b5f833c945ec1146c68"},{"isThumb":0,"img":"content\\/1f3c12c9f2df8761bd35c3ad688fdf23.pdf","thumb":"images\\/fileformat\\/pdf.png","alt":"","title":"BRUT NATURE 2013.pdf","type":"file","id":"7742fdd57faf5d9e19023dda16a083d1"}]'),
(25, 'pantalla premios', '[{"isThumb":0,"img":"content\\/dccdc3725edff48a8dec8bad21971a9c.jpg","thumb":"content\\/0.69804000-155429348929ba2b49a7da986683e7b0b3c68c0571w_450h_.jpg","alt":"","title":"BARRICA-2016-CINVE.jpg","type":"image","id":"863eb214815f4b8f1a04ddb1ade8d57d"},{"isThumb":0,"img":"content\\/54ea471033228aac781883b87e24d2f5.jpg","thumb":"content\\/0.84458700-1554293490d241bb6d2605c0c5f39908bbcb147df3w_450h_.jpg","alt":"","title":"CWWSC-Barrica-2011-2017.jpg","type":"image","id":"0dc8cb6356b1669b0fb69686fb0cbb42"},{"isThumb":0,"img":"content\\/e1070925896c2f622757e5ddeb825278.jpg","thumb":"content\\/0.58265000-1554293491096af3f2fbc79bfd41a713b6dc39c869w_450h_.jpg","alt":"","title":"CWWSC-esperit-2016.jpg","type":"image","id":"22d4f211569ab1bcde5013bade36f88d"},{"isThumb":0,"img":"content\\/330834997186365a2df61de4c8f5ace2.jpg","thumb":"content\\/0.14349200-155429349298c9c24aaba4e73681c914d50f7dd40ew_450h_.jpg","alt":"","title":"CWWSC-Rosat-2014-2017.jpg","type":"image","id":"a1e7f6d8c1476c25feffbc134bed10db"},{"isThumb":0,"img":"content\\/928f521739fb21231e28d92fc1f99e41.jpg","thumb":"content\\/0.69648900-1554293492987ec61207cab91a3c4ac1dcb96e2d18w_450h_.jpg","alt":"","title":"decanter-2017.jpg","type":"image","id":"02403eaac47e1b72d957a6c51054dd9c"},{"isThumb":0,"img":"content\\/e519817b3954aee41648eb6f2d719a87.jpg","thumb":"content\\/0.42292800-15542934931e2cca55706953c8ff9a50eb32318344w_450h_.jpg","alt":"","title":"Kripta-2008-Diploma-Medalla-ORO-CIVAS-2016-54.jpg","type":"image","id":"f413d735b9da6ebac8c449f42bc409f4"},{"isThumb":0,"img":"content\\/bc83fe0684ef4c355296501ac04ce0f7.jpg","thumb":"content\\/0.20435200-1554293494c81e1c616313ee7910e5ecd7be7a1142w_450h_.jpg","alt":"","title":"KRIPTA-2016-CINVE.jpg","type":"image","id":"c48817f293030ed17f0913b497e0a991"},{"isThumb":0,"img":"content\\/7872c6caa335ae18d9c600d633fabd7c.jpg","thumb":"content\\/0.55958900-1554293495a3a4f288d5d0333ae8ce37971d80e58dw_450h_.jpg","alt":"","title":"KRIPTA-2016.jpg","type":"image","id":"351c61008d5ad764a03060c8d7b4344a"},{"isThumb":0,"img":"content\\/5f4bf4d735d9247e55afc6916ef7e118.jpg","thumb":"content\\/0.42700800-1554293496eaab78550645342df1dfd3d2b1c4dd10w_450h_.jpg","alt":"","title":"premio-XIC-20151-e1455723924966.jpg","type":"image","id":"6cdcd5b3bb91ead6dbf9ddecebea53cb"},{"isThumb":0,"img":"content\\/e943cf2c12ee7fe47a22e2d151594d85.jpg","thumb":"content\\/0.27711800-1554293497364b55d6229e264e12f3b557b0388dacw_450h_.jpg","alt":"","title":"premios-magnum-2015-ORO.jpg","type":"image","id":"8373e69b8691fbb5e8eee1d56478a38c"},{"isThumb":0,"img":"content\\/dc46b7182853146453b37fdf4492effc.jpg","thumb":"content\\/0.11681300-1554293498f142a7c933165a4998145fcc032b8444w_450h_.jpg","alt":"","title":"Premis-me-gusta_1-2015.jpg","type":"image","id":"d06eca7a1bc358ee7bc9dd730d1296b7"},{"isThumb":0,"img":"content\\/4453d708df310e9cb3de6cb0c6a1aa14.jpg","thumb":"content\\/0.03682700-1554293499c2d5027c77590ea3756d30c725f26b51w_450h_.jpg","alt":"","title":"Premis-me-gusta_2-2015-e1455723668545.jpg","type":"image","id":"f2cf704d21929c963c8a5917217bf207"},{"isThumb":0,"img":"content\\/8fbe5f05f2cfafc911088ff77fb33083.jpg","thumb":"content\\/0.84728700-155429349926d6d8d45a71226e9f55d86afb05da51w_450h_.jpg","alt":"","title":"Premis-me-gusta_3-2015-e1455723737596.jpg","type":"image","id":"f04dbc89d9f1862910e428113d5061c3"},{"isThumb":0,"img":"content\\/507c95135a8bf35e64110d2dd19dc9cb.jpg","thumb":"content\\/0.70845100-15542935005a4a0193bf49392b9cd6159522540beaw_450h_.jpg","alt":"","title":"premis-me-gusta-MAGNUM-2016.jpg","type":"image","id":"f61c1caf817bb716ca2419fdd42dab8c"},{"isThumb":0,"img":"content\\/f19f5ad9ad42ca7e5ae2d30c4550483c.jpg","thumb":"content\\/0.88190800-155429350190c06c2f6458f05a560ac2114255a73cw_450h_.jpg","alt":"","title":"puntuacio.jpg","type":"image","id":"fc61461e35283f882969b053bd1dc888"},{"isThumb":0,"img":"content\\/2960a27f19da94956e037737028487e6.jpg","thumb":"content\\/0.52637200-15542935026bdd0e3c08c5e6c2be9168e828aed9fcw_450h_.jpg","alt":"","title":"VINUM-NATURE-Aptia-2013.jpg","type":"image","id":"d05c92bb29d82962529d60fe35c82db0"},{"isThumb":0,"img":"content\\/5be82de9c604ca687bfd8fd3f10f27b9.jpg","thumb":"content\\/0.40464800-155429350370e0d4f199de932d222805c152730f8fw_450h_.jpg","alt":"","title":"Vivino-Wine-Style-awards-2014-Barrica.jpg","type":"image","id":"568056e28cd08ebadea057916ce365a2"},{"isThumb":0,"img":"content\\/59831f2ef3c0dda3f264617dbe571cb1.jpg","thumb":"content\\/0.17055500-15542935040a49c4b28beb72e5eb1066a21d13d245w_450h_.jpg","alt":"","title":"Vivino-Wine-Style-awards-2014-Kripta.jpg","type":"image","id":"170afe99955ccedec764f3a061bffca4"},{"isThumb":0,"img":"content\\/720b5b3cf0dc36860091809a24d53ff1.png","thumb":"content\\/0.97189200-155429350472afbe83af05f6ba23e999276aabbddcw_450h_.png","alt":"","title":"Vivinos-2017-Wine-Style-Awards.png","type":"image","id":"40c1376826d0b9da172a78cd070b8c58"}]'),
(26, 'pantall el origen', '[{"alt":"","title":"img-subzonas-depresiondelpenedes.jpg","isThumb":0,"id":"84d8b5452284ca01107a9bfe898482a2","img":"content\\/3501be95e6f447d8570b5b94e5e074f8.jpg","thumb":"content\\/0.56254500-155440726871dfc2f38570c7d9e361b4cfb5f3cd69w_450h_.jpg","type":"image"},{"alt":"","title":"img-subzonas-sierralitoral.jpg","isThumb":0,"id":"e09b00c419ff3f457be43e883748dbb2","img":"content\\/9634f9b8890261815839e8efc7a0c9a4.jpg","thumb":"content\\/0.14570700-1554407562134d41189e9ed0ec8d17140f608e5857w_450h_.jpg","type":"image"},{"alt":"","title":"img-subzonas-sierraprelitoral.jpg","isThumb":0,"id":"9c81d2a2ca4b05e55a6ce45b3c5e299b","img":"content\\/e16c405eca1539e47ff92d24f17537a8.jpg","thumb":"content\\/0.32372600-15544075986650892af25427cfb38c69e2d8ea9b99w_450h_.jpg","type":"image"},{"alt":"","title":"img-subzonas.jpg","isThumb":0,"id":"d3c12589e5dfa3eccb20d0be665717f8","img":"content\\/356c4ad9c05934030bddc2dd97477aca.jpg","thumb":"content\\/0.78491400-1555405248f813b7dd555372af34570939d2bb7ee9w_450h_.jpg","type":"image"}]'),
(27, 'pantalla variedad aut', '[{"isThumb":0,"img":"content\\/85028caeab5547a3b23d14f499252441.jpg","thumb":"content\\/0.92612200-155440827929f22db95d55ed6e30c7978a1e63e20fw_450h_.jpg","alt":"","title":"img-variedadesautoctonas-macabeo1.jpg","type":"image","id":"4254d00359f78fcefeee1e6023f46f10"},{"isThumb":0,"img":"content\\/801b75aea3247894b61ec1ab952daefc.jpg","thumb":"content\\/0.94301700-15544082837b93f9f6cf5f82768b9c5f28dabb354fw_450h_.jpg","alt":"","title":"img-variedadesautoctonas-macabeo2.jpg","type":"image","id":"8d01f61c30e3d39322d3f26242829c6a"},{"isThumb":0,"img":"content\\/5f48200a993340c5ef36dbf447c74880.jpg","thumb":"content\\/0.46808500-15544082871e549f1f5521694e629216c19ec5be49w_450h_.jpg","alt":"","title":"img-variedadesautoctonas-parellada1.jpg","type":"image","id":"b2133d9b65a82cdbeeab2ad4b28de5c0"},{"isThumb":0,"img":"content\\/09601bfaa267a183669568446a848a0e.jpg","thumb":"content\\/0.99007600-15544083021b4c366054f81ca4c93bc53b280572c7w_450h_.jpg","alt":"","title":"img-variedadesautoctonas-parellada2.jpg","type":"image","id":"77c6160cd20bac0e70b112223b0794d2"},{"isThumb":0,"img":"content\\/f0409808aa409627b04c7346278d0c0f.jpg","thumb":"content\\/0.41685900-15544083153423a0b77a0e50dc060ca2a12c008945w_450h_.jpg","alt":"","title":"img-variedadesautoctonas-trepat1.jpg","type":"image","id":"f09b8589b6a83e3c81a12463253cb7fb"},{"isThumb":0,"img":"content\\/d27fac47b7c06f8f8ecb2f09eb7b23be.jpg","thumb":"content\\/0.70063100-15544083285c84405b59ea47b2de65c5ae6cd147c7w_450h_.jpg","alt":"","title":"img-variedadesautoctonas-trepat2.jpg","type":"image","id":"2a568a6913f0c906dc9193d6ae6bb256"},{"isThumb":0,"img":"content\\/c44cb34f7c707f399586bff69bb7ccb8.jpg","thumb":"content\\/0.46592800-155440834131137ead8ee8ea7997bb63ad1ad52f2cw_450h_.jpg","alt":"","title":"img-variedadesautoctonas-xarello1.jpg","type":"image","id":"51636cbded52e7679523cd98bff1e044"},{"isThumb":0,"img":"content\\/9096e92ec2f39a306afe5d73a9bf8651.jpg","thumb":"content\\/0.69942200-15544083476871f2aa7f4488d5c2823f836edef183w_450h_.jpg","alt":"","title":"img-variedadesautoctonas-xarello2.jpg","type":"image","id":"2c4edaec1f517716cff400ebaf60c490"}]'),
(28, 'pantall VITICULTURA ECOLÓGICA', '[{"alt":"","title":"img_viticultores_controlamos_la_produccion3.jpg","isThumb":0,"id":"520371ed23f05cdbe867e28e3799d810","img":"content\\/fdee56e0f2f1e3c9730b05b9ccfa909f.jpg","thumb":"content\\/0.01734600-1554408158cbafa5926633bd5584b04606224f3095w_450h_.jpg","type":"image"},{"alt":"","title":"img_viticultores_la_vendimia.jpg","isThumb":0,"id":"2b64d547ba5e0be38a3bc989167ae513","img":"content\\/e3d309c452f7d5c814e55de64899957b.jpg","thumb":"content\\/0.21338900-155440818507d930becdd25cec513e6f3ff08c6c18w_450h_.jpg","type":"image"},{"alt":"","title":"img_viticultores_recolectado_en_mano.jpg","isThumb":0,"id":"ded6c880f6a95a50f755f1bef89f8d42","img":"content\\/10dfca36f2046bb2c9fd006f1aa422b0.jpg","thumb":"content\\/0.37923600-1554408260851972d240030b3c8368e04bf736050dw_450h_.jpg","type":"image"},{"alt":"","title":"MEDIONA-(35).jpg","isThumb":0,"id":"c19f6739492e9a2d2a071fa96bdc881c","img":"content\\/59784b2ee901f7dfb0ffc704754d7bf0.jpg","thumb":"content\\/0.50868600-1555407052f9850465287415b6edb7f37557faf434w_450h_.jpg","type":"image"},{"alt":"","title":"la-vendimia.jpg","isThumb":0,"id":"5d8aa73efd4e83ab4b355e7137044bdc","img":"content\\/5cdb699e06de752a09e228cd23708c35.jpg","thumb":"content\\/0.47537300-1555407210351ae69b966e36af4e3333ea8b1c5142w_450h_.jpg","type":"image"},{"isThumb":0,"img":"content\\/a181c690203bdbaf14de71fbbb3b21d2.jpg","thumb":"content\\/0.56373600-1599562763a59a4c1dfe73015d8c4ee2d2b575bcb6w_450h_.jpg","alt":"","title":"variedades-autoctonas-macabeo.jpg","type":"image","id":"16e46651d1866a488b955f51484c448a"},{"isThumb":0,"img":"content\\/c426328fdce395b9fd9376aee818c092.jpg","thumb":"content\\/0.73714100-15995627637515595b369d7f13b573ccb364e4ecd6w_450h_.jpg","alt":"","title":"variedades-autoctonas-parellada.jpg","type":"image","id":"85f00bb84dd61175290e2c92d183e96a"},{"isThumb":0,"img":"content\\/dcf99cb3c32c1e91521ebf1c5aeea495.jpg","thumb":"content\\/0.85855500-15995627630f6a8cfd7933b28190ca2af196acec2cw_450h_.jpg","alt":"","title":"variedades-autoctonas-trepat.jpg","type":"image","id":"d5c84a5f0872f2a3d0f8655f42a33362"},{"isThumb":0,"img":"content\\/04f70eaad19fca5790e8d5ac8571fbb3.jpg","thumb":"content\\/0.99243600-1599562763d6ea756aa2a79c7d86b8c6e20ea39f19w_450h_.jpg","alt":"","title":"variedades-autoctonas-xarello.jpg","type":"image","id":"af31887b30595a48c091b0a79c15f307"}]'),
(29, 'pantall vinos crianza', '[{"isThumb":0,"img":"content\\/4bd28b2a80f3d3a9b09594241c885d55.jpg","thumb":"content\\/0.70817700-15545711995e2b16a79bfeb650f5ed890cb29b8875w_450h_.jpg","alt":"","title":"img-crianza.jpg","type":"image","id":"e8e8abe566445910a9452340b7eb3710"},{"isThumb":0,"img":"content\\/fa8fc75ea47b2579cfdca0071c9d2761.jpg","thumb":"content\\/0.40708600-1591814467bf3a4008f8968a78aa2de98df4b2d3f9w_450h_.jpg","alt":"","title":"foto crianza web.jpg","type":"image","id":"c0cf060e77899d4d3332a6c0a8ca0be6"}]'),
(30, 'pantall vinos degulle', '[{"isThumb":0,"img":"content\\/1aea248d6440242f95024abaa72707f4.jpg","thumb":"content\\/0.93423900-155457121272d1677cd42d4a524840f8d1950f5038w_450h_.jpg","alt":"","title":"img-garantiaycompromiso1.jpg","type":"image","id":"347cf58d02e2c9ffe7e35d3f070e336a"}]'),
(31, 'pantall vinos', '[{"alt":"","title":"img-prod-aptia-gran.jpg","isThumb":0,"id":"353eb61f095698a9489c6226ebc716bd","img":"content\\/c386bcb8f22b44efd5af860d20cb1c30.jpg","thumb":"content\\/0.92303500-1554571225ba4675f2f8019c6c414bee82f2dad5e7w_450h_.jpg","type":"image"},{"alt":"","title":"img-prod-xic-gran.jpg","isThumb":0,"id":"cce0843953f69911b8785af18af21f8b","img":"content\\/2d9ab5577d3130057c89be5785d05fde.jpg","thumb":"content\\/0.90977100-1554571227b141b67170eecccafc04b6ca7acb2a68w_450h_.jpg","type":"image"},{"alt":"","title":"foto vinyes web.jpg","isThumb":0,"id":"aa7c615861b424c4e878fa99ff84583b","img":"content\\/69c0c3434f55cebdeda37446b5ca9f6a.jpg","thumb":"content\\/0.38389300-1592309839f6a64a76fab926eb35548f220ec11304w_450h_.jpg","type":"image"},{"isThumb":0,"img":"content\\/b135ee753ca47a5c55ef1a7b10d11706.jpg","thumb":"content\\/0.95467000-1599694776b0b0a1b98301e7cb22612a920b8b5a63w_450h_.jpg","alt":"","title":"Alex barrica web.jpg","type":"image","id":"cd23bb07ac6946fdefa3b739b9029d59"},{"isThumb":0,"img":"content\\/cc6afb4744d4615841050546642828e9.jpg","thumb":"content\\/0.14766700-15996947777df563ddc4b35d16c40bf953ca7fcb31w_450h_.jpg","alt":"","title":"Mediona vista detall.jpg","type":"image","id":"0c304fe3214c4a281e46ed83c6ef9f44"},{"isThumb":0,"img":"content\\/2f50bbbc088ce940cc29fd635f06cddd.jpg","thumb":"content\\/0.29138900-1599694777f28611a072207bfdbce84d8979292b97w_450h_.jpg","alt":"","title":"Mediona vista general.jpg","type":"image","id":"9929c26035293be380dbc6efd14e74e7"}]'),
(32, 'pantalla elaboracion de vinos', '[{"alt":"","title":"img-prensasyfermentacion1.jpg","isThumb":0,"id":"742d76d3852f320c4764dd385ee3a27e","img":"content\\/9cafd648c8adcca529c15cf166532f5c.jpg","thumb":"content\\/0.67483200-155497877478ade5bf67be089bbd59be37f3bc194fw_450h_.jpg","type":"image"},{"alt":"","title":"foto elaboracio\\u0301n vinos base.jpg","isThumb":0,"id":"8ea05628437695ce61dd461eeb828f12","img":"content\\/2d3aa54a53afae3419287ddb65e4c3b4.jpg","thumb":"content\\/0.16790700-15918134653f7580b0593c67f3be360cbe973ab8d8w_450h_.jpg","type":"image"},{"alt":"","title":"Foto Alex Agusti\\u0301 cupage.jpg","isThumb":0,"id":"697c9ba240ef479740b9c837d7014625","img":"content\\/852bc92bff855a7c0c95977f4d3acae1.jpg","thumb":"content\\/0.91026000-15918138601dca83817784c0b96a37a32e7565994fw_450h_.jpg","type":"image"}]'),
(34, 'xic vermell', '[{"alt":"","title":"xic-vermell.jpg","isThumb":"1","id":"0b2618fe575362b8f4a67feec7f60904","img":"content\\/acd482c99868dea0b56da240f0442c4f.jpg","thumb":"content\\/0.59320200-15554378719610ca91f92ed4a4ba701e2a64d93bbdw_450h_.jpg","type":"image"}]'),
(35, '375 Blanc', NULL),
(36, 'Brut Nature Gran Reserva 2013', '[{"alt":"","title":"","isThumb":0,"id":"16fc1a97c1df897e70ff19d8dc76d0e4","img":"","thumb":"","type":"image"},{"alt":"","title":"brut nature gran reserva 2013.jpg","isThumb":"1","id":"83243dfdd33683558f185d9f2d66fec6","img":"content\\/38897fe969f2f4ac7cb3090cebe8dfaa.jpg","thumb":"content\\/0.82183100-1582019061e80f2cd86eb5fff0fd013942e61388dcw_450h_.jpg","type":"image"}]'),
(37, 'Premios', '[{"alt":"","title":"espantallops seccio premis.jpg","isThumb":0,"id":"1bf293484329a4cc34d7d728159b5564","img":"content\\/3b300547577222a954921df9447bcc51.jpg","thumb":"content\\/0.31538300-1581518718e8a5b7077d4e467006d1652e49ae99dfw_450h_.jpg","type":"image"},{"isThumb":0,"img":"content\\/fb42637c93dfb79c7e18c271722a605d.jpg","thumb":"content\\/0.45724500-15815855042704bd801b623ea4bc2d3c256e667193w_450h_.jpg","alt":"","title":"barrica seccio premis.jpg","type":"image","id":"960221033925a6673bd0b561c12074d2"},{"isThumb":0,"img":"content\\/4ce4f836d01cee4e0210b1d662284fa5.jpg","thumb":"content\\/0.46749200-158158777155a329115527fc245764e2613a2dc4d2w_450h_.jpg","alt":"","title":"kripta seccio premis.jpg","type":"image","id":"73d426d086b41a62843ffecc18f540cd"}]'),
(38, 'Origen', '[{"alt":"","title":"80 anys CV.jpg","isThumb":0,"id":"81d762b7616bb071611b0a277d9eebda","img":"content\\/7cf570130d6c26ff37a916632bda9029.jpg","thumb":"content\\/0.51064200-158210963673681777e5aaa279bca0b33e10f71e1cw_450h_.jpg","type":"image"},{"isThumb":0,"img":"content\\/902a16583b59f1499dae5ec80fd3ed35.jpg","thumb":"content\\/0.85647200-15995563546eb5315393aaa57be5248041370d4c06w_450h_.jpg","alt":"","title":"Agusti sentat a la bodega Kripta.jpg","type":"image","id":"2c1f59fd4cc41e2e427610d815582b96"}]'),
(39, 'crianza y deguelle', '[{"isThumb":0,"img":"content\\/73eaca3f2fc608c8d598cf64f65d162c.jpg","thumb":"content\\/0.25088100-1592308145a3be1b4805ec8394add06925b4d881aew_450h_.jpg","alt":"","title":"foto deguelle web.jpg","type":"image","id":"68c7fc6118c786d82c5da2c8152c61b0"},{"isThumb":0,"img":"content\\/b563aa630c9fd9b0d83c5e94d7a0f11e.jpg","thumb":"content\\/0.64074700-159969273154f30cd87feb1acaf6e3c6ea280832c4w_450h_.jpg","alt":"","title":"foto crianza.jpg","type":"image","id":"630458b8ec751ab04fa67c78b432a1e9"},{"isThumb":0,"img":"content\\/26c75a2172c847e4d8749238b3192607.jpg","thumb":"content\\/0.83732700-1599692731457d45928361b04594e56cdda9d73a3dw_450h_.jpg","alt":"","title":"KRIPTA sediment Can Rosell.jpg","type":"image","id":"7d28cad6e8fc95946ed680edcb453e01"}]'),
(40, 'Video-home', '[{"isThumb":0,"img":"http:\\/\\/agustitorellomata.com\\/_new\\/content\\/home-video.webmsd.webm","thumb":"http:\\/\\/too:8888\\/agustitorellomata.com\\/images\\/nofoto.png","alt":"","title":"","type":"video","id":1},{"isThumb":0,"img":"http:\\/\\/agustitorellomata.com\\/_new\\/content\\/home-video.webmhd.webm","thumb":"http:\\/\\/too:8888\\/agustitorellomata.com\\/images\\/nofoto.png","alt":"","title":"","type":"video","id":2},{"isThumb":0,"img":"http:\\/\\/agustitorellomata.com\\/_new\\/content\\/home-video.ogv","thumb":"http:\\/\\/too:8888\\/agustitorellomata.com\\/images\\/nofoto.png","alt":"","title":"","type":"video","id":3},{"isThumb":0,"img":"http:\\/\\/agustitorellomata.com\\/_new\\/content\\/home-video.mp4","thumb":"http:\\/\\/too:8888\\/agustitorellomata.com\\/images\\/nofoto.png","alt":"","title":"","type":"video","id":4}]'),
(41, 'adn', '[{"isThumb":0,"img":"content\\/720a71e7002921ab38469d26c77650c6.jpg","thumb":"content\\/0.82103800-1599556705ad9064c273622b9641a5eb796f476dbdw_450h_.jpg","alt":"","title":"Mediona.jpg","type":"image","id":"70bd2dc6591f12eeadc3d288911cda8c"}]'),
(42, 'el-origen-viñedo', '[{"isThumb":0,"img":"content\\/b27946485439b0449029596e13408504.jpg","thumb":"content\\/0.40884000-1599562617dea1eaf2c42cc924686636fd562e95d5w_450h_.jpg","alt":"","title":"img-subzonas.jpg","type":"image","id":"5fd7d2ed2def28a93c4f3407192bd047"}]'),
(43, 'cava', '[{"isThumb":0,"img":"content\\/0a2b30d501f1541ecd08715e4e651503.jpg","thumb":"content\\/0.60351300-159967958974915b1fd1a048ee52a70fcffe023d93w_450h_.jpg","alt":"","title":"Tallant les vinyes.jpg","type":"image","id":"e2f7c5d37e43fc99984bf012bd96740e"}]'),
(44, 'elaboracion', '[{"isThumb":0,"img":"content\\/3a6d89036264703f9e06521aa511e6f5.jpg","thumb":"content\\/0.57692400-15996920672cfcff88ddca0643372f8fd02e6d9726w_450h_.jpg","alt":"","title":"Alex i Agusti fent cupatge.jpg","type":"image","id":"2b0afad545c2e88da8eecb4e4a9b347d"},{"isThumb":0,"img":"content\\/75591935a62737a0a98ca892ef650209.jpg","thumb":"content\\/0.76413600-1599692067295545cf9c1e8c55b0e1f110fe68e9f0w_450h_.jpg","alt":"","title":"Alex olorant vi.jpg","type":"image","id":"30a6d1d1eac0ec72fb11bd885fe04ae6"},{"isThumb":0,"img":"content\\/8792389dddb149dfc1a7fc79245a7a94.jpg","thumb":"content\\/0.95508400-15996920677c2f74e94842d96659c88d9a45241ef4w_450h_.jpg","alt":"","title":"Elaboracion vinos base.jpg","type":"image","id":"a6e9b4775d4f05d4ac45418d73f96ff5"}]'),
(45, 'visitas', '[{"isThumb":0,"img":"content\\/0169447bda31be30ba2a07e309c16351.jpg","thumb":"content\\/0.59384600-159984938282f485ac1f30b82b8e0008396941bfd4w_450h_.jpg","alt":"","title":"Enoturisme.jpg","type":"image","id":"a623cf978198ef1d83b08ba51c056781"},{"isThumb":0,"img":"content\\/f9fe3bcb93388c32b65c1d3604520ecd.jpg","thumb":"content\\/0.76008600-159984938296efe34679c093486450a33958d71281w_450h_.jpg","alt":"","title":"La Barraqueta.jpg","type":"image","id":"2473fa2277b4e88b9b073ad350ed5c94"},{"isThumb":0,"img":"content\\/edf07ea60ca2c86f938a6d5e82c20622.jpg","thumb":"content\\/0.87533100-15998493826a6cba12a7dc2b1c14af62423823fe40w_450h_.jpg","alt":"","title":"Tu\\u0301nel de visites.jpg","type":"image","id":"1e359b0d4c873ecdbdc140d6c02cb3ba"}]'),
(46, 'Actividades', '[{"isThumb":0,"img":"content\\/746bc93bda97683d592aa4f1c1d7a129.jpg","thumb":"content\\/0.06351100-16007289359deefdded27a46b153ee9c02a07785afw_450h_.jpg","alt":"","title":"Imatge proba tutorial.jpg","type":"image","id":"a2f13d6bd27f91015299755aefa66479"},{"isThumb":0,"img":"","thumb":"","alt":"","title":"","type":"image","id":"b84a1adb90be34ed1ff5888fb4d3240f"}]'),
(47, 'Enoturisme', '[{"isThumb":0,"img":"content\\/a323f085839ae66b29b2bc2b892a2909.jpg","thumb":"content\\/0.03227500-1600733718850b5f81314f6d385ecd60361a3dc022w_450h_.jpg","alt":"","title":"Enoturisme 2.jpg","type":"image","id":"a4b4e735c7c7a443c75da5f082b11a2e"}]'),
(48, 'Fitxes productes pdf', '[{"alt":"","title":"VI XIC VERMELL 2019 Esp.pdf","isThumb":0,"id":"ef3e4c0bf9a095759dd3bd4978b8f129","img":"content\\/7a202742cf46561a19cef4c3dd37352e.pdf","thumb":"images\\/fileformat\\/pdf.png","type":"file"},{"alt":"","title":"XIC 2019 Esp.pdf","isThumb":0,"id":"c84eb97a0b097a40b71f28d065e7d9e5","img":"content\\/aa4d13b708a87dde3afac0f2c4829aa3.pdf","thumb":"images\\/fileformat\\/pdf.png","type":"file"},{"alt":"","title":"UBAC 2015 Esp.pdf","isThumb":0,"id":"5aa95c78c96bf8e8c3b54569f1896511","img":"content\\/926451963f54612432aff80e321dffbd.pdf","thumb":"images\\/fileformat\\/pdf.png","type":"file"},{"alt":"","title":"KRIPTA 2011 Esp.pdf","isThumb":0,"id":"96766eee8b6b3317aa9c2b99c0e4b96a","img":"content\\/cc12b767e4fbf8e0953a30f4f2626d13.pdf","thumb":"images\\/fileformat\\/pdf.png","type":"file"},{"alt":"","title":"BARRICA 2015 Esp.pdf","isThumb":0,"id":"afa0532e6e8b25fbedd45ac43030ceed","img":"content\\/63f50d967f97151989c34d5c0f6257a6.pdf","thumb":"images\\/fileformat\\/pdf.png","type":"file"}]');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `iva`
--

CREATE TABLE IF NOT EXISTS `iva` (
  `id` int(11) unsigned NOT NULL,
  `year` int(4) DEFAULT NULL,
  `iva` float DEFAULT NULL,
  `irpf` float DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `iva`
--

INSERT INTO `iva` (`id`, `year`, `iva`, `irpf`) VALUES
(1, 2012, 21, 21),
(2, 2013, 21, 21),
(3, 2014, 21, 21),
(4, 2015, 21, 20),
(5, 2016, 21, 19),
(6, 2017, 21, 21),
(7, 2018, 21, 21),
(8, 2019, 21, 21);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lang`
--

CREATE TABLE IF NOT EXISTS `lang` (
  `id` int(11) unsigned NOT NULL,
  `lang_key` varchar(100) DEFAULT NULL,
  `lang_type` varchar(2) DEFAULT '',
  `lang_value` text
) ENGINE=InnoDB AUTO_INCREMENT=934 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `lang`
--

INSERT INTO `lang` (`id`, `lang_key`, `lang_type`, `lang_value`) VALUES
(1, 'error_db', 'es', 'Se ha producido un fallo al consultar base de datos'),
(5, 'error_db', 'en', 'Failed to query database.'),
(9, 'lang_es', 'es', 'Español'),
(10, 'lang_es', 'en', 'Spanish'),
(11, 'lang_en', 'es', 'Ingles'),
(12, 'lang_en', 'en', 'English'),
(13, 'lang_ca', 'es', 'Català'),
(14, 'lang_ca', 'en', 'Catalonian'),
(17, 'error_db', 'ca', 'S&#39;ha produït un error en consultar base de dades'),
(29, 'lang_es', 'ca', 'Castellano'),
(32, 'lang_en', 'ca', 'Ingles'),
(35, 'lang_ca', 'ca', 'Català'),
(36, 'mail_invitacion', 'es', 'Invitación'),
(59, 'mail_invitacion', 'en', 'Invitation'),
(60, 'mail_invitacion', 'ca', 'Invitació'),
(61, 'mail_regards', 'es', 'Un coordial saludo'),
(62, 'mail_regards', 'en', 'Regards.'),
(63, 'mail_regards', 'ca', 'Salutació coordial.'),
(64, 'mail_invitacion_html', 'es', '<p>Nos gustaria enviarle una invitación</p><p>Al cual puede acceder entrando en siguiente link: %site_link%</p><p>También se le ha asignado un usuario y contraseña <i>(Exclusivo solo para usted.)</i>:</p><strong>Usuario:</strong> %user_name%<br/><strong>Contraseña:</strong> %user_pass%<br/><br/>'),
(65, 'mail_restablecerpass_html', 'es', '<p>Hemos actualizado tu contraseña</p><p>Te recordamos tus datos de acceso:<br/><strong>Usuario: </strong>%user_name%<br/><strong>Contraseña:</strong> %user_pass%<p>Al cual puede acceder entrando en siguiente link: %site_link%</p><br/><br/>'),
(66, 'mail_restablecerpass', 'es', 'Recuperación de contraseña'),
(67, 'title_search_404', 'es', 'UPS! El link esta mal'),
(68, 'title_search_404', 'en', 'UPS! L&#39;enllaç d&#39;aquesta mal'),
(69, 'title_search_404', 'ca', 'UPS! The link is wrong'),
(70, 'text_search_404', 'es', 'Es posible que esta dirección URL este mal puesto, pero eso he buscado y he encontrado estas páginas:'),
(72, 'text_search_404', 'ca', 'És possible que aquesta direcció URL este mal posada, per això he buscat i he trobat aquestes pàgines:'),
(73, 'text_search_404', 'en', 'This URL is wrong, but that I have searched and found these pages:'),
(74, 'back_button', 'es', 'Volver'),
(75, 'back_button', 'en', 'Back'),
(76, 'back_button', 'ca', 'Tornar'),
(77, 'add_cart_but', 'es', 'añadir al carrito'),
(78, 'add_cart_but', 'ca', 'afegir a la cistella'),
(79, 'add_cart_but', 'en', 'add to cart'),
(80, 'title_info_evio', 'es', 'información de envío'),
(81, 'title_info_evio', 'ca', 'informació d&#39;enviament'),
(82, 'title_info_evio', 'en', 'shippment information'),
(83, 'title_shop', 'es', 'Tienda'),
(84, 'title_shop', 'ca', 'botiga'),
(85, 'title_shop', 'en', 'Shop'),
(86, 'no_price', 'es', 'precio no establecido'),
(87, 'no_price', 'ca', 'preu no establert'),
(88, 'no_price', 'en', 'Price not established'),
(89, 'no_stock', 'es', 'fuera de stock'),
(90, 'no_stock', 'ca', 'fora d&#39;estoc'),
(91, 'no_stock', 'en', 'out of stock'),
(92, 'tienda_no_items', 'es', ''),
(93, 'tienda_no_items', 'ca', 'En aquet moment no li podem oferir venda dels nostres productes, disculpin les molèsties.'),
(94, 'tienda_no_items', 'en', ''),
(95, 'lang_page_title_mi_cuenta', 'es', 'Mi cuenta'),
(96, 'lang_page_title_mi_cuenta', 'ca', 'El meu compte'),
(97, 'lang_page_title_mi_cuenta', 'en', 'My account'),
(98, 'login_new_user_title', 'es', 'Nuevo usuário'),
(99, 'login_registred_title', 'es', 'ya estás registrado?'),
(100, 'login_new_user_title', 'ca', 'nou usuari'),
(101, 'login_new_user_title', 'en', 'new user'),
(102, 'login_registred_title', 'ca', 'ja estàs registrat?'),
(104, 'login_registred_title', 'en', 'Already registered?'),
(105, 'label_new_user_email', 'es', 'Introduce tu correo electrónico para crear tu cuenta.'),
(106, 'label_new_user_email', 'ca', 'Introdueix el teu correu electrònic per crear el teu compte.'),
(107, 'label_new_user_email', 'en', 'Enter your email to create your account.'),
(108, 'new_user_but', 'es', 'crear cuenta'),
(109, 'new_user_but', 'ca', 'crear compte'),
(110, 'new_user_but', 'en', 'create account'),
(111, 'label_email', 'es', 'correo electrónico'),
(112, 'label_email', 'ca', 'correu electrònic'),
(113, 'label_email', 'en', 'Email'),
(114, 'label_pass', 'es', 'contraseña'),
(115, 'label_pass', 'ca', 'contrasenya'),
(116, 'label_pass', 'en', 'password'),
(117, 'login_init_session_but', 'es', 'iniciar sesión'),
(118, 'login_init_session_but', 'ca', 'iniciar sessió'),
(119, 'login_init_session_but', 'en', 'log in'),
(120, 'login_lost_pass_link', 'es', '¿Has olvidado tu contraseña?'),
(121, 'login_lost_pass_link', 'ca', '¿Ha oblidat la seva contrasenya?'),
(123, 'login_lost_pass_link', 'en', 'can you forgotten your password?'),
(124, 'form_empty_fields', 'es', 'Hay campos en blanco.'),
(125, 'form_empty_fields', 'ca', 'Hi ha camps en blanc.'),
(126, 'form_empty_fields', 'en', 'Check empty fields.'),
(127, 'pass_not_correct', 'es', 'Nombre o contraseña incorrecta.'),
(128, 'pass_not_correct', 'ca', 'Nom o contrasenya incorrecta.'),
(129, 'pass_not_correct', 'en', 'Wrong name or password.'),
(130, 'lang_page_title_recover_password', 'es', 'Recuperar contraseña'),
(131, 'lang_page_title_recover_password', 'ca', 'recuperar contrasenya'),
(132, 'lang_page_title_recover_password', 'en', 'Recover your password'),
(133, 'recover_pass_title', 'es', 'Recuperación de contraseña'),
(134, 'recover_pass_title', 'ca', 'Recuperació de contrasenya'),
(135, 'recover_pass_title', 'en', 'Recovering your password'),
(136, 'label_recover_user_email', 'es', 'Introduce tu correo electrónico para enviarte un formulario de recuperación'),
(137, 'label_recover_user_email', 'ca', 'Introduir el teu correu electrònic per enviar-te formulari de recuperació'),
(138, 'label_recover_user_email', 'en', 'Enter your email to send you a recovery form'),
(139, 'recovery_pass_but', 'es', 'enviar solicitud'),
(140, 'recovery_pass_but', 'en', 'send request'),
(141, 'recovery_pass_but', 'ca', 'enviar sol·licitud'),
(142, 'msg_new_mail_exist', 'es', 'Ya existe un usuario con este correo electrónico.'),
(143, 'msg_new_mail_exist', 'ca', 'Ja existeix un usuari amb aquest correu electrònic.'),
(144, 'msg_new_mail_exist', 'en', 'Already exists one client with this email.'),
(145, 'msg_no_data', 'es', 'Revise los campos obligatorios, hay algun campo vacío.'),
(146, 'msg_no_data', 'en', 'Check the required fields, there is some empty field.'),
(147, 'msg_no_data', 'ca', 'Revisi els camps obligatoris, hi ha algun camp buit.'),
(148, 'msg_email_not_valid', 'es', 'El correo electrónico no es válido.'),
(149, 'msg_email_not_valid', 'en', 'Email is not valid.'),
(150, 'msg_email_not_valid', 'ca', 'El correu electrònic no és vàlid.'),
(151, 'msg_new_client_mail_sended', 'es', 'Revise su correo electronico, le llegara la solicitud.'),
(152, 'msg_new_client_mail_sended', 'ca', 'Revisi el seu correu electrònic, li arribés la sol·licitud.'),
(153, 'msg_new_client_mail_sended', 'en', 'Check your email, your request will arrive.'),
(154, 'msg_account_activated', 'es', 'Su cuenta esta activada correctamente.'),
(156, 'msg_account_activated', 'ca', 'El seu compte està activada correctament.'),
(157, 'msg_account_activated', 'en', 'Your account is successfully activated.'),
(158, 'msg_account_activate_error', 'es', 'Su clave de activación no es correcta.'),
(159, 'msg_account_activate_error', 'ca', 'La seva clau d&#39;activació no és correcta.'),
(160, 'msg_account_activate_error', 'en', 'Your activation key is not correct.'),
(161, 'msg_new_client_create_error', 'es', 'Ahora mismo no he podido crear un usuario nuevo, intentelo en unos momentos.'),
(162, 'msg_new_client_create_error', 'ca', 'Ara mateix no he pogut crear un usuari nou, intenteu en uns moments.'),
(163, 'msg_new_client_create_error', 'en', 'Right now I could not create a new user, try it in a few moments.'),
(164, 'mail_subject_new_client', 'es', 'Acceso y activación de su cuenta.'),
(165, 'mail_subject_new_client', 'en', 'Access and activation of your account.'),
(166, 'mail_subject_new_client', 'ca', 'Accés i activació del seu compte.'),
(167, 'mail_new_client_html', 'es', '<p>Hola estimado cliente, nos gustaria darles la bienvenida.</p><p>Hemos creado un link de activación: %site_link%</p><p>También se le ha asignado un usuario y contraseña <i>(Exclusivo solo para usted.)</i>:</p><strong>Usuario:</strong> %user_name%<br/><strong>Contraseña:</strong> %user_pass%<br/><br/>'),
(168, 'mail_new_client_html', 'ca', '<p>Hola estimat client, ens agradaria donar-los la benvinguda.</p><p>Hem creat un link d&#39;activació: %site_link% </p> <p>També se li ha assignat un usuari i contrasenya <i>( exclusiu només per a vostè.)</i>: </p><strong>Usuari: </strong>%user_name% <br/><strong>Contrasenya:< strong>%user_pass%<br/><br/>'),
(169, 'mail_new_client_html', 'en', '<p>Hello dear customer, we would like to welcome you.</p><p>We have created an activation link: %site_link%</p><p>You have also been assigned a username and password <i> ( Exclusive for you only.) </p> <strong> User: </strong>%user_name% <br/> <strong>Password: %user_pass% </strong><br/> <br/>'),
(170, 'msg_rec_mail_noexist', 'es', 'Usuario con este correo electrónico no existe.'),
(171, 'msg_rec_mail_noexist', 'en', 'User with this email does not exist.'),
(172, 'msg_rec_mail_noexist', 'ca', 'Usuari amb aquest correu electrònic no existeix.'),
(173, 'msg_recovery_pass_send_error', 'es', 'Por razones tecnicas no he podido enviar la solicitud, intentelo en unos momentos.'),
(174, 'msg_recovery_pass_send_error', 'ca', 'Per raons tècniques no he pogut enviar la sol·licitud, intenteu en uns moments.'),
(175, 'msg_recovery_pass_send_error', 'en', 'For technical reasons I could not send the request, try it in a few moments.'),
(176, 'mail_subject_recover_pass', 'es', 'Solicitud de recuperación de contraseña'),
(177, 'mail_subject_recover_pass', 'en', 'Request for password recovery'),
(178, 'mail_subject_recover_pass', 'ca', 'Sol·licitud de recuperació de contrasenya'),
(179, 'mail_recover_pass_html', 'es', '<p>Hola estimado cliente, hemos recibido la solicitud para recuperación de su contraseña.</p><p>Hemos creado un link de activación: %site_link%</p><p>También se le ha asignado una nueva contraseña <i>(Exclusivo solo para usted.)</i>:</p><strong>Usuario:</strong> %user_name%<br/><strong>Contraseña:</strong> %user_pass%<br/><br/>'),
(180, 'mail_recover_pass_html', 'ca', '<p>Hola estimat client, hem rebut la sol·licitud per a recuperació de la contrasenya.</p><p>Hem creat un link d&#39;activació: %site_link% </p> <p>També se li ha assignat una nova contrasenya <i>( exclusiu només per a vostè.)</i>: </p><strong>Usuari: </strong>%user_name% <br/><strong>Contrasenya:< strong>%user_pass%<br/><br/>'),
(181, 'mail_recover_pass_html', 'en', '<p>Hello dear client, we have received the request for recovery of your password.</p><p>We have created an activation link: %site_link%</p><p>You have also been assigned new password <i> ( Exclusive for you only.) </p> <strong> User: </strong>%user_name% <br/> <strong>Password: %user_pass% </strong><br/> <br/>'),
(182, 'micuenta_datospers_title', 'es', 'Mis datos personales'),
(183, 'micuenta_welcome', 'es', '¡Bienvenido a tu cuenta! Aquí podrás gestionar todos tus pedidos e información personal.'),
(184, 'micuenta_welcome', 'ca', 'Benvingut al teu compte! Aquí podràs gestionar totes les teves comandes i informació personal.'),
(185, 'micuenta_welcome', 'en', 'Welcome to your account! Here you can manage all your orders and personal information.'),
(186, 'micuenta_datospers_title', 'en', 'My personal information'),
(188, 'micuenta_datospers_title', 'ca', 'Les meves dades personals'),
(189, 'micuenta_direcciones_title', 'es', 'Mi dirección principal'),
(190, 'micuenta_direcciones_title', 'ca', 'La meava adreça'),
(191, 'micuenta_direcciones_title', 'en', 'My default address'),
(192, 'micuenta_no_direcciones_msg', 'es', 'No tiene ninguna dirección guardada'),
(193, 'micuenta_no_direcciones_msg', 'en', 'And there are none saved direction'),
(194, 'micuenta_no_direcciones_msg', 'ca', 'No hi te cap direcció guardada'),
(195, 'no_level_msg', 'es', 'No puede hacer esto, no tiene autorización!'),
(196, 'no_level_msg', 'ca', 'No pot Fer això, no hi té autorització!'),
(197, 'no_level_msg', 'en', 'Can not do that, you are not authorized!'),
(198, 'msg_client_persdata_updated', 'es', 'Sus datos se han actualizado correctamente'),
(199, 'msg_client_persdata_updated', 'en', 'Your personal data are updated succesfully'),
(200, 'msg_client_persdata_updated', 'ca', 'Les seves dades s&#39;han actualitzat correctament'),
(201, 'msg_client_persdata_no_updated', 'es', 'Sus datos no se han actualizado :('),
(202, 'msg_client_persdata_no_updated', 'en', 'Your personal data are not updated'),
(203, 'msg_client_persdata_no_updated', 'ca', 'Les seves dades no s&#39;han actualitzat :('),
(204, 'lang_label_dir', 'es', 'Dirección'),
(205, 'lang_label_city', 'es', 'Ciudad'),
(206, 'lang_label_region', 'es', 'Region'),
(207, 'lang_label_post', 'es', 'Código postal'),
(208, 'lang_label_country', 'es', 'País'),
(209, 'add_one_but', 'es', 'Añadir una'),
(210, 'form_save_but', 'es', 'Guardar'),
(211, 'form_tel', 'es', 'Teléfono'),
(212, 'form_cif', 'es', 'Cif, Dni, Nie (Facturación)'),
(213, 'form_surname', 'es', 'Apellidos'),
(214, 'form_name', 'es', 'Nombre'),
(215, 'label_client_id', 'es', 'Id del cliente'),
(216, 'menu_but_mis_pedidos', 'es', 'HISTORIAL DE PEDIDOS Y DETALLES'),
(217, 'menu_but_mis_devoluciones', 'es', 'MIS DEVOLUCIONES'),
(218, 'menu_but_misdirecciones', 'es', 'MIS DIRECCIONES'),
(219, 'menu_but_misdatos', 'es', 'MIS DATOS PERSONALES'),
(220, 'menu_but_logout', 'es', 'CERRAR SESIÓN'),
(221, 'menu_but_login', 'es', 'Iniciar sesion'),
(222, 'menu_but_register', 'es', 'Registrarse'),
(223, 'menu_but_enviodevoluciones', 'es', 'ENVÍOS Y DEVOLUCIONES'),
(224, 'menu_but_terycond', 'es', 'TÉRMINOS Y CONDICIONES'),
(225, 'menu_but_poryprivcookies', 'es', 'POLITICA DE PRIVACIDAD Y COOKIES'),
(226, 'menu_but_sobrenosotros', 'es', 'SOBRE NOSOTROS'),
(227, 'menu_but_contacto', 'es', 'contacto'),
(228, 'footer_text', 'es', 'Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500. Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500'),
(229, 'msg_no_hay_pedidos', 'es', 'No has realizado ningún pedido'),
(230, 'but_ir_a_la_tienda', 'es', 'Ir a la tienda'),
(231, 'lang_page_title_mis_devoluciones', 'es', 'Mis devoluciones'),
(232, 'lang_page_title_mis_pedidos', 'es', 'mis pedidos'),
(233, 'lang_page_title_mis_direcciones', 'es', 'mis direcciones'),
(234, 'msg_no_hay_devoluciones', 'es', 'no has realizado ningúna devolución'),
(235, 'misdirecciones_title', 'es', 'Mis direcciónes'),
(238, 'misdirecciones_asegurate_mod', 'es', 'Asegúrate de actualizar tu información personal si cambia'),
(239, 'form_update_but', 'es', 'Actualizar'),
(240, 'form_del_but', 'es', 'Borrar'),
(241, 'form_set_default_but', 'es', 'Establecer principal'),
(242, 'form_misdirecciones_name', 'es', 'Nombre rápido'),
(243, 'lang_page_title_checkout', 'es', 'Checkout'),
(244, 'cart_empty', 'es', 'Su carrito esta vacío.'),
(245, 'add_item_cart', 'es', 'Producto añadido al carrito'),
(246, 'cart_generado', 'es', 'Carrito generado'),
(247, 'cart_error_generar', 'es', 'No se ha podido generar el carrito, por favor intentelo en unos momentos.'),
(248, 'add_item_cart_error', 'es', 'No he podido añadir el producto al carrito.'),
(249, 'msg_cart_no_hay_compras', 'es', 'No ha realizado ninguna compra.'),
(250, 'lang_iva', 'es', 'IVA'),
(251, 'lang_iva', 'ca', 'IVA'),
(252, 'lang_iva', 'en', 'VAT'),
(253, 'lang_no_iva', 'es', 'No hay iva'),
(254, 'lang_page_title_cart', 'es', 'Carrito'),
(255, 'cart_but', 'es', 'Carrito'),
(256, 'cart_checkout_but', 'es', 'Finalizar la compra'),
(257, 'lang_cart_producto_title', 'es', 'producto'),
(258, 'lang_cart_cantidad_title', 'es', 'cantidad'),
(259, 'lang_envio', 'es', 'Envío'),
(260, 'title_lookbook', 'es', 'lookbook'),
(261, 'msg_home_welcome', 'es', 'Bienvenido'),
(262, 'msg_no_logged', 'es', 'Ya estas registrado? Aqui puedes registrarte o iniciar secion.'),
(263, 'checkout_title_adress_book', 'es', 'dirección de facturación'),
(264, 'msg_checkout_nodir', 'es', 'Por el momento no tiene ninguna dirección guardada es necesario que añada una.'),
(265, 'checkout_pago_title', 'es', 'forma de pago'),
(266, 'checkout_pedido_title', 'es', 'pedido'),
(267, 'checkout_agree_checkbox', 'es', 'acepto los términos y condiciones (+info)'),
(268, 'checkout_finalizar_but', 'es', 'finalizar compra'),
(297, 'mail_invitacion_html', 'en', '<p>We would like to send you an invitation</p><p>You can access it by entering the following link:%site_link% </p><p>You have also been assigned a user and password <i>(Exclusive only for You.)</p><strong>User: </strong>%user_name% <br/><strong>Password: </strong>%user_pass%<br/><br/>'),
(298, 'mail_invitacion_html', 'ca', '<p>Ens agradaria enviar-li una invitació</p><p>A l’quina por accedir-hi entrant en següent enllaç:%site_link%</p><p>També se li ha assignat un usuari i contrasenya <i>(Exclusiu només per vostè)</i>: </p> <strong>Usuari: </strong>%user_name%<br/><strong> Contrasenya: </strong>%user_pass%<br/>'),
(300, 'mail_restablecerpass_html', 'en', '<p>We have updated your password</p><p>We remind you of your login information:<br/><strong> User: </strong>%user_name%<br/><strong> Password: </strong> %user_pass% <p>You can access it by going to the following link:%site_link%</p><br/><br/>'),
(301, 'mail_restablecerpass_html', 'ca', '<p>Hem actualitzat la contrasenya</p><p>Et recordem les teves dades d&#39;accés: <br/><strong> Usuari: </strong>%user_name%<br/><strong> Contrasenya: </strong> %user_pass% <p><br/>En seguent link (%site_link%) hi pot accedir-hi.</p><br/><br/>'),
(303, 'mail_restablecerpass', 'en', 'Recuperació de contrasenya'),
(304, 'mail_restablecerpass', 'ca', 'Password recovery'),
(438, 'lang_label_dir', 'en', 'Address'),
(439, 'lang_label_dir', 'ca', 'direcció'),
(441, 'lang_label_city', 'en', 'city'),
(442, 'lang_label_city', 'ca', 'ciutat'),
(444, 'lang_label_region', 'en', 'Region'),
(445, 'lang_label_region', 'ca', 'Region'),
(447, 'lang_label_post', 'en', 'Postal Code'),
(448, 'lang_label_post', 'ca', 'codi postal'),
(450, 'lang_label_country', 'en', 'country'),
(451, 'lang_label_country', 'ca', 'país'),
(453, 'add_one_but', 'en', 'Add one'),
(454, 'add_one_but', 'ca', 'afegir una'),
(456, 'form_save_but', 'en', 'save'),
(457, 'form_save_but', 'ca', 'Guardar'),
(459, 'form_tel', 'en', 'telephone'),
(460, 'form_tel', 'ca', 'telèfon'),
(462, 'form_cif', 'en', 'ID Doc. (Billing)'),
(463, 'form_cif', 'ca', 'Cif, Dni, Nie (facturació)'),
(465, 'form_surname', 'en', 'Surnames'),
(466, 'form_surname', 'ca', 'Cognoms'),
(468, 'form_name', 'en', 'Name'),
(469, 'form_name', 'ca', 'Nom'),
(471, 'label_client_id', 'en', 'Client ID'),
(472, 'label_client_id', 'ca', 'Aneu del client'),
(474, 'menu_but_mis_pedidos', 'en', 'ORDER HISTORY AND DETAILS'),
(475, 'menu_but_mis_pedidos', 'ca', 'HISTORIAL DE COMANDES I DETALLS'),
(477, 'menu_but_mis_devoluciones', 'en', 'MY RETURNS'),
(478, 'menu_but_mis_devoluciones', 'ca', 'MIS DEVOLUCIONS'),
(480, 'menu_but_misdirecciones', 'en', 'MY ADDRESSES'),
(481, 'menu_but_misdirecciones', 'ca', 'LES MEVES ADRECES'),
(483, 'menu_but_misdatos', 'en', 'MY PERSONAL INFORMATION'),
(484, 'menu_but_misdatos', 'ca', 'Detalls sobre mi'),
(486, 'menu_but_logout', 'en', 'LOG OUT'),
(487, 'menu_but_logout', 'ca', 'TANCAR SESSIÓ'),
(489, 'menu_but_login', 'en', 'LOG IN'),
(490, 'menu_but_login', 'ca', 'Inicia sessió'),
(492, 'menu_but_register', 'en', 'Register'),
(493, 'menu_but_register', 'ca', 'Registrar'),
(495, 'menu_but_enviodevoluciones', 'en', 'SHIPPING & RETURNS'),
(496, 'menu_but_enviodevoluciones', 'ca', 'ENVIAMENTS I DEVOLUCIONS'),
(498, 'menu_but_terycond', 'en', 'TERMS AND CONDITIONS'),
(499, 'menu_but_terycond', 'ca', 'TERMES I CONDICIONS'),
(501, 'menu_but_poryprivcookies', 'en', 'PRIVACY POLICY AND COOKIES'),
(502, 'menu_but_poryprivcookies', 'ca', 'POLÍTICA DE PRIVACITAT I COOKIES'),
(504, 'menu_but_sobrenosotros', 'en', 'ABOUT US'),
(505, 'menu_but_sobrenosotros', 'ca', 'SOBRE NOSALTRES'),
(507, 'menu_but_contacto', 'en', 'contact'),
(508, 'menu_but_contacto', 'ca', 'contact'),
(510, 'footer_text', 'en', 'Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500. Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500'),
(511, 'footer_text', 'ca', 'Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500. Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500'),
(513, 'msg_no_hay_pedidos', 'en', 'You have not placed any orders'),
(514, 'msg_no_hay_pedidos', 'ca', 'No has realitzat cap comanda'),
(516, 'but_ir_a_la_tienda', 'en', 'Go to the store'),
(517, 'but_ir_a_la_tienda', 'ca', 'Anar a la botiga'),
(519, 'lang_page_title_mis_devoluciones', 'en', 'My returns'),
(520, 'lang_page_title_mis_devoluciones', 'ca', 'Els meus devolucions'),
(522, 'lang_page_title_mis_pedidos', 'en', 'my orders'),
(523, 'lang_page_title_mis_pedidos', 'ca', 'les meves comandes'),
(525, 'lang_page_title_mis_direcciones', 'en', 'MY ADDRESSES'),
(526, 'lang_page_title_mis_direcciones', 'ca', 'LES MEVES ADRECES'),
(528, 'msg_no_hay_devoluciones', 'en', 'You have not made any returns'),
(529, 'msg_no_hay_devoluciones', 'ca', 'no has realitzat cap devolució'),
(531, 'misdirecciones_title', 'en', 'MY ADDRESSES'),
(532, 'misdirecciones_title', 'ca', 'LES MEVES ADRECES'),
(534, 'misdirecciones_asegurate_mod', 'en', 'Be sure to update your personal information if you change'),
(535, 'misdirecciones_asegurate_mod', 'ca', 'Assegura&#39;t d&#39;actualitzar la teva informació personal si canvia'),
(537, 'form_update_but', 'en', 'Update'),
(538, 'form_update_but', 'ca', 'actualitzar'),
(540, 'form_del_but', 'en', 'Delete'),
(541, 'form_del_but', 'ca', 'esborrar'),
(543, 'form_set_default_but', 'en', 'Set Main'),
(544, 'form_set_default_but', 'ca', 'establir principal'),
(546, 'form_misdirecciones_name', 'en', 'Quick name'),
(547, 'form_misdirecciones_name', 'ca', 'nom ràpid'),
(549, 'lang_page_title_checkout', 'en', 'Checkout'),
(550, 'lang_page_title_checkout', 'ca', 'Checkout'),
(552, 'cart_empty', 'en', 'Your cart is empty.'),
(553, 'cart_empty', 'ca', 'La seva cistella està buida.'),
(555, 'add_item_cart', 'en', 'Product added to cart'),
(556, 'add_item_cart', 'ca', 'Producte afegit a la cistella'),
(558, 'cart_generado', 'en', 'Cart generated'),
(559, 'cart_generado', 'ca', 'Cistella generat'),
(561, 'cart_error_generar', 'en', 'The cart could not be generated, please try it in a few moments.'),
(562, 'cart_error_generar', 'ca', 'No s&#39;ha pogut generar el carret, si us plau intenteu en uns moments.'),
(564, 'add_item_cart_error', 'en', 'I could not add the product to the cart.'),
(565, 'add_item_cart_error', 'ca', 'No he pogut afegir el producte a la cistella.'),
(567, 'msg_cart_no_hay_compras', 'en', 'You have not made any purchases.'),
(568, 'msg_cart_no_hay_compras', 'ca', 'No ha realitzat cap compra.'),
(573, 'lang_no_iva', 'en', 'There is no VAT'),
(574, 'lang_no_iva', 'ca', 'No hi ha iva'),
(576, 'lang_page_title_cart', 'en', 'Cart'),
(577, 'lang_page_title_cart', 'ca', 'Cistella'),
(579, 'cart_but', 'en', 'Cart'),
(580, 'cart_but', 'ca', 'Cistella'),
(582, 'cart_checkout_but', 'en', 'Finish the purchase'),
(583, 'cart_checkout_but', 'ca', 'Finalitzar la compra'),
(585, 'lang_cart_producto_title', 'en', 'product'),
(586, 'lang_cart_producto_title', 'ca', 'producte'),
(588, 'lang_cart_cantidad_title', 'en', 'quantity'),
(589, 'lang_cart_cantidad_title', 'ca', 'quantitat'),
(591, 'lang_envio', 'en', 'Shipping'),
(592, 'lang_envio', 'ca', 'enviament'),
(594, 'title_lookbook', 'en', 'lookbook'),
(595, 'title_lookbook', 'ca', 'lookbook'),
(597, 'msg_home_welcome', 'en', 'Welcome'),
(598, 'msg_home_welcome', 'ca', 'Benvingut'),
(600, 'msg_no_logged', 'en', 'Already registered? Here you can register or start section.'),
(601, 'msg_no_logged', 'ca', 'Ja estàs registrat? Aqui pots registrar-te o iniciar secio.'),
(603, 'checkout_title_adress_book', 'en', 'Billing Address'),
(604, 'checkout_title_adress_book', 'ca', 'adreça de facturació'),
(606, 'msg_checkout_nodir', 'en', 'At the moment you do not have any saved addresses you need to add one.'),
(607, 'msg_checkout_nodir', 'ca', 'De moment no té cap adreça guardada cal que afegeixi un.'),
(609, 'checkout_pago_title', 'en', 'way to pay'),
(610, 'checkout_pago_title', 'ca', 'forma de pagament'),
(612, 'checkout_pedido_title', 'en', 'order'),
(613, 'checkout_pedido_title', 'ca', 'demanat'),
(615, 'checkout_agree_checkbox', 'en', 'I accept the terms and conditions (+ info)'),
(616, 'checkout_agree_checkbox', 'ca', 'accepto els termes i condicions (+ info)'),
(618, 'checkout_finalizar_but', 'en', 'Checkout'),
(619, 'checkout_finalizar_but', 'ca', 'finalitzar compra'),
(620, 'msg_no_shipping_companies', 'es', 'En estos momentos no realizamos envíos. Disculpen las molestias.'),
(621, 'msg_no_shipping_companies', 'en', 'We do not ship at this time. We apologize for the inconvenience.'),
(622, 'msg_no_shipping_companies', 'ca', 'En aquests moments no realitzem enviaments. Disculpin les molèsties.'),
(623, 'title_select_shipping_comp', 'es', 'Seleccionar compañía de envío'),
(624, 'title_select_shipping_comp', 'ca', 'Seleccionar companyia d''enviament'),
(625, 'title_select_shipping_comp', 'en', 'Select shipping company'),
(626, 'form_num_visa', 'es', 'número de tarjeta'),
(627, 'form_num_visa', 'ca', 'número de targeta'),
(628, 'form_num_visa', 'en', 'Card number'),
(629, 'form_card_expire', 'es', 'fecha de caducidad'),
(630, 'form_card_expire', 'en', 'Date of Expiry'),
(631, 'form_card_expire', 'ca', 'data de caducitat'),
(632, 'form_month', 'es', 'mes'),
(633, 'form_month', 'ca', 'mes'),
(634, 'form_month', 'en', 'month'),
(635, 'form_year', 'es', 'año'),
(636, 'form_year', 'ca', 'any'),
(637, 'form_year', 'en', 'year'),
(638, 'form_card_ccv', 'es', 'código de seguridad (CCV)'),
(639, 'form_card_ccv', 'ca', 'codi de seguretat (CCV)'),
(641, 'form_card_ccv', 'en', 'Security code (CCV)'),
(736, 'MSG0000', 'es', 'El sistema está ocupado, inténtelo más tarde'),
(737, 'MSG0001', 'es', 'Número de pedido repetido'),
(738, 'MSG0002', 'es', 'El Bin de la tarjeta no está dado de alta en FINANET'),
(739, 'MSG0003', 'es', 'El sistema está arrancando, inténtelo en unos momentos'),
(740, 'MSG0004', 'es', 'Error de Autenticación'),
(741, 'MSG0005', 'es', 'No existe método de pago válido para su tarjeta'),
(742, 'MSG0006', 'es', 'Tarjeta ajena al servicio'),
(743, 'MSG0007', 'es', 'Faltan datos, por favor compruebe que su navegador acepta cookies'),
(744, 'MSG0008', 'es', 'Error en datos enviados. Contacte con su comercio.'),
(745, 'MSG0000', 'ca', 'El sistema està ocupat, intenti-ho més tard'),
(746, 'MSG0000', 'en', 'The system is busy, intenti-ho later'),
(747, 'MSG0001', 'en', 'Reorder number'),
(748, 'MSG0001', 'ca', 'Número de comanda repetit'),
(749, 'MSG0002', 'ca', 'El Bin de la targeta no està donat d''alta a Finanet'),
(750, 'MSG0002', 'en', 'The Bin of the card is not registered in FINANET'),
(752, 'MSG0004', 'en', 'Authentication Error'),
(753, 'MSG0004', 'ca', 'Error d''autenticació'),
(754, 'MSG0005', 'en', 'There is no valid payment method for your card'),
(756, 'MSG0005', 'ca', 'No hi ha mètode de pagament vàlid per a la targeta'),
(757, 'MSG0006', 'ca', 'Targeta aliena al servei'),
(758, 'MSG0006', 'en', 'Non-service card'),
(759, 'MSG0007', 'ca', 'Falten dades, si us plau comprovi que el seu navegador accepta cookies'),
(760, 'MSG0007', 'en', 'Missing data, please check that your browser accepts cookies'),
(761, 'MSG0008', 'en', 'Error in sent data. Contact your dealer.'),
(762, 'MSG0008', 'ca', 'Error en dades enviades. Contacti amb el seu comerç.'),
(763, 'checkout_success', 'es', 'La compra se ha realizado correctamente.'),
(764, 'checkout_success', 'ca', 'La compra s''ha realitzat correctament.'),
(765, 'checkout_success', 'en', 'The purchase was successful.'),
(766, 'order_pagado', 'es', 'Pagado'),
(767, 'order_pagado', 'en', 'Paid'),
(768, 'order_pagado', 'ca', 'Pagat'),
(769, 'order_no_pagado', 'es', 'Falta por pagar'),
(770, 'order_no_pagado', 'en', 'Pending to pay'),
(771, 'order_no_pagado', 'ca', 'Falta per pagar'),
(772, 'order_entregado', 'es', 'Entregado'),
(773, 'order_entregado', 'ca', 'Entregat'),
(774, 'order_entregado', 'en', 'Delivered'),
(775, 'order_no_entregado', 'es', 'En camino'),
(776, 'order_no_entregado', 'ca', 'En camí'),
(777, 'order_no_entregado', 'en', 'Pendig delivery'),
(778, 'order_date', 'es', 'Fecha'),
(779, 'order_date', 'en', 'Date'),
(781, 'order_date', 'ca', 'Data'),
(782, 'order_pago', 'es', 'Pago'),
(783, 'order_pago', 'ca', 'Pagament'),
(784, 'order_pago', 'en', 'Payment'),
(785, 'order_estado', 'es', 'Estado'),
(786, 'order_estado', 'ca', 'Estat'),
(787, 'order_estado', 'en', 'Status'),
(788, 'order_tracking_num', 'es', 'Número de seguimiento'),
(790, 'order_tracking_num', 'ca', 'Número de seguiment'),
(791, 'order_tracking_num', 'en', 'Tracking number'),
(792, 'order_no_tracking_no', 'es', 'No asignado'),
(793, 'order_no_tracking_no', 'ca', 'No assignat'),
(794, 'order_no_tracking_no', 'en', 'Not assigned'),
(795, 'order_show_details', 'es', 'Ver detalles'),
(796, 'order_show_details', 'ca', 'Veure comanda'),
(797, 'order_show_details', 'en', 'Order details'),
(798, 'order_actions', 'es', 'Acciones'),
(799, 'order_actions', 'ca', 'Accions'),
(800, 'order_actions', 'en', 'Actions'),
(801, 'email_novalid', 'es', 'Email no válido'),
(802, 'email_novalid', 'ca', 'E-mail no vàlid'),
(803, 'email_novalid', 'en', 'Invalid Email'),
(804, 'regards', 'es', 'Saludos'),
(805, 'regards', 'ca', 'Salutacions'),
(806, 'regards', 'en', 'Regards'),
(807, 'contact_form_confirm', 'es', 'El mensaje se ha enviado correctamente'),
(808, 'contact_form_confirm', 'ca', 'El missatge s''ha enviat correctament'),
(809, 'contact_form_confirm', 'en', 'The message has been sent successfully'),
(810, 'contact_form_error', 'es', 'Se produjo un error al enviar el mensaje, intentelo mas tarde.'),
(811, 'contact_form_error', 'ca', 'S''ha produït un error en enviar el missatge, intenteu més tard.'),
(812, 'contact_form_error', 'en', 'There was an error sending the message, please try again later.'),
(813, 'form_but_send', 'es', 'Enviar'),
(814, 'form_but_send', 'ca', 'Enviar'),
(815, 'form_but_send', 'en', 'Send'),
(816, 'form_message', 'es', 'Mensaje'),
(817, 'form_message', 'ca', 'Missatge'),
(818, 'form_message', 'en', 'Message'),
(819, 'lang_page_title_historial', 'es', 'Historial de pedidos'),
(820, 'lang_page_title_historial', 'ca', 'Historial de comandes'),
(821, 'lang_page_title_historial', 'en', 'Orders history'),
(822, 'mail_order_confirm', 'es', 'Confirmación de pedido'),
(823, 'mail_order_confirm', 'ca', 'Confirmació de comanda'),
(825, 'mail_order_confirm', 'en', 'Order confirmation'),
(826, 'mail_order_confirm_text', 'es', '<p>Estimado cliente:</p><p>Le comunicamos que hemos recibido su pedido y ha quedado registrada en nuestro sistema con siguiente número de referencia <strong>%ref_number%</strong>.</p><br/><br/>'),
(827, 'mail_order_confirm_text', 'ca', '<p>Estimat client:</p>\n<p>Li comuniquem que hem rebut la seva comanda i ha quedat registrada en el nostre sistema amb següent número de referència <strong>%ref_number%</strong>.</p>\n<br/>\n<br/>'),
(828, 'mail_order_confirm_text', 'en', '<p>Dear Customer:</p>\n<p>We inform you that we have received your order and it has been registered in our system with the following reference number <strong>%ref_number%</strong>.</p>\n<br/>\n<br/>'),
(829, 'form_motivo', 'es', 'Motivo'),
(830, 'form_motivo', 'ca', 'Motiu'),
(831, 'form_motivo', 'en', 'Reason'),
(832, 'form_order_id', 'es', 'Número del pedido'),
(833, 'form_order_id', 'en', 'Order id'),
(834, 'form_order_id', 'ca', 'Número de la comanda'),
(835, 'mail_subject_reclamacion', 'es', 'Reclamación'),
(836, 'mail_subject_reclamacion', 'ca', 'Reclamació'),
(837, 'mail_subject_reclamacion', 'en', 'Claim'),
(838, 'mail_message_reclamacion', 'es', 'El Cliente con id: <strong>%ID%</strong> ha iniciado una reclamación por el siguiente motivo: <strong>%MOTIVO%</strong><br/><br/><strong>Mensaje:</strong><br/>'),
(839, 'mail_message_reclamacion', 'ca', 'El Client amb id: <strong>%ID%</strong> ha iniciat una reclamació pel següent motiu: <strong>%MOTIVO%</strong><br/><br/><strong> Missatge:</strong><br/>'),
(840, 'mail_message_reclamacion', 'en', 'The Client with id: <strong>%ID%</strong> has initiated a claim for the next reason:<strong>%REASON%</strong><br/><br/><strong>Message:</strong><br/>'),
(841, 'micuenta_firststeps', 'es', 'Antes de realizar la campra se recomienda rellenar los campos con sus datos personales, posteriormente crear una dirección donde se va envíar.'),
(842, 'micuenta_shipponlyspain', 'es', 'Por el momento el envío solo se realizara en el territorio Español.'),
(843, 'cart_shipping_included', 'es', 'Incluido en el precio'),
(844, 'cart_shipping_included', 'ca', 'Inclòs en el preu'),
(845, 'cart_shipping_included', 'en', 'Included in the price'),
(846, 'country_list_error', 'es', 'La lista no se ha cargado bien'),
(847, 'country_list_error', 'ca', 'La llista no s''ha carregat bé'),
(848, 'country_list_error', 'en', 'The list has not been loaded properly'),
(849, 'creditcard', 'en', 'Credit Card'),
(850, 'creditcard', 'es', 'Tarjeta de crédito'),
(851, 'creditcard', 'ca', 'Targeta de crédit'),
(852, 'no_payment_actived_message', 'es', '<p>Ahora mismo no se puede comprar, estamos estudiando nuevas propuestas de pago.</p>'),
(853, 'no_payment_actived_message', 'ca', '<p>Ara mateix no es pot comprar, estem estudiant noves propostes de pagament.</p>'),
(854, 'no_payment_actived_message', 'en', '<p>You can not buy it right now, we are looking at new payment proposals.</p>'),
(855, 'pordefecto', 'es', 'Por defecto'),
(856, 'pordefecto', 'ca', 'Per defecte'),
(857, 'pordefecto', 'en', 'Default'),
(858, 'lang_page_title_pago_error', 'es', 'La transacción ha fallado'),
(859, 'lang_page_title_pago_error', 'ca', 'La transacció ha fallat'),
(860, 'lang_page_title_pago_error', 'en', 'Transaction failed'),
(861, 'lang_error_stage_leadtext', 'es', 'Error 404 - Oh no! Link roto'),
(862, 'lang_error_stage_leadtext', 'ca', 'Error 404 - Oh no! Link roto'),
(863, 'lang_error_stage_leadtext', 'en', 'Error 404 - Oh no! Link is broken'),
(864, 'back_to_home_but', 'es', 'Quiero ir a la página principal'),
(865, 'back_to_home_but', 'ca', 'Vull anar a la pàgina principal'),
(866, 'back_to_home_but', 'en', 'I want to go to the main page'),
(867, 'lang_error_stage_text', 'es', '<p>Puede ser que el link este mal puesto, o simplemente oculto.</p>'),
(868, 'lang_error_stage_text', 'ca', '<p>Pot ser que el link aquest mal lloc, o simplement ocult.</p>'),
(869, 'lang_error_stage_text', 'en', '<p>It may be that the link is misplaced, or simply hidden.</p>'),
(870, 'lang_pago_error_text', 'es', '<p>La operación de transacción ha fallado.<br/>Pruebe realizar el pago de nuevo.</p>'),
(871, 'lang_pago_error_text', 'ca', '<p>L''operació de transacció ha fallat.<br/>Proveu realitzar el pagament de nou.</p>'),
(872, 'lang_pago_error_text', 'en', '<p>The transaction operation failed.<br/>Try to make the payment again.</p>'),
(873, 'lang_pago_completado_text', 'es', '<p>Su transacción ha sido completada.<br/>En breve recibira el resumen de la compra.<br/>Muchisimas gracias.</p>'),
(874, 'lang_pago_completado_text', 'ca', '<p>El seu transacció ha estat completada.<br/>En breu rebrà el resum de la compra.<br/>Moltíssimes gràcies.</p>'),
(875, 'lang_pago_completado_text', 'en', '<p>Your transaction has been completed.<br/>You will shortly receive the purchase summary.<br/>Thank you very much.</p>'),
(876, 'varios_items', 'es', 'Varios productos'),
(877, 'varios_items', 'ca', 'Varis productes'),
(878, 'varios_items', 'en', 'Various products'),
(879, 'redirection', 'es', 'Redireccionando...'),
(880, 'redirection', 'ca', 'Redireccionant...'),
(881, 'redirection', 'en', 'Redirecting...'),
(882, 'payment_no_redirect', 'es', 'No puedo crear petición de pago. Problema al crear o autenticar usuario.'),
(883, 'payment_no_redirect', 'ca', 'No puc crear petició de pagament. Problema en crear o autenticar usuari.'),
(884, 'payment_no_redirect', 'en', 'I can not create payment request. Problem creating or authenticating user.'),
(885, 'lang_cart_promote_code', 'es', 'Código de promoción'),
(886, 'cart_item_apply_promocode', 'es', 'Descuento aplicado sobre un producto de'),
(887, 'cart_descuento', 'es', 'Descuento'),
(888, 'no_post_content', 'es', 'No hay contenido por el momento'),
(889, 'lang_readmore', 'es', 'Seguir leyendo'),
(890, 'menu_but_blog', 'es', 'Blog'),
(891, 'lang_newsletter_title_success', 'es', 'Mensaje enviado con éxito'),
(892, 'lang_newsletter_msg_success', 'es', 'Muchas gracias!'),
(893, 'lang_newsletter_msg_fail', 'es', 'Ya se han agotado los cupones de descuento.'),
(894, 'mail_subject_oferta', 'es', 'Cupón de descuento'),
(895, 'mail_discount_html', 'es', '<div style="text-align:center;"><p>¡Gracias por contactar con nosotros!</p>\n<p>Por favor introduce el siguiente código en la casilla código de promoción para obtener un descuento del <strong>%percent%%</strong> al hacer la compra.</p>\n<p>%desc%</p>\n<p><strong>CÓDIGO:</strong> <span style="color:#ff0000">%cupon%</span></p></div>'),
(896, 'lang_newsletter_msg_fail_send', 'es', 'Por algún motivo no he podido enviar el código de descuento'),
(897, 'header_lang', 'es', 'idioma'),
(898, 'header_lang', 'en', 'lang.'),
(899, 'header_lang', 'ca', 'idioma'),
(900, 'msg_error_param', 'es', 'Error en el parámetro.'),
(901, 'msg_error_param', 'ca', 'Error en el paràmetre.'),
(902, 'msg_error_param', 'en', 'Error in the parameter.'),
(905, 'lang_color', 'es', 'Color'),
(906, 'lang_color', 'en', 'Color'),
(907, 'lang_color', 'ca', 'Color'),
(908, 'lang_size', 'es', 'Tamaño'),
(909, 'lang_size', 'en', 'Size'),
(910, 'lang_size', 'ca', 'Mida'),
(911, 'lang_select', 'es', 'Seleccionar'),
(912, 'lang_select', 'en', 'Select one'),
(913, 'lang_select', 'ca', 'Seleccionar'),
(914, 'menu_but_socialmedia', 'es', 'Social Media'),
(915, 'menu_but_socialmedia', 'en', 'Social Media'),
(916, 'lang_copy', 'es', 'Todos los derechos reservados.'),
(917, 'lang_copy', 'en', 'All rights reserved'),
(918, 'lang_copy', 'ca', 'Tots els drets reservats'),
(919, 'button_ver', 'es', 'VER'),
(920, 'button_ver', 'ca', 'VEURE'),
(921, 'button_ver', 'en', 'SEE'),
(922, 'title_actividades', 'es', 'ACTIVIDADES'),
(923, 'title_actividades', 'ca', 'ACTIVITATS'),
(924, 'title_actividades', 'en', 'ACTIVITIES'),
(925, 'lang_but_reservar', 'es', 'Reservar'),
(926, 'lang_but_reservar', 'ca', 'Reservar'),
(927, 'lang_but_reservar', 'en', 'Reserve'),
(928, 'lang_but_comollegar', 'es', 'CÓMO LLEGAR'),
(929, 'lang_but_comollegar', 'ca', 'COM ARRIBAR'),
(930, 'lang_but_comollegar', 'en', 'HOW TO GET'),
(931, 'lang_but_listactividades', 'es', 'VOLVER AL LISTADO DE ACTIVIDADES'),
(932, 'lang_but_listactividades', 'en', 'RETURN TO THE LIST OF ACTIVITIES'),
(933, 'lang_but_listactividades', 'ca', 'TORNAR A EL LLISTAT D''ACTIVITATS');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menus`
--

CREATE TABLE IF NOT EXISTS `menus` (
  `id` int(11) unsigned NOT NULL,
  `m_type` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `active` int(1) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `update_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `create_date` datetime DEFAULT NULL,
  `lang` varchar(4) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `menus`
--

INSERT INTO `menus` (`id`, `m_type`, `title`, `active`, `order`, `update_date`, `create_date`, `lang`) VALUES
(1, 1, 'Header', 1, 0, '2018-01-13 17:58:46', '2018-01-09 15:32:06', 'es'),
(2, 3, 'Footer - condiciones', 1, 0, '2018-01-13 17:58:53', '2018-01-09 15:33:34', 'es');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menus_meta`
--

CREATE TABLE IF NOT EXISTS `menus_meta` (
  `id` int(11) unsigned NOT NULL,
  `m_id` int(11) DEFAULT NULL,
  `m_key` varchar(255) DEFAULT NULL,
  `m_value` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menus_structure`
--

CREATE TABLE IF NOT EXISTS `menus_structure` (
  `id` int(11) unsigned NOT NULL,
  `m_id` int(11) DEFAULT NULL,
  `m_parent` int(11) DEFAULT NULL,
  `title` varchar(500) DEFAULT NULL,
  `url` text COMMENT 'url externa',
  `p_id` int(11) DEFAULT NULL COMMENT 'page id',
  `order` int(11) DEFAULT NULL,
  `active` int(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `menus_structure`
--

INSERT INTO `menus_structure` (`id`, `m_id`, `m_parent`, `title`, `url`, `p_id`, `order`, `active`) VALUES
(17, 2, 0, '', '', 18, 0, 1),
(18, 2, 0, '', '', 19, 0, 1),
(21, 3, 0, '', '', 15, 0, 1),
(22, 1, 0, '', '', 10, 0, 1),
(23, 1, 0, '', '', 24, 5, 1),
(26, 1, 0, '', '', 22, 1, 1),
(27, 1, 0, '', '', 25, 6, 1),
(28, 1, 0, 'Viñedos', '', 0, 2, 1),
(33, 1, 0, '', '', 26, 8, 0),
(34, 1, 28, '', '', 27, 0, 1),
(36, 1, 28, '', '', 29, 1, 1),
(42, 1, 33, '', '', 35, 0, 0),
(43, 1, 33, '', '', 36, 1, 0),
(45, 1, 33, '', '', 37, 2, 0),
(47, 1, 0, '', '', 32, 4, 1),
(48, 1, 59, '2019-2020', '', 38, 0, 1),
(49, 1, 59, '', '', 39, 1, 1),
(52, 1, 0, 'Cava', '', 41, 3, 1),
(53, 1, 52, '', '', 33, 0, 1),
(54, 1, 52, '', '', 30, 1, 1),
(56, 1, 0, 'ENOTURISMO', '', 0, 9, 1),
(57, 1, 56, '', '', 42, 0, 1),
(58, 1, 56, '', '', 43, 1, 1),
(59, 1, 0, 'Premios', '', 0, 7, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menus_types`
--

CREATE TABLE IF NOT EXISTS `menus_types` (
  `id` int(11) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `menus_types`
--

INSERT INTO `menus_types` (`id`, `title`) VALUES
(1, 'Header'),
(2, 'Footer - login'),
(3, 'Footer - condiciones');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `options`
--

CREATE TABLE IF NOT EXISTS `options` (
  `ID` bigint(10) NOT NULL,
  `options_key` varchar(255) NOT NULL,
  `options_value` longtext NOT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `options`
--

INSERT INTO `options` (`ID`, `options_key`, `options_value`, `description`) VALUES
(1, 'description', '', 'Meta descripcion de la pagina'),
(2, 'keywords', '', 'Meta keywords'),
(3, 'sitetitle', 'Agustí Torelló Mata', 'Titulo'),
(4, 'sitetitlefull', 'Agustí Torelló Mata', NULL),
(5, 'sitetitleseo', 'ATM', 'Titulo corto para SEO'),
(10, 'dir', '[{"placeTitle":"","dir":"Av. Jaume I, 107 Bx-1, 08880 Cubelles, Barcelona","shortDir":"Av. Jaume I, 107 Bx-1","gmapUrl":"https:\\/\\/goo.gl\\/maps\\/S9M6rcmBpFwb3kJV7","gps":"41.401721, 2.136905","post":"08880","country":"Spain","city":"Barcelona","tel":"+34 93 891 11 73","telAlter":"","cif":"47795265T"}]', NULL),
(13, 'mailinfo', 'info@agustitorellomata.com', 'Mail de info (info@glunt.es)'),
(15, 'botmail', 'mensaje-automatizado@agustitorellomata.com', 'Mail desde donde se contesta'),
(21, 'analytics', '', 'Analytics ID'),
(22, 'addthis', '', 'AddThis ID'),
(23, 'gmaps_key', 'AIzaSyCPd8AtJAVYxjdHbQS3Ti9KzZMj9kuOasA', 'Google maps API Token'),
(24, 'fb', 'https://www.facebook.com/Cava.Agusti.Torello.Mata', 'Facebook'),
(25, 'tw', 'https://twitter.com/ATM_Cava', 'Twitter'),
(26, 'in', 'https://www.instagram.com/agustitorellomatacava', 'Instagram'),
(27, 'gp', 'https://goo.gl/maps/S9M6rcmBpFwb3kJV7', 'Google Plus'),
(28, 'tr', '', 'TripAdvisor'),
(29, 'fb_page_name', '', NULL),
(30, 'fb_page_id', '', NULL),
(31, 'fb_app', '', NULL),
(32, 'fb_secret', '', NULL),
(33, 'fb_token', '', NULL),
(34, 'fb_app_token', '', NULL),
(35, 'tw_costumer_key', '', NULL),
(36, 'tw_costumer_secret', '', NULL),
(37, 'tw_access_token', '', NULL),
(38, 'tw_access_secret', '', NULL),
(39, 'tw_owner', '', NULL),
(40, 'tw_owner_id', '', NULL),
(41, 'dm_nws', 'agustitorellomata.com', NULL),
(42, 'api', '', NULL),
(45, 'tel', '[]', NULL),
(46, 'sideMenu', '', NULL),
(47, 'initial_page', 'el-origen', 'Pagina por defecto'),
(48, 'lang', '["es","en","ca"]', 'Idiomas'),
(49, 'defaultLang', 'es', 'Idioma por defecto'),
(50, 'initial_page_header_type', 'select', 'Home tipo de header en la pagina principal'),
(51, 'default_iva_percentage', '21', 'iva por defecto, se pondra en el caso de que varie el año y no se actualize a tiempo'),
(52, 'redsys_user', '', NULL),
(53, 'redsys_pass', '', NULL),
(54, 'redsys_sha256', '', NULL),
(55, 'redsys_mode', '1', NULL),
(56, 'initial_page_header_gallery_id', '112', 'Home Gallery id de la galeria del header'),
(57, 'initial_page_header_popup_id', '97', 'Home Gallery id del popup'),
(58, 'initial_page_header_popup_enabled', '1', 'Home popup enable / disable'),
(59, 'redsys_active', '1', NULL),
(60, 'redsys_pass_real', '', NULL),
(61, 'redsys_sha256_real', '', NULL),
(62, 'paypal_mode', '1', NULL),
(63, 'paypal_active', '1', NULL),
(64, 'redsys_service', 'redirect', NULL),
(65, 'paypal_apiuser_sandbox', '', NULL),
(66, 'paypal_apipass_sandbox', '', NULL),
(67, 'paypal_apisign_sandbox', '', NULL),
(68, 'paypal_apiuser_live', '', NULL),
(69, 'paypal_apipass_live', '', NULL),
(70, 'paypal_apisign_live', '', NULL),
(71, 'redsys_notification_type', 'post', NULL),
(72, 'home_destacados_cat_id', '1', NULL),
(73, 'home_destacados_cant', '27', NULL),
(74, 'adwords', '', NULL),
(75, 'instagram_api', '', NULL),
(76, 'instagram_token', '', NULL),
(77, 'instagram_secret', '', NULL),
(78, 'instagram_id', '', NULL),
(79, 'instagram_callback', '', NULL),
(81, 'fb_pixel', '', NULL),
(82, 'standartEmail', '<!doctype html><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><meta name="viewport" content="width:device-width, initial-scale:1.0"><title>%title%</title><style type="text/css">.ReadMsgBody {width: 100%;background-color: #e9eaed;} .ExternalClass {width: 100%; background-color: #e9eaed; } body {width: 100%;background-color: #ffffff;margin: 0;padding: 0;-webkit-font-smoothing: antialiased;font-family: Georgia, Times, serif;} table {border-collapse: collapse;} .mobile-only {display: none;} @media only screen and (max-width: 640px) {body[yahoo] .deviceWidth {width: 440px!important;padding: 0;} body[yahoo] .paddedblockWidth{width: 400px!important;padding: 0;} body[yahoo] .button {width: 400px!important;padding: 0;} body[yahoo] .center {text-align: center!important;} .paddingleft {padding: 20px 20px 16px 20px!important;}} @media only screen and (max-width: 479px) {body[yahoo] .deviceWidth {width: 280px!important;padding: 0;} body[yahoo] .paddedblockWidth{width: 240px!important;padding: 0;} body[yahoo] .button {width: 240px!important;padding: 0;} body[yahoo] .center {text-align: center!important;}}</style></head><body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" yahoo="fix" style="font-family: Arial, Times, serif"><table width="100%" border="0" cellpadding="0" cellspacing="0" align="center"><tr><td><table width="580" border="0" cellpadding="0" cellspacing="0" align="center" class="deviceWidth"><tr><td width="100%" height="30" padding="" font-family="" font-size="" color="" text-align="" line-height="">&nbsp;</td></tr></table></td></tr></table><table width="100%" border="0" cellpadding="0" cellspacing="0" align="center"><tr><td width="100%" valign="top"><table width="580" align="center" class="deviceWidth" border="0" cellspacing="0" cellpadding="0"><tbody><tr><td style="padding: 0px 20px 20px; text-align: left; color: #6a7480; line-height: 18px; font-family: Arial, sans-serif; font-size: 14px; font-weight: normal; vertical-align: top;" bgcolor="#ebebeb"><br><p style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;margin-top:0;margin-bottom:24px;margin-right:0;margin-left:0;">%message%<br/><br><span>%regards%</span><br><span><b>%site_name%</b></span></td></tr></tbody></table><div style="height: 25px">&nbsp;</div><table width="100%" border="0" cellspacing="0" align="center"><tr><td style="padding: 30px"><table width="580" border="0" cellpadding="0" cellspacing="0" align="center" class="deviceWidth"><tr><td><table width="45%" cellpadding="0" cellspacing="0" border="0" align="left" class="deviceWidth"> <tr><td valign="top" style="font-size: 11px; color: #9197a3; font-family: Arial, sans-serif; padding-bottom: 20px; line-height: 16px;" class="center"><br>Copyright &#169; %site_name%.<br> %copyz%<br><br><span style="font-size:11px;color:#9197a3;font-family: Arial, sans-serif;line-height: 14px;">%site_dir%</span><br><br></td></tr></table><table width="40%" cellpadding="0" cellspacing="0" border="0" align="right" class="deviceWidth"><tr><td valign="top" style="font-size: 11px; color:#9197a3; font-weight: normal; font-family: Arial, Times, serif; line-height: 16px; vertical-align: top; text-align: right" class="center">%site_logo%</td></tr></table></td></tr></table></td></tr></table></td></tr></table></body></html>', NULL),
(83, 'tooSHash', '6254bd05df70f6c57df731d908873252', NULL),
(84, 'tooSType', '1', NULL),
(85, 'dirDefault', '0', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) unsigned NOT NULL,
  `obj_title` varchar(255) DEFAULT NULL,
  `obj_hash` varchar(100) DEFAULT NULL,
  `type` int(11) DEFAULT '1',
  `create_date` datetime DEFAULT NULL,
  `active` int(1) DEFAULT '0',
  `protected` int(1) DEFAULT '0',
  `lang` varchar(5) DEFAULT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `pages`
--

INSERT INTO `pages` (`id`, `obj_title`, `obj_hash`, `type`, `create_date`, `active`, `protected`, `lang`, `update_date`) VALUES
(8, 'Contacto', 'contacto', 1, '2018-01-09 00:00:00', 1, 1, 'es', '2020-01-31 11:17:16'),
(10, 'Origen', 'origen', 1, '2018-01-09 00:00:00', 1, 1, 'es', '2020-09-07 12:29:44'),
(25, 'Productos', 'productos', 7, '2019-02-25 00:00:00', 1, 1, 'es', '2019-02-25 20:05:56'),
(24, 'Kripta', 'kripta', 1, '2019-02-15 00:00:00', 1, 1, 'es', '2019-02-15 20:12:02'),
(14, 'login', 'login', 1, '2018-02-01 00:00:00', 1, 1, 'es', '2018-02-01 11:43:56'),
(15, 'Recuperación de contraseña', 'recuperacion-de-contrasena', 1, '2018-02-01 00:00:00', 1, 1, 'es', '2018-02-01 15:44:53'),
(23, 'Enoturismo y Club', 'enoturismo-y-club', 1, '2019-02-15 00:00:00', 1, 1, 'es', '2020-06-11 11:32:20'),
(18, 'Política de privacidad', 'politica-de-privacidad', 1, '2018-02-06 00:00:00', 1, 1, 'es', '2019-02-18 11:58:04'),
(19, 'Política de cookies', 'politica-de-privacidad-y-cookies', 1, '2018-02-06 00:00:00', 1, 1, 'es', '2019-02-18 11:58:30'),
(22, 'ADN', 'adn', 1, '2019-02-15 00:00:00', 1, 1, 'es', '2020-02-19 10:45:33'),
(21, 'error', 'error', 1, '2018-02-23 00:00:00', 1, 1, 'es', '2019-02-15 20:00:41'),
(26, 'Premios', 'premios', 1, '2019-04-03 00:00:00', 0, 1, 'es', '2020-09-22 08:52:34'),
(27, 'El Origen', 'el-origen', 1, '2019-04-04 00:00:00', 1, 1, 'es', '2019-04-08 11:28:41'),
(28, 'VITICULTURA ECOLÓGICA', 'viticultura-ecologica', 1, '2019-04-04 00:00:00', 1, 1, 'es', '2019-04-04 20:06:09'),
(29, 'VARIEDADES AUTÓCTONAS', 'variedades-autoctonas', 1, '2019-04-04 00:00:00', 1, 1, 'es', '2019-04-04 20:14:33'),
(30, 'Crianza Y Degüelle', 'crianza-y-deguelle', 1, '2019-04-06 00:00:00', 1, 1, 'es', '2020-09-09 23:04:41'),
(31, 'Degüelle', 'deguelle', 1, '2019-04-06 00:00:00', 1, 0, 'es', '2019-04-06 17:24:48'),
(32, 'Vinos', 'vinos', 1, '2019-04-06 00:00:00', 1, 1, 'es', '2020-09-09 23:36:25'),
(33, 'Elaboración y Cupages', 'elaboracion-y-cupages', 1, '2019-04-11 00:00:00', 1, 1, 'es', '2020-09-14 20:39:54'),
(34, 'Cupajes', 'cupajes', 1, '2019-04-11 00:00:00', 1, 0, 'es', '2019-04-11 10:35:57'),
(35, 'Espantallops', 'premis-espantallops', 1, '2020-02-12 00:00:00', 0, 1, 'es', '2020-09-23 09:41:05'),
(36, 'Barrica', 'premios-barrica', 1, '2020-02-12 00:00:00', 0, 0, 'es', '2020-09-23 09:41:17'),
(37, 'Kripta', 'premios-kripta', 1, '2020-02-13 00:00:00', 0, 0, 'es', '2020-09-23 09:41:27'),
(38, '2019-2020', '2019-2020', 1, '2020-06-10 00:00:00', 1, 0, 'es', '2020-06-10 19:30:28'),
(39, 'Histórico', 'historico', 1, '2020-06-10 00:00:00', 1, 1, 'es', '2020-09-14 21:56:06'),
(40, 'presentacion', 'presentacion', 6, '2020-09-07 00:00:00', 1, 1, 'es', '2020-09-07 12:30:34'),
(41, 'Cava', 'cava', 1, '2020-09-09 00:00:00', 1, 1, 'es', '2020-09-09 19:25:05'),
(42, 'Visitas', 'visitas', 1, '2020-09-11 00:00:00', 1, 1, 'es', '2020-09-11 18:34:58'),
(43, 'Actividades', 'actividades', 9, '2020-09-11 00:00:00', 1, 1, 'es', '2020-09-12 15:38:25'),
(44, 'Sopar de verema - 19 Septembre 2020', 'sopar-de-verema-19-septembre-2020', 8, '2020-09-12 00:00:00', 0, 0, 'es', '2020-09-22 09:37:39'),
(51, 'Proba activitat 2020', 'proba-activitat-2020', 8, '2020-09-21 00:00:00', 0, 0, 'es', '2020-09-22 00:07:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pages_lang_rel`
--

CREATE TABLE IF NOT EXISTS `pages_lang_rel` (
  `id` int(11) unsigned NOT NULL,
  `page_id` int(11) DEFAULT NULL,
  `lang_type` varchar(2) DEFAULT '',
  `page_translate_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pages_meta`
--

CREATE TABLE IF NOT EXISTS `pages_meta` (
  `id` int(11) unsigned NOT NULL,
  `p_id` int(11) DEFAULT NULL,
  `meta_key` varchar(100) DEFAULT NULL,
  `meta_value` longtext
) ENGINE=InnoDB AUTO_INCREMENT=6864 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `pages_meta`
--

INSERT INTO `pages_meta` (`id`, `p_id`, `meta_key`, `meta_value`) VALUES
(1, 21, 'page_content', 'ZmFsc2U='),
(2, 21, 'seo_resumen', ''),
(3, 21, 'seo_checktitleonfreaturedimage', '0'),
(4, 21, 'seo_customtitleonfreaturedimage', ''),
(5, 21, 'seo_freaturedimage', ''),
(6, 21, 'seo_noodp', '0'),
(7, 21, 'seo_noydir', '0'),
(8, 21, 'seo_nofollow', '0'),
(9, 21, 'seo_noarchive', '0'),
(10, 21, 'seo_keywords', ''),
(11, 21, 'seo_description', ''),
(12, 21, 'seo_customimage', ''),
(13, 10, 'page_content', 'W3sidHlwZSI6InctMS0xIHB0LTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEgcGItMyBwYi03QHMgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPlVOIENBVkEgQ09OIE5PTUJSRSBQUk9QSU88L2I+PC9oMT4ifX0seyJ0eXBlIjoidy0xLTEgd3MtMS0xIGhtIGhsIGh4bCBwYi03ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50LzkwMmExNjU4M2I1OWYxNDk5ZGFlNWVjODBmZDNlZDM1LmpwZyYjMzk7Pjxicj4ifX0seyJ0eXBlIjoibWMgdy0xLTIgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGRpdiBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+PGI+QWd1c3TDrSBUb3JlbGzDsyBNYXRhPC9iPiBuYWNlIGVuIFNhbnQgU2FkdXJuaSBk4oCZQW5vaWEgZW4gMTkzNSwgaGlqbyBkZSBzYXN0cmVzIHkgbcO6c2ljb3MuIENvbWllbnphIGEgdHJhYmFqYXIgYSBsb3MgMTQgYcOxb3MgeSBhIGxvcyAxOCBhw7FvcyBhYnJlIGVsIHByaW1lciBsYWJvcmF0b3JpbyBkZSBhbsOhbGlzaXMgZGUgdmlub3MgZGUgU2FudCBTYWR1cm5pLiBFbiAxOTYwIHNlIGNhc2EgY29uIENhcm1lbiBTaWJpbGwgQ2FyZMO6cywgaW5pY2lhbmRvIHVuYSB2aWRhIHF1ZSBnaXJhcsOhIHNpZW1wcmUgYWxyZWRlZG9yIGRlbCBjYXZhIHkgcXVlIGxvIGNvbnNvbGlkYXLDoSBjb21vIHVubyBkZSBsb3MgbWVqb3JlcyBlbsOzbG9nb3MgZGVsIHBhw61zLjxicj48YnI+SG9tYnJlIGNvbnNhZ3JhZG8gYWwgQ2F2YSwgZW4gMTk1NSBlbGFib3JhIHN1cyBwcmltZXJhcyA1MDAgYm90ZWxsYXMgZGUgY2F2YSwgbWllbnRyYXMgYXNlc29yYSB5IGRpcmlnZSBkdXJhbnRlIGHDsW9zIGltcG9ydGFudGVzIGVtcHJlc2FzIGRlbCBzZWN0b3IuIEVuIDE5NzggZWxhYm9yYSBzdSBvYnJhIG1hZXN0cmE6IEtSSVBUQSwgcmVjb25vY2lkbyBjb21vIHVubyBkZSBsb3MgZ3JhbmRlcyBlc3B1bW9zb3MgZGVsIG11bmRvLjwvZGl2PiJ9fSx7InR5cGUiOiJ3LTEtMiBocyAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC85MDJhMTY1ODNiNTlmMTQ5OWRhZTVlYzgwZmQzZWQzNS5qcGcmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0xIHB0LTIgcGItMiAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMiB3cy0xLTEgcGItNCBwdC0yQHMgcGItN0BzICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50LzdjZjU3MDEzMGQ2YzI2ZmYzN2E5MTY2MzJiZGE5MDI5LmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoidy0xLTIgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGRpdiBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+Q29uIHVuYSBwcm9kdWNjacOzbiBhbnVhbCBkZSA1MDAuMDAwIGJvdGVsbGFzIGRlIGNhdmEgeSAxNTAuMDAwIGRlIHZpbm8sIEFHVVNUw40gVE9SRUxMw5MgTUFUQSBlc3TDoSBwcmVzZW50ZSBlbiBtw6FzIGRlIDMwIHBhw61zZXMuIDxicj48YnI+QmFqbyBsYSBkaXJlY2Npw7NuIGFjdHVhbCBkZSBzdXMgMiBoaWpvczogQWxleCAtIGVuw7Nsb2dvLCBkaXJlY3RvciB0w6ljbmljbyB5IHZpdGljdWx0dXJhIHkgR2VtbWEsIGFib2dhZGEgeSBhZG1pbmlzdHJhZG9yYSBkZSBsYSBjb21wYcOxw61hLCBzb24gdW4gcmVmZXJlbnRlIGVuIGxhcyBlbXByZXNhcyBmYW1pbGlhcmVzIGRlbCBDYXZhLjxicj48YnI+TmFjaWRvcyBjb24gbGEgaG9uZXN0aWRhZCBkZSBsb3MgaHVtaWxkZXMsIG5vcyBwcm95ZWN0YW1vcyBhbCBtdW5kbyBjb24gZWwgc2VsbG8gZGUgdW5hIGZhbWlsaWEgY29uIEFMTUEgQ0FWQS48YnI+PC9kaXY+In19XQ=='),
(14, 10, 'seo_resumen', ''),
(15, 10, 'seo_checktitleonfreaturedimage', '0'),
(16, 10, 'seo_customtitleonfreaturedimage', ''),
(17, 10, 'seo_freaturedimage', ''),
(18, 10, 'seo_noodp', '0'),
(19, 10, 'seo_noydir', '0'),
(20, 10, 'seo_nofollow', '0'),
(21, 10, 'seo_noarchive', '0'),
(22, 10, 'seo_keywords', ''),
(23, 10, 'seo_description', ''),
(24, 10, 'seo_customimage', ''),
(25, 22, 'page_content', 'W3sidHlwZSI6InctMS0xIHB0LTQiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBwYi0zIHBiLTdAcyAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PGI+QUROOiBOVUVTVFJBIEVTRU5DSUE8L2I+PC9oMT4ifX0seyJ0eXBlIjoidy0xLTEgZ2MiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJtYyB3LTEtMSBwYi00QHMgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiJtdC1uQHMiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvODNlNmViNDdmNTEzZjdkMDgwZjVlZjlkNTZlN2RmNDUuanBnJiMzOTsgY2xhc3M9JiMzOTttYyYjMzk7Pjxicj4ifX0seyJ0eXBlIjoidy0xLTEgZyIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiIn19LHsidHlwZSI6Im1jIHctOC0xMCBocyBwdC0yIHByLTMgcGItNCBwbC0zICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiYmFja2dyb3VuZC1jb2xvcjojZmZmOyBtYXJnaW4tdG9wOiAtNDVweDsgLXdlYmtpdC1jb2x1bW4tY291bnQ6MjstbW96LWNvbHVtbi1jb3VudDoyO2NvbHVtbi1jb3VudDoyOy13ZWJraXQtY29sdW1uLWdhcDogNDdweDstbW96LWNvbHVtbi1nYXA6IDQ3cHg7Y29sdW1uLWdhcDogNDdweDsiLCJjY2xhc3MiOiJtdC1uQHMiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+VW4gdG90YWwgZGUgPGI+MTUwIHBhcmNlbGFzIMO6bmljYXM8L2I+IHNvbiBlbCBvcmlnZW4gZGUgdG9kb3MgbnVlc3Ryb3Mgdmlub3MgIHkgY3VwYWdlcy4gVG9kYXMgZWxsYXMgZGUgY3VsdGl2byA8Yj5lY29sw7NnaWNvICB5IHZlbmRpbWlhIGEgbWFubzwvYj4uIFZpbmlmaWNhZG8gMTAwJSBlbiBsYSBwcm9waWVkYWQuPGJyPiA8YnI+U8OzbG8gPGI+dmFyaWVkYWRlcyBhdXTDs2N0b25hczwvYj46IE1BQ0FCRU8sIFhBUkVMLkxPLCBQQVJFTExBREEgeSBUUkVQQVQgcGFyYSBlbCByb3NhZG8uIEVuIGNhZGEgY29zZWNoYSBzZWxlY2Npb25hbW9zLCBjb24gY3VsdGl2byBtaWNyb2Jpb2zDs2dpY28sIGxhcyBtZWpvcmVzIGxldmFkdXJhcyBkZSBjYWRhIHZhcmllZGFkLiBBc8OtIG51ZXN0cm9zIHZpbm9zIGZlcm1lbnRhbiBjYWRhIGHDsW8gY29uIDxiPmxldmFkdXJhcyBwcm9waWFzPC9iPiBjZXJyYW5kbyBlbCBjw61yY3VsbyBzaW5ndWxhciBkZSBsb3MgdmnDsWVkb3MgZGUgb3JpZ2VuLjxicj48YnI+PGI+Vml0aWN1bHR1cmEgZGUgbW9udGHDsWE8L2I+OiBMYSBmaW5jYSBVQkFDIGRlIE1lZGlvbmEsIGEgNTUwbSBkZSBhbHRpdHVkLCBlcyBsYSBjdW5hIGRlIG51ZXN0cmFzIHV2YXMgIFBhcmVsbGFkYSB5IFRyZXBhdCBxdWUgY29uZmllcmVuIHVuIHNlbGxvIGRpc3RpbnRvIHkgw7puaWNvIGEgbnVlc3Ryb3MgY3VwYWdlczogZWwgaW50ZXJjYW1iaW8gdMOpcm1pY28gbm9jaGUvZMOtYSB5IGVsIHBhcnRpY3VsYXIgc3VlbG8gZGUgcGl6YXJyYXMgYXBvcnRhIHVuIGNhcsOhY3RlciBtaW5lcmFsIGV4Y2VwY2lvbmFsLjxicj48YnI+PGI+TWFlc3Ryb3MgZGUgbGEgTWFjYWJlbzwvYj4uIEF1dG9yZXMgZGVsIMO6bmljbyBjYXZhIG1vbm92YXJpZXRhbCBNYWNhYmVvIGZlcm1lbnRhZG8gZW4gYmFycmljYS4gTGEgTWFjYWJlbyBlcyBzaWVtcHJlIGxhIHZhcmllZGFkIGRvbWluYW50ZSBlbiBsb3MgY3VwYWdlcyBBR1VTVMONIFRPUkVMTMOTIE1BVEEuPGJyPjxicj48Yj5MYXJnYXMgY3JpYW56YXMgZW4gYm90ZWxsYTwvYj46IFPDs2xvIFJlc2VydmFzIGNvbiAyNCBtZXNlcyBtw61uaW1vIGRlIGNyaWFuemEsIHkgR3JhbmRlcyBSZXNlcnZhIGNvbiBjcmlhbnphcyBkZXNkZSBsb3MgMyBoYXN0YSBsb3MgMTAgYcOxb3MuPGJyPjxicj5Tb21vcyBoZXJlZGVyb3MgZGUgbnVlc3RybyB0cmFiYWpvLCB5IGZvcmphZG9yZXMgZGUgdW4gZnV0dXJvIGNvbmp1bnRvIGNvbiBsb3Mgdml0aWN1bHRvcmVzIGRlIG51ZXN0cmEgdGllcnJhLjxicj48L3A+In19LHsidHlwZSI6InctMS0xIHdzLTEtMSBobSBobCBoeGwgcHQtNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz5VbiB0b3RhbCBkZSA8Yj4xNTAgcGFyY2VsYXMgw7puaWNhcywmbmJzcDs8L2I+dG9kYXMgZGUgPGI+Y3VsdGl2byBlY29sw7NnaWNvIHkgdmVuZGltaWFkYXMgYSBtYW5vPC9iPiwgc29uIGVsIG9yaWdlbiBkZSB0b2RvcyBudWVzdHJvcyB2aW5vcyB5IGN1cGFnZXMgdmluaWZpY2Fkb3MgMTAwJSBlbiBsYSBwcm9waWVkYWQmbmJzcDs8YnI+PGJyPkVsYWJvcmFtb3MgY29uIHZhcmllZGFkZXMgYXV0w7NjdG9uYXM6IE1BQ0FCRU8gLCBYQVJFTC5MTywgUEFSRUxMQURBIHkgVFJFUEFUIHBhcmEgZWwgcm9zYWRvLiBFbiBjYWRhIGNvc2VjaGEgc2VsZWNjaW9uYW1vcywgY29uIGN1bHRpdm8gbWljcm9iaW9sw7NnaWNvLCBsYXMgbWVqb3JlcyBsZXZhZHVyYXMgZGUgY2FkYSB2YXJpZWRhZC4gQXPDrSBudWVzdHJvcyB2aW5vcyBmZXJtZW50YW4gY2FkYSBhw7FvIGNvbiA8Yj5sZXZhZHVyYXMgcHJvcGlhczwvYj4gY2VycmFuZG8gZWwgY8OtcmN1bG8gc2luZ3VsYXIgZGUgbG9zIHZpw7FlZG9zIGRlIG9yaWdlbi48YnI+PGJyPjxiPlZpdGljdWx0dXJhIGRlIG1vbnRhw7FhPC9iPjogTGEgZmluY2EgVUJBQyBkZSBNZWRpb25hLCBhIDU1MCBtLiBkZSBhbHRpdHVkLCBlcyBsYSBjdW5hIGRlIG51ZXN0cmFzIHV2YXMgIFBhcmVsbGFkYSB5IFRyZXBhdCBxdWUgY29uZmllcmVuIHVuIHNlbGxvIGRpc3RpbnRvIHkgw7puaWNvIGEgbnVlc3Ryb3MgY3VwYWdlczogZWwgaW50ZXJjYW1iaW8gdMOpcm1pY28gbm9jaGUvZGlhIHkgZWwgcGFydGljdWxhciBzdWVsbyBkZSBwaXphcnJhcyBhcG9ydGEgdW4gY2Fyw6FjdGVyIG1pbmVyYWwgZXhjZXBjaW9uYWwuIDxicj48L3A+PGRpdiBjbGFzcz0mIzM5O3ctMS0xIGhsJiMzOTs+PGRpdiBjbGFzcz0mIzM5O3ctMS0xIHB0LTQmIzM5Oz48L2Rpdj48aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvNzIwYTcxZTcwMDI5MjFhYjM4NDY5ZDI2Yzc3NjUwYzYuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGRpdiBjbGFzcz0mIzM5O3ctMS0xIHB0LTgmIzM5Oz48L2Rpdj48L2Rpdj48Yj5NYWVzdHJvcyBkZSBNYWNhYmVvLjwvYj4gQXV0b3JlcyBkZWwgw7puaWNvIGNhdmEgbW9ub3ZhcmlldGFsIE1hY2FiZW8gZmVybWVudGFkbyBlbiBiYXJyaWNhLiBMYSB2YXJpZWRhZCBNYWNhYmVvIGVzIHNpZW1wcmUgbGEgZG9taW5hbnRlIGVuIGxvcyBjdXBhZ2VzIEFHVVNUSSBUT1JFTExPIE1BVEEuPGJyPjxicj48Yj5MYXJnYXMgY3JpYW56YXMgZW4gYm90ZWxsYTo8L2I+IFPDs2xvIFJlc2VydmFzIGNvbiAyNCBtZXNlcyBtw61uaW1vIGRlIGNyaWFuemEsIHkgR3JhbmRlcyBSZXNlcnZhcyBjb24gY3JpYW56YXMgZGVzZGUgbG9zIDMgaGFzdGEgbG9zIDEwIGHDsW9zLjxicj48YnI+U29tb3MgaGVyZWRlcm9zIGRlIG51ZXN0cm8gdHJhYmFqbywgeSBmb3JqYWRvcmVzIGRlIHVuIGZ1dHVybyBjb25qdW50byBjb24gbG9zIHZpdGljdWx0b3JlcyBkZSBudWVzdHJhIHRpZXJyYS48cD48L3A+In19LHsidHlwZSI6InctMS0xIHB0LTIgcGItMiAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJtYyB3LTgtMTAgaHMgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50LzcyMGE3MWU3MDAyOTIxYWIzODQ2OWQyNmM3NzY1MGM2LmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoidy0xLTEgcGItNCIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6e319XQ=='),
(26, 22, 'seo_resumen', ''),
(27, 22, 'seo_checktitleonfreaturedimage', '0'),
(28, 22, 'seo_customtitleonfreaturedimage', ''),
(29, 22, 'seo_freaturedimage', ''),
(30, 22, 'seo_noodp', '0'),
(31, 22, 'seo_noydir', '0'),
(32, 22, 'seo_nofollow', '0'),
(33, 22, 'seo_noarchive', '0'),
(34, 22, 'seo_keywords', ''),
(35, 22, 'seo_description', ''),
(36, 22, 'seo_customimage', ''),
(37, 23, 'page_content', 'W3sidHlwZSI6InctMS0xIHB0LTQiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBwYi0zIHBiLTdAcyAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PGI+RU5PVFVSSVNNTyAmYW1wOyBDTFVCPC9iPjwvaDE+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0mIzM5O3AxJiMzOTs+PGI+TGFzIEN1YXRybyBFc3RhY2lvbmVzIERlbCBDYXZhPC9iPjxicj48L3A+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHBiLTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cD5VbiBlc3BhY2lvIGRvbmRlIGVsIHZpc2l0YW50ZSB2aXZlIGVsIGNpY2xvIHZpdGFsIGRlbCBjYXZhIGRlc2RlIHN1IG9yaWdlbjogdXZhLCB2acOxYSwgdmlubyB5IGJ1cmJ1amFzIHNlIGZ1c2lvbmFuIGVuIHVuIHBhc2VvIHBvciBsYXMgY3VhdHJvIGVzdGFjaW9uZXMgZGVsIGHDsW8gYSB0cmF2w6lzIGRlIGxvcyBvam9zIGRlbCBjYXZhLjxicj48YnI+VW5hIGV4cGVyaWVuY2lhIGltcGFjdGFudGUgZG9uZGUgbGEgdmnDsWEgc2UgY29udmllcnRlIGVuIGVsIGhpbG8gY29uZHVjdG9yIGRlbCBwcm9jZXNvIGRlbCBjYXZhLCBlbiB1bmEgcGFudGFsbGEgcXVlIGRlc3BpZXJ0YSB0b2RvcyBsb3Mgc2VudGlkb3MuPGJyPjxicj5VbiBob21lbmFqZSBhIGxhIHRpZXJyYSB5IGEgc3VzIGhvbWJyZXMsIHBvcnF1ZSBjb25zZWd1aXIgcXVlIHVuIGdyYW5vIGRlIHV2YSBzZSB0cmFuc2Zvcm1lIGVuIHVuIHZpbm8gY29uIG3DunNpY2EgeSB2aWRhIHByb3BpYSwgZXMgYWxnbyBxdWUgZXN0w6Egc29sbyBhbCBhbGNhbmNlIGRlIGxvcyBxdWUgaGFjZW4gcmVhbGlkYWQgc3VzIHN1ZcOxb3MuPGJyPk51ZXN0cm8gc3Vlw7FvIGVzIGNvbXBhcnRpciBsbyBxdWUgdml2aW1vcyBkdXJhbnRlIHRvZG8gZWwgYcOxby48L3A+In19LHsidHlwZSI6InctMS0xIHB0LTQgcGItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PGI+VklTSVRBUzwvYj48L2gxPiJ9fSx7InR5cGUiOiJ3LTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IiJ9fSx7InR5cGUiOiJ3LTEtMiB3cy0xLTEgcGItMTBAcyAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48Yj5WSVNJVEEgR1JBTiBSRVNFUlZBPC9iPjwvcD48cCBjbGFzcz0mIzM5O3AxIHR4dEBqJiMzOTs+PGk+VmlzaXRhIGd1aWFkYSB5IGRlZ3VzdGFjacOzbiBkZSB0cmVzIGNhdmFzIHkgdW4gdmlubzwvaT48L3A+PHAgY2xhc3M9JiMzOTtwMSB0eHRAaiYjMzk7PlJlY29ycmlkbyBndWlhZG8gcG9yIGxhcyBpbnN0YWxhY2lvbmVzIGRlIGxhIGJvZGVnYSBkZSB2aW5pZmljYWNpw7NuIHkgcG9yIGxhcyBjYXZhcyBwYXJhIGNvbm9jZXIgbGFzIGNhcmFjdGVyw61zdGljYXMgZGVsIFBlbmVkw6hzIHkgbGFzIHBhcnRpY3VsYXJpZGFkZXMgZGVsIHByb2Nlc28gZGUgZWxhYm9yYWNpw7NuIHkgY3JpYW56YSBkZSBudWVzdHJvcyBjYXZhcy48YnI+PGJyPjxicj5EZWd1c3RhY2nDs24gY29tZW50YWRhIGRlIHVuIHZpbm8geSB0cmVzIGNhdmFzLjwvcD48cCBjbGFzcz0mIzM5O3AxIHR4dEBqJiMzOTs+PGk+PGJyPkR1PC9pPjxpPnI8L2k+PGk+YWNpw7NuOiA2MCBtaW51PC9pPjxpPnQ8L2k+PGk+b3MuPGJyPjwvaT48aT5QcmVjaW8gcG9yIHBlcnNvbmE6IDE1PC9pPjxpPuKCrDwvaT48L3A+In19LHsidHlwZSI6InctMS0yIHdzLTEtMSBwYi0xMEBzICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPlZJU0lUQSBWSVA8L2I+PC9wPjxwIGNsYXNzPSYjMzk7cDEmIzM5Oz48aT5UPC9pPjxpPm91ciBwcmk8L2k+PGk+djwvaT48aT5hZG8geSBkZWd1PC9pPjxpPnM8L2k+PGk+dGFjacOzbiBkZSA1IGM8L2k+PGk+YXY8L2k+PGk+YXMgKGluY2x1PC9pPjxpPnk8L2k+PGk+ZSBjPC9pPjxpPmE8L2k+PGk+dGEgZGUgS3JpcHRhKSB5IHVuIHZpbm88L2k+PC9wPjxwIGNsYXNzPSYjMzk7cDEmIzM5Oz5WaXNpdGEgZ3VpYWRhIHByaXZhZGEgcG9yIGxhcyBpbnN0YWxhY2lvbmVzIGRlIGxhIGJvZGVnYSBkZSB2aW5pZmljYWNpw7NuIHkgcG9yIGxhcyBjYXZhcyBwYXJhIGNvbm9jZXIgbGFzIGNhcmFjdGVyw61zdGljYXMgZGVsIFBlbmVkw6hzIHkgbGFzIHBhcnRpY3VsYXJpZGFkZXMgZGVsIHByb2Nlc28gZGUgZWxhYm9yYWNpw7NuIHkgY3JpYW56YSBkZSBudWVzdHJvcyBjYXZhcy48L3A+PGJyPjxwIGNsYXNzPSYjMzk7cDEmIzM5Oz5TZXNpw7NuIGRlIGRlZ3VzdGFjacOzbiBjb21lbnRhZGEgZGUgbnVlc3Ryb3MgY2F2YXMgbcOhcyByZXByZXNlbnRhdGl2b3MuPGJyPjxpPjxicj5EdTwvaT48aT5yPC9pPjxpPmFjacOzbjogMiBobzwvaT48aT5yPC9pPjxpPmFzLjxicj48L2k+PGk+UHJlY2lvIHBvciBwZXJzb25hOiA1MDwvaT48aT7igqw8L2k+PC9wPjxwIGNsYXNzPSYjMzk7cDMmIzM5Oz48aT48L2k+PC9wPjxicj4ifX0seyJ0eXBlIjoidy0xLTEgd3MtMS0xIHB0LTUgcGItMyAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwPjxiPkNPTlRBQ1RPPC9iPjwvcD48cD48Yj5Db250YWN0byB0ZWzDqWZvbm86PC9iPiA8YSBocmVmPSYjMzk7dGVsOjkzODkxMTE3MyYjMzk7PiA5MyA4OTEgMTEgNzM8L2E+PGJyPjwvcD48cD48Yj5Db250YWN0byBjb3JyZW8gZWxlY3Ryw7NuaWNvOjwvYj4gPGEgaHJlZj0mIzM5O21haWx0bzp2aXNpdGVzQGFndXN0aXRvcmVsbG9tYXRhLmNvbSYjMzk7PnZpc2l0ZXNAYWd1c3RpdG9yZWxsb21hdGEuY29tPC9hPjwvcD4ifX0seyJ0eXBlIjoidy0xLTEgd3MtMS0xIHB0LTVAcyBwYi01QHMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEgZ2MiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC80ZDY2MGRhN2IxMTg2MGNjYWVmN2ViMmFiYzUzOWNkYi5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0xIHB0LTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEgcGItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fV0='),
(38, 23, 'seo_resumen', ''),
(39, 23, 'seo_checktitleonfreaturedimage', '0'),
(40, 23, 'seo_customtitleonfreaturedimage', ''),
(41, 23, 'seo_freaturedimage', ''),
(42, 23, 'seo_noodp', '0'),
(43, 23, 'seo_noydir', '0'),
(44, 23, 'seo_nofollow', '0'),
(45, 23, 'seo_noarchive', '0'),
(46, 23, 'seo_keywords', ''),
(47, 23, 'seo_description', ''),
(48, 23, 'seo_customimage', ''),
(97, 18, 'page_content', 'W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPkFWSVNPIExFR0FMPC9iPjwvaDE+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcGItMyAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwPjxiPklORk9STUFDScOTTiBCw4FTSUNBIFNPQlJFIFBST1RFQ0NJw5NOIERFIERBVE9TPC9iPjxicj48YnI+PGI+UmVzcG9uc2FibGU6Jm5ic3A7PC9iPkFHVVNUw40gVE9SRUxMw5MsIFMuQS48YnI+PGI+RmluYWxpZGFkOiZuYnNwOzwvYj5MYSBhdGVuY2nDs24gZGUgc29saWNpdHVkZXMgZGUgZGl2ZXJzYSDDrW5kb2xlIHBvciBwYXJ0ZSBkZWwgVXN1YXJpbzxicj48Yj5MZWdpdGltYWNpw7NuOiZuYnNwOzwvYj5Db25zZW50aW1pZW50byBkZWwgaW50ZXJlc2Fkby48YnI+PGI+RGVzdGluYXRhcmlvczombmJzcDs8L2I+T3RyYXMgZW1wcmVzYXMgZGVsIGdydXBvLiBFbmNhcmdhZG9zIGRlIFRyYXRhbWllbnRvIGRlbnRybyBvIGZ1ZXJhIGRlIGxhIFVFPGJyPjxiPkRlcmVjaG9zOiZuYnNwOzwvYj5BY2NlZGVyLCByZWN0aWZpY2FyIHkgc3VwcmltaXIgbG9zIGRhdG9zLCBhc8OtIGNvbW8gb3Ryb3MgZGVyZWNob3MsIGNvbW8gc2UgZXhwbGljYSBlbiBsYSBpbmZvcm1hY2nDs24gYWRpY2lvbmFsPGJyPjxiPkluZm9ybWFjacOzbiBhZGljaW9uYWw6Jm5ic3A7PC9iPlB1ZWRlIGNvbnN1bHRhciBsYSBpbmZvcm1hY2nDs24gYWRpY2lvbmFsIHkgZGV0YWxsYWRhIHNvYnJlIFByb3RlY2Npw7NuIGRlIERhdG9zIGVuIG51ZXN0cmEgcMOhZ2luYSB3ZWI6IDxhIGhyZWY9JiMzOTtodHRwOi8vd3d3LmFndXN0aXRvcmVsbG9tYXRhLmNvbSYjMzk7Pnd3dy5hZ3VzdGl0b3JlbGxvbWF0YS5jb208L2E+PGJyPjwvcD4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PkluZm9ybWFjacOzbiBhZGljaW9uYWw8L3A+PHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PkxhcyBwcmVzZW50ZSBQb2zDrXRpY2EgZGUgUHJvdGVjY2nDs24gZGUgZGF0b3MgcmVndWxhIGVsIHRyYXRhbWllbnRvIGRlIGRhdG9zIHBlcnNvbmFsZXMgZmFjaWxpdGFkb3MgcG9yIGVsIFVzdWFyaW8gYSB0cmF2w6lzIGRlbCBwb3J0YWwgZGUgSW50ZXJuZXQgKGVuIGFkZWxhbnRlLCBlbCDigJxQb3J0YWzigJ0pIHF1ZSBBR1VTVMONIFRPUkVMTMOTLCBTLkEuIHBvbmUgYSBkaXNwb3NpY2nDs24gZGUgbG9zIHVzdWFyaW9zIGRlIEludGVybmV0LiBMYSBwcmVzZW50ZSBQb2zDrXRpY2EgZm9ybWEgcGFydGUgaW50ZWdyYW50ZSBkZWwgQXZpc28gTGVnYWwgYWNjZXNpYmxlIGVuIHRvZG8gbW9tZW50byBkZXNkZSBlbCBQb3J0YWwuPGJyPkVsIFVzdWFyaW8gZ2FyYW50aXphIHF1ZSBsb3MgZGF0b3MgYXBvcnRhZG9zIHNvbiB2ZXJkYWRlcm9zLCBleGFjdG9zLCBjb21wbGV0b3MgeSBhY3R1YWxpemFkb3MsIHNpZW5kbyByZXNwb25zYWJsZSBkZSBjdWFscXVpZXIgZGHDsW8gbyBwZXJqdWljaW8sIGRpcmVjdG8gbyBpbmRpcmVjdG8sIHF1ZSBwdWRpZXJhIG9jYXNpb25hcnNlIGNvbW8gY29uc2VjdWVuY2lhIGRlbCBpbmN1bXBsaW1pZW50byBkZSB0YWwgb2JsaWdhY2nDs24uIEVuIGVsIGNhc28gZGUgcXVlIGxvcyBkYXRvcyBhcG9ydGFkb3MgcGVydGVuZWNpZXJhbiBhIHVuIHRlcmNlcm8sIGVsIFVzdWFyaW8gZ2FyYW50aXphIHF1ZSBoYSBpbmZvcm1hZG8gYSBkaWNobyB0ZXJjZXJvIGRlIGxvcyBhc3BlY3RvcyBjb250ZW5pZG9zIGVuIGVzdGUgZG9jdW1lbnRvIHkgb2J0ZW5pZG8gc3UgYXV0b3JpemFjacOzbiBwYXJhIGZhY2lsaXRhciBzdXMgZGF0b3MgYSBBR1VTVMONIFRPUkVMTMOTLCBTLkEuIHBhcmEgbG9zIGZpbmVzIHNlw7FhbGFkb3MuPGJyPkVsIFBvcnRhbCBwdWVkZSBvZnJlY2VyIGZ1bmNpb25hbGlkYWRlcyBwYXJhIGNvbXBhcnRpciBjb250ZW5pZG9zIGEgdHJhdsOpcyBkZSBhcGxpY2FjaW9uZXMgZGUgdGVyY2Vyb3MsIGNvbW8gRmFjZWJvb2sgbyBUd2l0dGVyLiBFc3RhcyBhcGxpY2FjaW9uZXMgcHVlZGVuIHJlY29nZXIgeSB0cmF0YXIgaW5mb3JtYWNpw7NuIHJlbGFjaW9uYWRhIGNvbiBsYSBuYXZlZ2FjacOzbiBkZWwgdXN1YXJpbyBlbiBsb3MgZGlmZXJlbnRlcyBzaXRpb3Mgd2Vicy4gQ3VhbHF1aWVyIGluZm9ybWFjacOzbiBwZXJzb25hbCBxdWUgc2UgcmVjYWJhZGEgYSB0cmF2w6lzIGRlIGVzdGFzIGFwbGljYWNpb25lcywgcHVlZGUgc2VyIHV0aWxpemFkYSBwb3IgdGVyY2Vyb3MgdXN1YXJpb3MgZGUgbGFzIG1pc21hcywgeSBzdXMgaW50ZXJhY2Npb25lcyBlc3TDoW4gc29tZXRpZGFzIGEgbGFzIHBvbMOtdGljYXMgZGUgcHJpdmFjaWRhZCBkZSBsYXMgY29tcGHDscOtYXMgcXVlIGZhY2lsaXRhbiBsYXMgYXBsaWNhY2lvbmVzLjxicj5FbCBQb3J0YWwgcHVlZGUgYWxvamFyIGJsb2dzLCBmb3JvcywgeSBvdHJhcyBhcGxpY2FjaW9uZXMgbyBzZXJ2aWNpb3MgZGUgcmVkZXMgc29jaWFsZXMgY29uIGxhIGZpbmFsaWRhZCBkZSBmYWNpbGl0YXIgZWwgaW50ZXJjYW1iaW8gZGUgY29ub2NpbWllbnRvIHkgY29udGVuaWRvLiBDdWFscXVpZXIgaW5mb3JtYWNpw7NuIHBlcnNvbmFsIHF1ZSBzZSBmYWNpbGl0ZSBwb3IgZWwgdXN1YXJpbyBwdWVkZSBzZXIgY29tcGFydGlkYSBjb24gb3Ryb3MgdXN1YXJpb3MgZGUgZXNlIHNlcnZpY2lvLCBzb2JyZSBsb3MgY3VhbGVzIEFHVVNUw40gVE9SRUxMw5MsIFMuQS5ubyB0aWVuZSBjb250cm9sIGFsZ3Vuby48YnI+Q29uIG9iamV0byBkZSBvZnJlY2VyIGluZm9ybWFjacOzbiBvIHNlcnZpY2lvcyBkZSBpbnRlcsOpcyBlbiBmdW5jacOzbiBkZSBsYSBsb2NhbGl6YWNpw7NuIGRlbCBVc3VhcmlvLCBBR1VTVMONIFRPUkVMTMOTLCBTLkEuIHBvZHLDoSBhY2NlZGVyIGEgZGF0b3MgcmVsYXRpdm9zIGEgbGEgZ2VvbG9jYWxpemFjacOzbiBkZWwgZGlzcG9zaXRpdm8gZGVsIFVzdWFyaW8sIGVuIGFxdWVsbG9zIGNhc29zIGVuIHF1ZSBsYSBjb25maWd1cmFjacOzbiBkZWwgdXN1YXJpbyBhbCBlZmVjdG8gYXPDrSBsbyBwZXJtaXRhLjxicj5BIGVmZWN0b3MgZGUgc2VndXJpZGFkIHTDqWNuaWNhIHkgZGlhZ27Ds3N0aWNvIGRlIHNpc3RlbWFzLCBkZSBmb3JtYSBhbm9uaW1pemFkYSBvIGFncmVnYWRhLCBBR1VTVMONIFRPUkVMTMOTLCBTLkEuIHBvZHLDoSByZWdpc3RyYXIgbGEgZGlyZWNjacOzbiBJUCAobsO6bWVybyBkZSBpZGVudGlmaWNhY2nDs24gZGVsIGFjY2VzbyBhIEludGVybmV0IGRlbCBkaXNwb3NpdGl2bywgcXVlIHBlcm1pdGUgYSBsb3MgZGlzcG9zaXRpdm9zLCBzaXN0ZW1hcyB5IHNlcnZpZG9yZXMgcmVjb25vY2Vyc2UgeSBjb211bmljYXJzZSBlbnRyZSBzw60pLiBEaWNoYSBpbmZvcm1hY2nDs24gcG9kcsOhIHNlciB0YW1iacOpbiBlbXBsZWFkYSBjb24gZmluYWxpZGFkZXMgYW5hbMOtdGljYXMgZGUgcmVuZGltaWVudG8gd2ViLjwvcD48cCBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+PGJyPjEuICDCv1F1acOpbiBlcyBlbCByZXNwb25zYWJsZSBkZWwgdHJhdGFtaWVudG8gZGUgbG9zIGRhdG9zIHBlcnNvbmFsZXMgZGVsIFVzdWFyaW8/PC9wPjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz5JZGVudGlkYWQ6IEFHVVNUw40gVE9SRUxMw5MsIFMuQS4gZXMgdW5hIHNvY2llZGFkIGVzcGHDsW9sYSBpbnNjcml0YSBlbiBlbCBSZWdpc3RybyBNZXJjYW50aWwgZGUgQmFyY2Vsb25hIGNvbiBDSUYgbsO6bWVybyBBLTU4NDA5MDUzPGJyPkRpcmVjY2nDs24gcG9zdGFsOiBDLyBMYSBTZXJyYSwgcy9uIDA4NzcwU2FudCBTYWR1cm7DrSBk4oCZQW5vaWE8YnI+VGVsw6lmb25vOiA5MzggOTEgMTEgNzM8YnI+Q29ycmVvIGVsZWN0csOzbmljbzogaW5mb0BhZ3VzdGl0b3JlbGxvbWF0YS5jb208YnI+PGJyPjIuICDCv0NvbiBxdcOpIGZpbmFsaWRhZCB0cmF0YW1vcyBsb3MgZGF0b3MgcGVyc29uYWxlcyBkZWwgVXN1YXJpbz88YnI+IDxicj5BR1VTVMONIFRPUkVMTMOTLCBTLkEuIHRyYXRhIGxhIGluZm9ybWFjacOzbiBmYWNpbGl0YWRhIHBvciBlbCBVc3VhcmlvIGNvbiBlbCBmaW4gZGUgYXRlbmRlciBsYXMgc29saWNpdHVkZXMgZGUgZGl2ZXJzYSDDrW5kb2xlIGxsZXZhZGFzIGEgY2FibyBwb3IgcGFydGUgZGUgZXN0ZS4gRW4gZnVuY2nDs24gZGUgbGEgbmF0dXJhbGV6YSBkZSBsYSBzb2xpY2l0dWQsIGxhIGZpbmFsaWRhZCBwZXJzZWd1aXLDoSBsYSBnZXN0acOzbiBkZTo8YnI+PGJyPmEuICBDb25zdWx0YXMgeSBzb2xpY2l0dWRlcyBkZSBwcm9wdWVzdGFzLCAoUkZQKSByZW1pdGlkYXMgYSB0cmF2w6lzIGRlbCBmb3JtdWxhcmlvIGRlIGNvbnRhY3RvIGhhYmlsaXRhZG8gYWwgZWZlY3RvLiA8YnI+Yi4gIEN1cnJpY3VsdW1zIHJlbWl0aWRvcyBhIHRyYXbDqXMgZGVsIFBvcnRhbC48YnI+Yy4gIExhIHBhcnRpY2lwYWNpw7NuIGVuIGJsb2dzLCBtZWRpYW50ZSBjb21lbnRhcmlvcy48YnI+ZC4gIExhcyBjb211bmljYWNpb25lcyBhIHRyYXbDqXMgZGUgZW5jdWVzdGFzLjxicj5lLiAgQ29tdW5pY2FjaW9uZXMgZWxlY3Ryw7NuaWNhcyBkZSBuYXR1cmFsZXphIGluZm9ybWF0aXZhLCBkZSBhY3VlcmRvIGNvbiBzdXMgaW50ZXJlc2VzLiA8YnI+PGJyPjwvcD48cCBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+QUdVU1TDjSBUT1JFTEzDkywgUy5BLiBwb2Ryw6EgZWxhYm9yYXIgdW4gcGVyZmlsIGNvbWVyY2lhbCwgY29uIGJhc2UgZW4gbGEgaW5mb3JtYWNpw7NuIGZhY2lsaXRhZGEuIE5vIHNlIHRvbWFyw6FuIGRlY2lzaW9uZXMgYXV0b21hdGl6YWRhcyBjb24gYmFzZSBlbiBkaWNobyBwZXJmaWwuPGJyPkVuIGVsIHN1cHVlc3RvIGRlIHF1ZSBlbCBVc3VhcmlvIHNlIHJlZ2lzdHJlIGVuIGVsIFBvcnRhbCBhIHRyYXbDqXMgZGVsIGxvZ2luIHNvY2lhbCwgQUdVU1TDjSBUT1JFTEzDkywgUy5BLiDDum5pY2FtZW50ZSBhY2NlZGVyw6EgYSBsb3MgZGF0b3MgcGVyc29uYWxlcyBkZWwgVXN1YXJpbyBwYXJhIGxvcyBxdWUgaGF5YSBwcmVzdGFkbyBzdSBjb25zZW50aW1pZW50byBkdXJhbnRlIGxhIGNvbmZpZ3VyYWNpw7NuIGRlbCBhY2Nlc28gZGUgbGEgcmVkIHNvY2lhbCBkZSBxdWUgc2UgdHJhdGUuIEN1YWxxdWllciBpbmZvcm1hY2nDs24gZmFjaWxpdGFkYSBlbiBjb25leGnDs24gY29uIGRpY2hhcyBhcGxpY2FjaW9uZXMgc29jaWFsZXMgcG9kcsOtYSBzZXIgYWNjZWRpZGEgcG9yIG1pZW1icm9zIGRlIGxhIGNvcnJlc3BvbmRpZW50ZSByZWQgc29jaWFsLCBkaWNoYXMgaW50ZXJhY2Npb25lcyBzZSByZWdpcsOhbiBwb3IgbGFzIHBvbMOtdGljYXMgZGUgcHJpdmFjaWRhZCBkZSBsYXMgZW50aWRhZGVzIHByZXN0YWRvcmFzIGRlIGxvcyBzZXJ2aWNpb3MuIEFHVVNUw40gVE9SRUxMw5MsIFMuQS4gbm8gZGlzcG9uZSBkZSBuaW5nw7puIGNvbnRyb2wgbmkgcmVzcG9uc2FiaWxpZGFkIHJlc3BlY3RvIGRlIGRpY2hhcyBlbnRpZGFkZXMgbyBkZWwgdXNvIHF1ZSByZWFsaWNlbiBkZSBsYSBpbmZvcm1hY2nDs24gZGVsIHVzdWFyaW8uPGJyPjxicj48L3A+PHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PjIuMS4gSW5mb3JtYWNpw7NuIGFjZXJjYSBkZWwgdHJhdGFtaWVudG8gZGUgZGF0b3MgcGFyYSBlbnbDrW8gZGUgY29tdW5pY2FjaW9uZXMgZGVzZGUgQUdVU1TDjSBUT1JFTEzDkywgUy5BLjxicj48YnI+TG9zIGRhdG9zIGVtcGxlYWRvcywgbyBmYWNpbGl0YWRvcywgZW4gbGFzIGNvbXVuaWNhY2lvbmVzIGluZm9ybWF0aXZhcyB5L28gcHJvbW9jaW9uYWxlcyBzb24gdHJhdGFkb3MgcG9yIEFHVVNUw40gVE9SRUxMw5MsIFMuQS4gcGFyYSBmaW5hbGlkYWRlcyBjb25zaXN0ZW50ZXMgZW4gZWwgZW52w61vIGVsZWN0csOzbmljbyBkZSBpbmZvcm1hY2nDs24geSBjb211bmljYWNpb25lcyBzb2JyZSBzZXJ2aWNpb3MsIGFjdGl2aWRhZGVzLCBwdWJsaWNhY2lvbmVzIHkgYWNvbnRlY2ltaWVudG9zIHkgcHJvZmVzaW9uYWxlcyBkZSBBR1VTVMONIFRPUkVMTMOTLCBTLkEuIG8gZGVsICBzZWd1aW1pZW50byB5IG9wdGltaXphY2nDs24gZGUgbGFzIGNhbXBhw7FhcyBkZSBtYXJrZXRpbmcgcmVhbGl6YWRhcyBtZWRpYW50ZSB0ZWNub2xvZ8OtYXMgYWwgZWZlY3RvOyB5IGxhIGVsYWJvcmFjacOzbiBkZSBwZXJmaWxlcyBjb24gZmluYWxpZGFkZXMgY29tZXJjaWFsZXMuPGJyPkVsIGNvbnNlbnRpbWllbnRvIHBhcmEgZWwgZW52w61vIGRlIGRpY2hhcyBjb211bmljYWNpb25lcyBwb2Ryw6Egc2VyIHJldm9jYWRvIGVuIHRvZG8gbW9tZW50byBlbiBjYWRhIHVuYSBkZSBsYXMgY29tdW5pY2FjaW9uZXMgcmVjaWJpZGFzIG1lZGlhbnRlIGVsIG1lY2FuaXNtbyBoYWJpbGl0YWRvIGFsIGVmZWN0by48YnI+RWwgY3JpdGVyaW8gZGUgY29uc2VydmFjacOzbiBkZSBsb3MgZGF0b3MgdGVuZHLDoSBiYXNlIGVuIGxhIG1hbmlmZXN0YWNpw7NuIGNvbnRyYXJpYSBhbCB0cmF0YW1pZW50byBwb3Igc3UgcGFydGUuIEVuIHRvZG8gY2FzbywgUG9kcsOhIGVqZXJjZXIgbG9zIGRlcmVjaG9zIGRlIGFjY2VzbywgcmVjdGlmaWNhY2nDs24sIGxpbWl0YWNpw7NuLCBzdXByZXNpw7NuLCBwb3J0YWJpbGlkYWQgeSBvcG9zaWNpw7NuLCBkaXJpZ2llbmRvIHN1IHBldGljacOzbiBhIGxhIGRpcmVjY2nDs24gcG9zdGFsIGluZGljYWRhIG3DoXMgYXJyaWJhIG8gYmllbiBhIHRyYXbDqXMgZGUgY29ycmVvIGVsZWN0csOzbmljb2luZm9AYWd1c3RpdG9yZWxsb21hdGEuY29tLjxicj48L3A+PHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PjMuICDCv1BvciBjdcOhbnRvIHRpZW1wbyBjb25zZXJ2YXJlbW9zIGxvcyBkYXRvcyBwZXJzb25hbGVzIGRlbCBVc3VhcmlvPzxicj48YnI+Q29uIGNhcsOhY3RlciBnZW5lcmFsLCBsb3MgZGF0b3MgcGVyc29uYWxlcyBwcm9wb3JjaW9uYWRvcyBzZSBjb25zZXJ2YXLDoW4gZHVyYW50ZSBlbCB0aWVtcG8gbmVjZXNhcmlvIHBhcmEgYXRlbmRlciBsYSBzb2xpY2l0dWQgZGVsIFVzdWFyaW8gbyBtaWVudHJhcyBubyBzZSBzb2xpY2l0ZSBzdSBzdXByZXNpw7NuIHBvciBlbCBVc3VhcmlvLiBFbiBlbCBjYXNvIGNvbmNyZXRvIGRlIGN1cnLDrWN1bHVtIGxvcyBkYXRvcyBzZXLDoW4gY29uc2VydmFkb3MgcG9yIHVuIHBlcmlvZG8gbcOheGltbyBkZSB0cmVzIGHDsW9zLCBzYWx2byBpbmRpY2FjacOzbiBlbiBjb250cmFyaW8gcG9yIHBhcnRlIGRlbCBpbnRlcmVzYWRvLjxicj48YnI+NC4gIMK/Q3XDoWwgZXMgbGEgbGVnaXRpbWFjacOzbiBwYXJhIGVsIHRyYXRhbWllbnRvIGRlIGxvcyBkYXRvcyBwZXJzb25hbGVzIGRlbCBVc3VhcmlvPzxicj48YnI+TGEgYmFzZSBsZWdhbCBwYXJhIGVsIHRyYXRhbWllbnRvIGRlIGxvcyBkYXRvcyBlcyBsYSBsZWdpdGltYWNpw7NuIHBvciBjb25zZW50aW1pZW50byBkZWwgVXN1YXJpby48YnI+PGJyPjUuICDCv0EgcXXDqSBkZXN0aW5hdGFyaW9zIHNlIGNvbXVuaWNhcsOhbiBsb3MgZGF0b3MgcGVyc29uYWxlcyBkZWwgVXN1YXJpbz88YnI+PGJyPkVuIGFxdWVsbG9zIGNhc29zIGVuIHF1ZSBlbCBVc3VhcmlvIHNvbGljaXRlLCBhIHRyYXbDqXMgZGUgbGEgd2ViLCBwcm9wdWVzdGFzIGRlIHNlcnZpY2lvcyBvIHNlIHJlbWl0YW4gY3VycmljdWx1bXMsIHN1cyBkYXRvcyBzZXLDoW4gZmFjaWxpdGFkb3MgYSBhcXVlbGxhcyBlbXByZXNhcyBlc3Bhw7FvbGFzIGFmaWxpYWRhcyBhIGxhIHJlZCBBR1VTVMONIFRPUkVMTMOTLCBTLkEuLjxicj5FbiBhcXVlbGxvcyBjYXNvcyBlbiBxdWUgbGEgc29saWNpdHVkIGRlbCBVc3VhcmlvIGFzw60gbG8ganVzdGlmaXF1ZSBsb3MgZGF0b3MgaWRlbnRpZmljYXRpdm9zIHBvZHLDoW4gZmFjaWxpdGFyc2UgYSBvdHJhcyBlbnRpZGFkZXMgYWZpbGlhZGFzIGEgbGEgcmVkIEFHVVNUw40gVE9SRUxMw5MsIFMuQS4sIGluY2x1aWRhcyBhcXVlbGxhcyB1YmljYWRhcyBmdWVyYSBkZWwgRXNwYWNpbyBFY29uw7NtaWNvIEV1cm9wZW8sIGEgbG9zIG1lcm9zIGVmZWN0b3MgZGUgYXRlbmRlciBsYSBzb2xpY2l0dWQgdmluY3VsYWRhIGFsIHBhw61zIGRlIGRlc3Rpbm8uPGJyPkFzw60gbWlzbW8sIGxvcyBkYXRvcyBwb2Ryw6FuIHNlciBjZWRpZG9zIGEgYWRtaW5pc3RyYWNpb25lcyB5IG9yZ2FuaXNtb3MgcMO6YmxpY29zIHBhcmEgZWwgY3VtcGxpbWllbnRvIGRlIG9ibGlnYWNpb25lcyBkaXJlY3RhbWVudGUgZXhpZ2libGVzIGEgQUdVU1TDjSBUT1JFTEzDkywgUy5BLi48YnI+PGJyPjYuICDCv0N1w6FsZXMgc29uIGxvcyBkZXJlY2hvcyBkZWwgVXN1YXJpbyBjdWFuZG8gbm9zIGZhY2lsaXRhIHN1cyBkYXRvcyBwZXJzb25hbGVzPzxicj48YnI+RWwgVXN1YXJpbyB0aWVuZSBkZXJlY2hvIGEgb2J0ZW5lciBjb25maXJtYWNpw7NuIHNvYnJlIHNpIEFHVVNUw40gVE9SRUxMw5MsIFMuQS4gdHJhdGEgZGF0b3MgcGVyc29uYWxlcyBxdWUgbGUgY29uY2llcm5lbiwgYXPDrSBjb21vIGEgYWNjZWRlciBhIHN1cyBkYXRvcyBwZXJzb25hbGVzLCBzb2xpY2l0YXIgbGEgcmVjdGlmaWNhY2nDs24gZGUgbG9zIGRhdG9zIGluZXhhY3RvcyBvLCBlbiBzdSBjYXNvLCBzb2xpY2l0YXIgc3Ugc3VwcmVzacOzbiBjdWFuZG8sIGVudHJlIG90cm9zIG1vdGl2b3MsIGxvcyBkYXRvcyB5YSBubyBzZWFuIG5lY2VzYXJpb3MgcGFyYSBsb3MgZmluZXMgcXVlIGZ1ZXJvbiByZWNvZ2lkb3MuPGJyPkVuIGRldGVybWluYWRhcyBjaXJjdW5zdGFuY2lhcywgZWwgVXN1YXJpbyBwb2Ryw6Egc29saWNpdGFyIGxhIGxpbWl0YWNpw7NuIGRlbCB0cmF0YW1pZW50byBkZSBzdXMgZGF0b3MsIGVuIGN1eW8gY2FzbyDDum5pY2FtZW50ZSBzZSBjb25zZXJ2YXLDoW4gcGFyYSBlbCBlamVyY2ljaW8gbyBsYSBkZWZlbnNhIGRlIHJlY2xhbWFjaW9uZXMuPGJyPkVuIGRldGVybWluYWRhcyBjaXJjdW5zdGFuY2lhcyB5IHBvciBtb3Rpdm9zIHJlbGFjaW9uYWRvcyBjb24gc3Ugc2l0dWFjacOzbiBwYXJ0aWN1bGFyLCBlbCBVc3VhcmlvIHBvZHLDoSBvcG9uZXJzZSBhbCB0cmF0YW1pZW50byBkZSBzdXMgZGF0b3MuIEFHVVNUw40gVE9SRUxMw5MsIFMuQS4gY2VzYXLDoSBlbiBlbCB0cmF0YW1pZW50byBkZSBsb3MgZGF0b3MsIHNhbHZvIHBvciBtb3Rpdm9zIGxlZ8OtdGltb3MgaW1wZXJpb3NvcywgbyBlbCBlamVyY2ljaW8gbyBsYSBkZWZlbnNhIGRlIHBvc2libGVzIHJlY2xhbWFjaW9uZXMuPGJyPkVsIFVzdWFyaW8gcG9kcsOhIHBsYW50ZWFyIGxhcyBjdWVzdGlvbmVzIHF1ZSBjb25zaWRlcmUgZW4gcmVsYWNpw7NuIGEgbGEgcHJlc2VudGUgUG9sw610aWNhIGFzw60gY29tbyBlamVyY2VyIHN1cyBkZXJlY2hvcyBlbiBsb3MgdMOpcm1pbm9zIGxlZ2FsbWVudGUgcHJldmlzdG9zIGRlYmllbmRvIHBhcmEgZWxsbyBkaXJpZ2lyIHVuYSBjb211bmljYWNpw7NuIG1lZGlhbnRlIGNvcnJlbyBwb3N0YWwgYTogQUdVU1TDjSBUT1JFTEzDkywgUy5BLiwgQy8gTGEgU2VycmEsIHMvbiwgQ1A6IDA4NzcwLCBTYW50IFNhZHVybsOtIGTigJlBbm9pYSwgbyBjb3JyZW8gZWxlY3Ryw7NuaWNvIGE6IGluZm9AYWd1c3RpdG9yZWxsb21hdGEuY29tIGNvbiBpbmRpY2FjacOzbiBkZSBsYSBzb2xpY2l0dWQgY29ycmVzcG9uZGllbnRlIHkgYWNvbXBhw7FhZG8gZGUgY29waWEgZGVsIEROSSBvIGRvY3VtZW50byBhY3JlZGl0YXRpdm8gZGUgbGEgaWRlbnRpZGFkLjxicj48YnI+PGJyPiA8L3A+PHAgY2xhc3M9JiMzOTtwMSB0eHRAaiYjMzk7Pjxicj48L3A+PHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PjwvcD4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwPjxiPkNPTkRJQ0lPTkVTIERFIFZFTlRBPC9iPjwvcD48cD5Fc3RlIGNvbWVyY2lhbnRlIHNlIGNvbXByb21ldGUgYSBubyBwZXJtaXRpciBuaW5ndW5hIHRyYW5zYWNjacOzbiBxdWUgc2VhIGlsZWdhbCwgbyBzZSBjb25zaWRlcmUgcG9yIGxhcyBtYXJjYXMgZGUgdGFyamV0YXMgZGUgY3LDqWRpdG8gbyBlbCBiYW5jbyBhZHF1aXJpZW50ZSwgcXVlIHB1ZWRhIG8gdGVuZ2EgZWwgcG90ZW5jaWFsIGRlIGRhw7FhciBsYSBidWVuYSB2b2x1bnRhZCBkZSBsb3MgbWlzbW9zIG8gaW5mbHVpciBkZSBtYW5lcmEgbmVnYXRpdmEgZW4gZWxsb3MuIExhcyBzaWd1aWVudGVzIGFjdGl2aWRhZGVzIGVzdMOhbiBwcm9oaWJpZGFzIGVuIHZpcnR1ZCBkZSBsb3MgcHJvZ3JhbWFzIGRlIGxhcyBtYXJjYXMgZGUgdGFyamV0YXM6IGxhIHZlbnRhIHUgb2ZlcnRhIGRlIHVuIHByb2R1Y3RvIG8gc2VydmljaW8gcXVlIG5vIHNlYSBkZSBwbGVuYSBjb25mb3JtaWRhZCBjb24gdG9kYXMgbGFzIGxleWVzIGFwbGljYWJsZXMgYWwgQ29tcHJhZG9yLCBCYW5jbyBFbWlzb3IsIENvbWVyY2lhbnRlLCBUaXR1bGFyIGRlIGxhIHRhcmpldGEsIG8gdGFyamV0YXMuJm5ic3A7PC9wPjxwPkFkZW3DoXMsIGxhcyBzaWd1aWVudGVzIGFjdGl2aWRhZGVzIHRhbWJpw6luIGVzdMOhbiBwcm9oaWJpZGFzIGV4cGzDrWNpdGFtZW50ZTogJiMzOTs8Yj5WZW50YSBkZSBiZWJpZGFzIGFsY29ow7NsaWNhcyBhIG1lbm9yZXMgZGUgMTggYcOxb3M8L2I+JiMzOTs8L3A+In19LHsidHlwZSI6InctMS0xIHBiLTYiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fV0='),
(98, 18, 'seo_resumen', ''),
(99, 18, 'seo_checktitleonfreaturedimage', '0'),
(100, 18, 'seo_customtitleonfreaturedimage', ''),
(101, 18, 'seo_freaturedimage', ''),
(102, 18, 'seo_noodp', '0'),
(103, 18, 'seo_noydir', '0'),
(104, 18, 'seo_nofollow', '0'),
(105, 18, 'seo_noarchive', '0'),
(106, 18, 'seo_keywords', ''),
(107, 18, 'seo_description', ''),
(108, 18, 'seo_customimage', ''),
(109, 19, 'page_content', 'W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPlBPTMONVElDQSBERSBDT09LSUVTPC9iPjwvaDE+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcGItMyAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz5OdWVzdHJvIHNpdGlvIHdlYiA8YSBocmVmPSYjMzk7aHR0cDovL3d3dy5hZ3VzdGl0b3JlbGxvbWF0YS5jb20mIzM5Oz53d3cuYWd1c3RpdG9yZWxsb21hdGEuY29tPC9hPiB1dGlsaXphIHVuYSB0ZWNub2xvZ8OtYSBkZW5vbWluYWRhIOKAnGNvb2tpZXPigJ0gY29uIGxhIGZpbmFsaWRhZCBkZSBwb2RlciByZWNhYmFyIGluZm9ybWFjacOzbiBhY2VyY2EgZGVsIHVzbyBkZWwgU2l0aW8gV2ViLiBTaSBxdWllcmUgY29udGFjdGFyIGNvbiBub3NvdHJvcyBlc2Nyw61iYW5vcyBhbCBpbmZvQGFndXN0aXRvcmVsbG9tYXRhLmNvbTwvcD48cCBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+TGUgaW5mb3JtYW1vcyBkZSBxdWUgcG9kZW1vcyB1dGlsaXphciBjb29raWVzIGNvbiBsYSBmaW5hbGlkYWQgZGUgZmFjaWxpdGFyIHN1IG5hdmVnYWNpw7NuIGEgdHJhdsOpcyBkZWwgU2l0aW8gV2ViLCBkaXN0aW5ndWlybGUgZGUgb3Ryb3MgdXN1YXJpb3MsIHByb3BvcmNpb25hcmxlIHVuYSBtZWpvciBleHBlcmllbmNpYSBlbiBlbCB1c28gZGVsIG1pc21vLCBlIGlkZW50aWZpY2FyIHByb2JsZW1hcyBwYXJhIG1lam9yYXIgbnVlc3RybyBTaXRpbyBXZWIuIEFzaW1pc21vLCBlbiBjYXNvIGRlIHF1ZSBwcmVzdGUgc3UgY29uc2VudGltaWVudG8sIHV0aWxpemFyZW1vcyBjb29raWVzIHF1ZSBub3MgcGVybWl0YW4gb2J0ZW5lciBtw6FzIGluZm9ybWFjacOzbiBhY2VyY2EgZGUgc3VzIHByZWZlcmVuY2lhcyB5IHBlcnNvbmFsaXphciBudWVzdHJvIFNpdGlvIFdlYiBkZSBjb25mb3JtaWRhZCBjb24gc3VzIGludGVyZXNlcyBpbmRpdmlkdWFsZXMuPGJyPkxhIHByZXNlbnRlIHBvbMOtdGljYSBkZSBjb29raWVzIHRpZW5lIHBvciBmaW5hbGlkYWQgaW5mb3JtYXJsZSBkZSBtYW5lcmEgY2xhcmEgeSBwcmVjaXNhIHNvYnJlIGxhcyBjb29raWVzIHF1ZSBzZSB1dGlsaXphbiBlbiBudWVzdHJvIFNpdGlvIFdlYiAobGEg4oCcUG9sw610aWNhIGRlIENvb2tpZXPigJ0pLjxicj5VbmEgY29va2llIGVzIHVuIGFyY2hpdm8gcXVlIHNlIGRlc2NhcmdhIGVuIHN1IGVxdWlwbyAob3JkZW5hZG9yIG8gZGlzcG9zaXRpdm8gbcOzdmlsKSBjb24gbGEgZmluYWxpZGFkIGRlIGFsbWFjZW5hciBkYXRvcyBxdWUgcG9kcsOhbiBzZXIgYWN0dWFsaXphZG9zIHkgcmVjdXBlcmFkb3MgcG9yIGxhIGVudGlkYWQgcmVzcG9uc2FibGUgZGUgc3UgaW5zdGFsYWNpw7NuLjwvcD48cCBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+TGEgaW5mb3JtYWNpw7NuIHJlY2FiYWRhIGEgdHJhdsOpcyBkZSBsYXMgY29va2llcyBwdWVkZSBpbmNsdWlyIGxhIGZlY2hhIHkgaG9yYSBkZSB2aXNpdGFzIGFsIFNpdGlvIFdlYiwgbGFzIHDDoWdpbmFzIHZpc2lvbmFkYXMsIGVsIHRpZW1wbyBxdWUgaGEgZXN0YWRvIGVuIG51ZXN0cm8gU2l0aW8gV2ViIHkgbG9zIHNpdGlvcyB2aXNpdGFkb3MganVzdG8gYW50ZXMgeSBkZXNwdcOpcyBkZWwgbWlzbW8uPC9wPjxicj4gPHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7Pk51ZXN0cm8gU2l0aW8gV2ViIHV0aWxpemEgbGFzIGNvb2tpZXMgcXVlIHNlIGRlc2NyaWJlbiBhIGNvbnRpbnVhY2nDs246PC9wPi0gIFvil49dIEdvb2dsZSBBbmFseXRpY3M8YnI+PHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PkFsIG5hdmVnYXIgeSBjb250aW51YXIgZW4gbnVlc3RybyBTaXRpbyBXZWIgZXN0YXLDoSBjb25zaW50aWVuZG8gZWwgdXNvIGRlIGxhcyBjb29raWVzIGFudGVzIGVudW5jaWFkYXMsIHBvciBsb3MgcGxhem9zIHNlw7FhbGFkb3MgeSBlbiBsYXMgY29uZGljaW9uZXMgY29udGVuaWRhcyBlbiBsYSBwcmVzZW50ZSBQb2zDrXRpY2EgZGUgQ29va2llcy48L3A+PHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PkVuIGN1YWxxdWllciBjYXNvLCBsZSBpbmZvcm1hbW9zIGRlIHF1ZSBkYWRvIHF1ZSBsYXMgY29va2llcyBubyBzb24gbmVjZXNhcmlhcyBwYXJhIGVsIHVzbyBkZSBudWVzdHJvIFNpdGlvIFdlYiwgcHVlZGUgYmxvcXVlYXJsYXMgbyBkZXNoYWJpbGl0YXJsYXMgYWN0aXZhbmRvIGxhIGNvbmZpZ3VyYWNpw7NuIGRlIHN1IG5hdmVnYWRvciBxdWUgbGUgcGVybWl0ZSByZWNoYXphciBsYSBpbnN0YWxhY2nDs24gZGUgdG9kYXMgbGFzIGNvb2tpZXMgbyBkZSBhbGd1bmFzIGRlIGVsbGFzLjxicj5TaSBxdWlzaWVzZSByZXRpcmFyIGVuIGN1YWxxdWllciBtb21lbnRvIHN1IGNvbnNlbnRpbWllbnRvIHJlbGFjaW9uYWRvIGNvbiBsYSBwcmVzZW50ZSBQb2zDrXRpY2EgZGUgQ29va2llcywgZGViZXLDoSBlbGltaW5hciBsYXMgY29va2llcyBhbG1hY2VuYWRhcyBlbiBzdSBlcXVpcG8gKG9yZGVuYWRvciBvIGRpc3Bvc2l0aXZvIG3Ds3ZpbCkgYSB0cmF2w6lzIGRlIGxvcyBhanVzdGVzIHkgY29uZmlndXJhY2lvbmVzIGRlIHN1IG5hdmVnYWRvciBkZSBJbnRlcm5ldC48YnI+U2Fsdm8gcXVlIGhheWEgYWp1c3RhZG8gbGEgY29uZmlndXJhY2nDs24gZGUgc3UgbmF2ZWdhZG9yLCBudWVzdHJvIHNpc3RlbWEgY3JlYXLDoSBjb29raWVzIGVuIGN1YW50byB2aXNpdGUgbnVlc3RybyBTaXRpbyBXZWIuPGJyPkVzIHBvc2libGUgcXVlIGFjdHVhbGljZW1vcyBsYSBQb2zDrXRpY2EgZGUgQ29va2llcyBkZSBudWVzdHJvIFNpdGlvIFdlYiwgcG9yIGVsbG8gbGUgcmVjb21lbmRhbW9zIHJldmlzYXIgZXN0YSBwb2zDrXRpY2EgY2FkYSB2ZXogcXVlIGFjY2VkYSBhIG51ZXN0cm8gU2l0aW8gV2ViLjwvcD48YnI+In19LHsidHlwZSI6InctMS0xIHBiLTYiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fV0='),
(110, 19, 'seo_resumen', ''),
(111, 19, 'seo_checktitleonfreaturedimage', '0'),
(112, 19, 'seo_customtitleonfreaturedimage', ''),
(113, 19, 'seo_freaturedimage', ''),
(114, 19, 'seo_noodp', '0'),
(115, 19, 'seo_noydir', '0'),
(116, 19, 'seo_nofollow', '0'),
(117, 19, 'seo_noarchive', '0'),
(118, 19, 'seo_keywords', ''),
(119, 19, 'seo_description', ''),
(120, 19, 'seo_customimage', ''),
(121, 24, 'page_content', 'W3sidHlwZSI6InctMS0xIHB0LTQiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBwYi0zIHBiLTdAcyAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PGI+PGk+S1JJUFRBLCZuYnNwOzwvaT48L2I+PGk+QmVzdCBpbiBjbGFzczwvaT48L2gxPiJ9fSx7InR5cGUiOiJ3LTEtMSBobSBobCBoeGwgcGItNEBzICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50Lzg5ZGU5OGMxYWNkZTgxOGMyMDc3MjM2ZmMzM2NiNTY4LmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoidy0xLTEgaG0gaGwgaHhsIHB0LTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoid3MtMS0xIHBiLTdAcyAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IndpZHRoOiA1MyU7IiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGRpdiBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+MTk3OCBlcyBsYSBwcmltZXJhIGNvc2VjaGEgY29uIGxhIHF1ZSBBR1VTVEkgVE9SRUxMTyBNQVRBIHJlYWxpemEgc3Ugc3Vlw7FvOiBlbGFib3JhciB1biBjYXZhIGV4Y2VwY2lvbmFsLjxicj48YnI+Q29uIDIwIGHDsW9zIGRlIGV4cGVyaWVuY2lhIHByb2Zlc2lvbmFsLCBlbGFib3JhIGVuIHN1IGJvZGVnYSBwYXJ0aWN1bGFyIGRlIENhbiBSb3NzZWxsIGxhcyBwcmltZXJhcyBib3RlbGxhcyBLUklQVEEsIGNvbiB1biBjdXBhZ2UgcHJvY2VkZW50ZSBkZSB0cmVzIHBhcmNlbGFzIMO6bmljYXMgZGVsIFBlbmVkw6lzLjxicj48YnI+TWFjYWJlbywgWGFyZWzCt2xvIHkgUGFyZWxsYWRhIGluaWNpYW4gdW5hIGxhcmdhIGNyaWFuemEgY29uIHRhcMOzbiBkZSBjb3JjaG8gY29uc2lndWllbmRvIHVuIGJvdXF1ZXQgw7puaWNvIHF1ZSBsbyBjb25zb2xpZGEgY29tbyB1bm8gZGUgbG9zIGdyYW5kZXMgdmlub3MgZGVsIG11bmRvLjxicj48YnI+TGEgYm90ZWxsYSDDoW5mb3JhLCBpZGVhZGEgeSBwYXRlbnRhZGEsIGVzIHVuIGhvbWVuYWplIGEgbGEgQW50aWd1YSBSb21hLiBMYSBldGlxdWV0YSAtb2JyYSBkZWwgYXJ0aXN0YSBSYWZhZWwgQmFydG9sb3p6aS0gZXZvY2EgZWwgTWVkaXRlcnLDoW5lbyBkZSBDYWRhcXXDqXMsIGxhIHZpZCB5IGVsIG9saXZvOiB0cmlsb2dpYSBkZSBsb3MgY2zDoXNpY29zLjxicj48YnI+S1JJUFRBIGVzIGVsIGNhdmEgbcOhcyBnYWxhcmRvbmFkbyBzaW4gaW50ZXJydXBjacOzbiBkZXNkZSBzdSBwcmltZXJhIG1lZGFsbGEgZGUgb3JvIGVuIGxhIEFudGlndWEgQnJhdGlzbGF2YSwgMTk4NC4gQ2FkYSBhw7FhZGEsIGVzIHVuIHByZW1pbyBxdWUgcmVmdWVyemEgbGEgZXhjZWxlbmNpYS48L2Rpdj4ifX0seyJ0eXBlIjoiaHMgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiJ3aWR0aDogNDclOyBwYWRkaW5nLWxlZnQ6IDklOyIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC84OWRlOThjMWFjZGU4MThjMjA3NzIzNmZjMzNjYjU2OC5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0xIGhzIHBiLTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEgd3MtMS0xIGhtIGhsIGh4bCBwYi00QHMgcGwtbkBzIG1iLTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvNjRmNWIyYzg2NjZmZDFjN2QyYmMyYzQyZWE1NWY5M2EuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJ3LTEtMSBobSBobCBoeGwgcGItNCBtYi00ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6e319LHsidHlwZSI6InctMS0xIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTMgd3MtMS0xIHBiLTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+PGI+TUFDQUJFTy4gPGJyPjxzcGFuIHN0eWxlPSYjMzk7Y29sb3I6IHJnYigxODUsIDE0NiwgMjUpOyYjMzk7PlZpw7FhIFZpY2FyaS4gU2FudCBQYXUgZOKAmU9yZGFsLjwvc3Bhbj48L2I+PC9wPjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5OyBzdHlsZT0mIzM5O3RleHQtYWxpZ246IGp1c3RpZnk7JiMzOTs+UGxhbnRhZGEgZW4gdmFzbyBlbiAxOTYyIGEgMjM5IG1ldHJvcyBkZSBhbHRpdHVkIGVuIHVuIHRlcnJlbm8gZGUgZ3JhYmFzIGNvbiBtdWNobyBkcmVuYWplLiBDb24gdW5hIHByb2R1Y2Npw7NuIG1lZGlhIGRlIDYwMDAga2cvaGEsIGRlIHBpZWwgZmluYSB5IGFwYXJpZW5jaWEgYXBpw7FhZGEsIGVzIGxhIHZhcmllZGFkIG3DoXMgZGVsaWNhZGEgZGUgbGFzIDMsIHkgbGEgYmFzZSBwcmluY2lwYWwgZGVsIEtyaXB0YS4gQXBvcnRhIGZpbnVyYSwgZWxlZ2FuY2lhIHkgbm90YXMgZGUgZnJ1dGEgYmxhbmNhLjxicj48L3A+In19LHsidHlwZSI6InctMS0zIHdzLTEtMSBwYi00ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PjxiPlhBUkVMwrdMTy4gPGJyPjxzcGFuIHN0eWxlPSYjMzk7Y29sb3I6IHJnYigxODUsIDE0NiwgMjUpOyYjMzk7PlZpw7FhIE1lcmNhZGVyLiBTYW50IFNhZHVybsOtIGTigJlBbm9pYS48L3NwYW4+PC9iPjwvcD48cCBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+UGxhbnRhZGEgZW4gMTk3NCwgZW1wYWx0YWRhIHBhcmEgY29uc2VndWlyIG3DoXMgZXhwb3NpY2nDs24gZm9saWFyIGEgMTYyIG1ldHJvcyBkZWwgbml2ZWwgZGVsIG1hciBlbiB1biBzdWVsbyBkZSBhcmNpbGxhcyB5IGNhbGPDoXJlby4gRGUgZ3Jhbm8gc3VlbHRvIHkgcGllbCBncnVlc2EsIGVzIGxhIHZhcmllZGFkIG3DoXMgcsO6c3RpY2EgeSBmdWVydGUuIEFwb3J0YSBwb2RlciBhbGNvaMOzbGljbywgY3VlcnBvIHkgZXN0cnVjdHVyYS48L3A+In19LHsidHlwZSI6InctMS0zIHdzLTEtMSBwYi00ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PjxiPlBBUkVMTEFEQS4gPGJyPjxzcGFuIHN0eWxlPSYjMzk7Y29sb3I6IHJnYigxODUsIDE0NiwgMjUpOyYjMzk7PlZpw7FhIExvbGEuIFNhbnQgSm9hbiBkZSBNZWRpb25hLjwvc3Bhbj48L2I+PC9wPjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz5QbGFudGFkYSBlbiAxOTY5IGVuIFNhbnQgSm9hbiBkZSBNZWRpb25hIGEgNjUwIG1ldHJvcyBkZSBhbHRpdHVkLCBjcmVjZSBjb24gdW5hcyBlc3BlY2lhbGVzIG5vdGFzIGRlIHNhbGluaWRhZCBtaW5lcmFsLiBEZSBncmFubyB5IHBpZWwgZ3J1ZXNhLCBhIGVzdGEgYWx0aXR1ZCBkaXNmcnV0YSBkZSB1biBleGNlbGVudGUgaW50ZXJjYW1iaW8gdMOpcm1pY28gZMOtYS9ub2NoZSwgZXNwZWNpYWxtZW50ZSBpbXBvcnRhbnRlIHBhcmEgY3JlY2VyIGFsIGFtcGFybyBkZWwgYWlyZSBmcmVzY28gZGUgbW9udGHDsWEuIENvbmZpZXJlIHVuYSBncmFuIGNvbmNlbnRyYWNpw7NuIGRlIGFyb21hcyB5IGFwb3J0YSBhY2lkZXogeSBub3RhcyB0cm9waWNhbGVzLjwvcD4ifX0seyJ0eXBlIjoidy0xLTEgbWItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJtYyB3LTEtMSBocyAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiAiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvNjRmNWIyYzg2NjZmZDFjN2QyYmMyYzQyZWE1NWY5M2EuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJ3LTEtMSBwYi00ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6e319XQ=='),
(122, 24, 'seo_resumen', ''),
(123, 24, 'seo_checktitleonfreaturedimage', '0'),
(124, 24, 'seo_customtitleonfreaturedimage', ''),
(125, 24, 'seo_freaturedimage', ''),
(126, 24, 'seo_noodp', '0'),
(127, 24, 'seo_noydir', '0'),
(128, 24, 'seo_nofollow', '0'),
(129, 24, 'seo_noarchive', '0'),
(130, 24, 'seo_keywords', ''),
(131, 24, 'seo_description', ''),
(132, 24, 'seo_customimage', ''),
(625, 25, 'page_content', 'W3sidHlwZSI6InctMS0xIHB0LTQiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGgxIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz5QUk9EVUNUT1M8L2gxPiJ9fV0='),
(626, 25, 'seo_resumen', ''),
(627, 25, 'seo_checktitleonfreaturedimage', '0'),
(628, 25, 'seo_customtitleonfreaturedimage', ''),
(629, 25, 'seo_freaturedimage', ''),
(630, 25, 'seo_noodp', '0'),
(631, 25, 'seo_noydir', '0'),
(632, 25, 'seo_nofollow', '0'),
(633, 25, 'seo_noarchive', '0'),
(634, 25, 'seo_keywords', ''),
(635, 25, 'seo_description', ''),
(636, 25, 'seo_customimage', ''),
(685, 26, 'page_content', 'W3sidHlwZSI6InctMS0xIHB0LTQiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBwYi0zICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGgxIGNsYXNzPSd0eHRAYyc+PGI+UFJFTUlPUzwvYj48L2gxPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiTnVlc3RybyBjYXZhIGdvemEgZGVsIHJlY29ub2NpbWllbnRvIHkgbGEgZmlkZWxpZGFkIGRlIGNsaWVudGVzIGRlIHJlbGV2YW5jaWEgaW50ZXJuYWNpb25hbC4gRXMgcGlvbmVybyB5IGVzdMOhIHByZXNlbnRlIGVuIGxvcyBtw6FzIHNlbGVjdG9zIGVzdGFibGVjaW1pZW50b3MgZGUgbcO6bHRpcGxlcyBwYcOtc2VzIHBvciBzdSBjYWxpZGFkLCBwZXJzb25hbGlkYWQgeSBleGNsdXNpdmlkYWQuIn19LHsidHlwZSI6InctMS0xIHBiLTMiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9Jycgc3JjPSdjb250ZW50LzMzMDgzNDk5NzE4NjM2NWEyZGY2MWRlNGM4ZjVhY2UyLmpwZycgY2xhc3M9J2UnPjxicj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC02IHBiLTYgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aHI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0nJyBzcmM9J2NvbnRlbnQvNTRlYTQ3MTAzMzIyOGFhYzc4MTg4M2I4N2UyNGQyZjUuanBnJyBjbGFzcz0nZSc+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PScnIHNyYz0nY29udGVudC85MjhmNTIxNzM5ZmIyMTIzMWUyOGQ5MmZjMWY5OWU0MS5qcGcnIGNsYXNzPSdlJz48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNiBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGhyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9Jycgc3JjPSdjb250ZW50LzcyMGI1YjNjZjBkYzM2ODYwMDkxODA5YTI0ZDUzZmYxLnBuZycgY2xhc3M9J2UnPjxicj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC02IHBiLTYgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aHI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0nJyBzcmM9J2NvbnRlbnQvZjE5ZjVhZDlhZDQyY2E3ZTVhZTJkMzBjNDU1MDQ4M2MuanBnJyBjbGFzcz0nZSc+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PScnIHNyYz0nY29udGVudC9lNTE5ODE3YjM5NTRhZWU0MTY0OGViNmYyZDcxOWE4Ny5qcGcnIGNsYXNzPSdlJz48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNiBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGhyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9Jycgc3JjPSdjb250ZW50L2JjODNmZTA2ODRlZjRjMzU1Mjk2NTAxYWMwNGNlMGY3LmpwZycgY2xhc3M9J2UnPjxicj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC02IHBiLTYgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aHI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0nJyBzcmM9J2NvbnRlbnQvNTA3Yzk1MTM1YThiZjM1ZTY0MTEwZDJkZDE5ZGM5Y2IuanBnJyBjbGFzcz0nZSc+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PScnIHNyYz0nY29udGVudC9kY2NkYzM3MjVlZGZmNDhhOGRlYzhiYWQyMTk3MWE5Yy5qcGcnIGNsYXNzPSdlJz48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNiBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGhyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9Jycgc3JjPSdjb250ZW50L2UxMDcwOTI1ODk2YzJmNjIyNzU3ZTVkZGViODI1Mjc4LmpwZycgY2xhc3M9J2UnPjxicj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC02IHBiLTYgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aHI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0nJyBzcmM9J2NvbnRlbnQvNzg3MmM2Y2FhMzM1YWUxOGQ5YzYwMGQ2MzNmYWJkN2MuanBnJyBjbGFzcz0nZSc+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PScnIHNyYz0nY29udGVudC81ZjRiZjRkNzM1ZDkyNDdlNTVhZmM2OTE2ZWY3ZTExOC5qcGcnIGNsYXNzPSdlJz48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNiBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGhyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9Jycgc3JjPSdjb250ZW50L2U5NDNjZjJjMTJlZTdmZTQ3YTIyZTJkMTUxNTk0ZDg1LmpwZycgY2xhc3M9J2UnPjxicj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC02IHBiLTYgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aHI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0nJyBzcmM9J2NvbnRlbnQvZGM0NmI3MTgyODUzMTQ2NDUzYjM3ZmRmNDQ5MmVmZmMuanBnJyBjbGFzcz0nZSc+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PScnIHNyYz0nY29udGVudC80NDUzZDcwOGRmMzEwZTljYjNkZTZjYjBjNmExYWExNC5qcGcnIGNsYXNzPSdlJz48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNiBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGhyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9Jycgc3JjPSdjb250ZW50LzhmYmU1ZjA1ZjJjZmFmYzkxMTA4OGZmNzdmYjMzMDgzLmpwZycgY2xhc3M9J2UnPjxicj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC02IHBiLTYgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aHI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0nJyBzcmM9J2NvbnRlbnQvMjk2MGEyN2YxOWRhOTQ5NTZlMDM3NzM3MDI4NDg3ZTYuanBnJyBjbGFzcz0nZSc+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTYgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PScnIHNyYz0nY29udGVudC81YmU4MmRlOWM2MDRjYTY4N2JmZDhmZDNmMTBmMjdiOS5qcGcnIGNsYXNzPSdlJz48YnI+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNiBwYi02ICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGhyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9Jycgc3JjPSdjb250ZW50LzU5ODMxZjJlZjNjMGRkYTNmMjY0NjE3ZGJlNTcxY2IxLmpwZycgY2xhc3M9J2UnPjxicj4ifX0seyJ0eXBlIjoidy0xLTEgcGItMyIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6e319XQ=='),
(686, 26, 'seo_resumen', ''),
(687, 26, 'seo_checktitleonfreaturedimage', '0'),
(688, 26, 'seo_customtitleonfreaturedimage', ''),
(689, 26, 'seo_freaturedimage', ''),
(690, 26, 'seo_noodp', '0'),
(691, 26, 'seo_noydir', '0'),
(692, 26, 'seo_nofollow', '0'),
(693, 26, 'seo_noarchive', '0'),
(694, 26, 'seo_keywords', ''),
(695, 26, 'seo_description', ''),
(696, 26, 'seo_customimage', ''),
(841, 26, 'gallery_id', '25');
INSERT INTO `pages_meta` (`id`, `p_id`, `meta_key`, `meta_value`) VALUES
(1046, 27, 'page_content', 'W3sidHlwZSI6InctMS0xIHB0LTQiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBwYi0zIHBiLTdAcyAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PGI+RUwgT1LDjUdFTjogVkFMTFMgRCYjMzk7QU5PSUEtRk9JWDwvYj48L2gxPiJ9fSx7InR5cGUiOiJ3LTEtMSBobSBobCBoeGwgcGItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvYjI3OTQ2NDg1NDM5YjA0NDkwMjk1OTZlMTM0MDg1MDQuanBnJiMzOTsgY2xhc3M9JiMzOTttYyYjMzk7Pjxicj48L3A+In19LHsidHlwZSI6InctNC0xMCB3cy0xLTEgcHQtMiBwYi00ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7Pk51ZXN0cm9zIHZpw7FlZG9zIHNlIHViaWNhbiBlbiBlbCBsYSB6b25hIGhpc3TDs3JpY2EgZGVsIENhdmEgYWwgc3VyIGRlIEJhcmNlbG9uYSwgZW4gbGEgem9uYSBkZW5vbWluYWRhIFZBTExTIETigJlBTk9JQS1GT0lYIGRlbGltaXRhZG9zIGVudHJlIGVsIG1hciBNZWRpdGVycsOhbmVvIHkgbGFzIG1vbnRhw7FhcyBkZSBNb250c2VycmF0LiBMYSBwYXJ0aWN1bGFyIGdlb2xvZ8OtYSBkZSBsYSB6b25hIHkgbGEgaW5mbHVlbmNpYSBkZWwgbWFyLCBkZXRlcm1pbmFuIHVuYSBkaXZlcnNpZGFkIGRlIHN1ZWxvcyBjb24gaW1wb3J0YW50ZXMgY2FyYWN0ZXLDrXN0aWNhcyBsaXRvbMOzZ2ljYXMgcXVlIGNvbmZpZ3VyYW4gdHJlcyB6b25hcyB2aXTDrWNvbGFzIGRpZmVyZW5jaWFkYXMgcGFyYSBudWVzdHJvcyB2aW5vcyBiYXNlLjxicj48YnI+RXN0YSBleGNlcGNpb25hbCBkaXZlcnNpZGFkIG5vcyBwZXJtaXRlIGVsYWJvcmFyIHZpbm9zIGRlIGdyYW4gc2luZ3VsYXJpZGFkLCBjb24gdW5hIGlkZW50aWRhZCBwZWN1bGlhciBwcsOzcGlhIGRlIGNhZGEgem9uYS4gU2VsZWNjaW9uYW1vcyBsb3MgbWVqb3JlcyB0ZXJyZW5vcyBkZSBjYWRhIHBhcmNlbGEgcGFyYSBvYnRlbmVyIGxhIG3DoXhpbWEgZXhwcmVzacOzbiwgY2FsaWRhZCB5IHBlcnNvbmFsaWRhZCBkZSBjYWRhIHZhcmllZGFkLjwvcD4ifX0seyJ0eXBlIjoidy02LTEwIGhzIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvYjI3OTQ2NDg1NDM5YjA0NDkwMjk1OTZlMTM0MDg1MDQuanBnJiMzOTsgY2xhc3M9JiMzOTttYyYjMzk7Pjxicj48L3A+In19XQ=='),
(1047, 27, 'seo_resumen', ''),
(1048, 27, 'seo_checktitleonfreaturedimage', '0'),
(1049, 27, 'seo_customtitleonfreaturedimage', ''),
(1050, 27, 'seo_freaturedimage', ''),
(1051, 27, 'seo_noodp', '0'),
(1052, 27, 'seo_noydir', '0'),
(1053, 27, 'seo_nofollow', '0'),
(1054, 27, 'seo_noarchive', '0'),
(1055, 27, 'seo_keywords', ''),
(1056, 27, 'seo_description', ''),
(1057, 27, 'seo_customimage', ''),
(1118, 0, 'gallery_id', '37'),
(1179, 28, 'page_content', 'W3sidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcGItMyAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7cDEgdHh0QGMmIzM5Oz48Yj5WSVRJQ1VMVFVSQSBFQ09Mw5NHSUNBPC9iPjxicj48L3A+PHAgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjwvcD48cCBjbGFzcz0mIzM5O3AyIHR4dEBjJiMzOTs+UHJhY3RpY2Ftb3MgdW5hIHZpdGljdWx0dXJhIHNvc3RlbmlibGUsIGVjb2zDs2dpY2EgeSByZXNwZXR1b3NhIGNvbiBlbCBtZWRpbyBhbWJpZW50ZSwgcG9yIGVzbyB0cmFiYWphbW9zJm5ic3A7PGJyPm51ZXN0cm9zIHZpw7FlZG9zIGV4Y2x1c2l2YW1lbnRlIGNvbiBwcm9kdWN0b3MgZWNvbMOzZ2ljb3MuPC9wPjxwIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48L3A+In19LHsidHlwZSI6InctMS0xIGdjIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX0seyJ0eXBlIjoibWMgdy0xLTEgd3MtMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2h0dHBzOi8vdG1wLmRtMjExLmNvbS9hZ3VzdGl0b3JlbGxvbWF0YS5jb20vY29udGVudC81OTc4NGIyZWU5MDFmN2RmYjBmZmM3MDQ3NTRkN2JmMC5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0xIGciLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0mIzM5O3AxIHR4dEBjJiMzOTs+PGI+Q29udHJvbGFtb3MgbGEgcHJvZHVjY2nDs248L2I+PC9wPjxwIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48L3A+PHAgY2xhc3M9JiMzOTtwMiB0eHRAYyYjMzk7PkxpbWl0YW1vcyBsYSBwcm9kdWNjacOzbiBwYXJhIGF1bWVudGFyIGxhIGNvbmNlbnRyYWNpw7NuIGRlIG51ZXN0cmFzIHV2YXMuPC9wPjxwIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48L3A+PHAgY2xhc3M9JiMzOTtwMSB0eHRAYyYjMzk7PjxiPjxicj48L2I+PC9wPjxwIGNsYXNzPSYjMzk7cDEgdHh0QGMmIzM5Oz48Yj5SZWNvbGVjdGFkbyBhIG1hbm88L2I+PC9wPjxwIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48L3A+PHAgY2xhc3M9JiMzOTtwMiB0eHRAYyYjMzk7PlJlY29sZWN0YW1vcyB5IHNlbGVjY2lvbmFtb3MgbWFudWFsbWVudGUgdXZhIGEgdXZhIHBhcmEgZ2FyYW50aXphciBzdSBjYWxpZGFkLjwvcD4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwYi0zICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50LzEwZGZjYTM2ZjIwNDZiYjJjOWZkMDA2ZjFhYTQyMmIwLmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwYi0zICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTtwMSB0eHRAYyYjMzk7PjxiPkxhIFZlbmTDrW1pYTwvYj48L3A+PGJyPiA8cCBjbGFzcz0mIzM5O3AyIHR4dEBjJiMzOTs+SW5pY2lhbW9zIGxhIHZlbmTDrW1pYSBlbiBlbCBtb21lbnRvIMOzcHRpbW8gZGUgbWFkdXJhY2nDs24gZGUgY2FkYSB2YXJpZWRhZCwgcGFyYSBnYXJhbnRpemFyIGVsIGVxdWlsaWJyaW8gZGUgbG9zIGFyb21hcywgYXrDumNhcmVzIHkgYWNpZGV6LjwvcD48YnI+In19LHsidHlwZSI6InctMS0xIGdjIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX0seyJ0eXBlIjoibWMgdy0xLTEgd3MtMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2h0dHBzOi8vdG1wLmRtMjExLmNvbS9hZ3VzdGl0b3JlbGxvbWF0YS5jb20vY29udGVudC81Y2RiNjk5ZTA2ZGU3NTJhMDllMjI4Y2QyMzcwOGMzNS5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0xIGciLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBwYi0zIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX1d'),
(1180, 28, 'seo_resumen', ''),
(1181, 28, 'seo_checktitleonfreaturedimage', '0'),
(1182, 28, 'seo_customtitleonfreaturedimage', ''),
(1183, 28, 'seo_freaturedimage', ''),
(1184, 28, 'seo_noodp', '0'),
(1185, 28, 'seo_noydir', '0'),
(1186, 28, 'seo_nofollow', '0'),
(1187, 28, 'seo_noarchive', '0'),
(1188, 28, 'seo_keywords', ''),
(1189, 28, 'seo_description', ''),
(1190, 28, 'seo_customimage', ''),
(1203, 29, 'page_content', 'W3sidHlwZSI6InctMS0xIHBiLTQiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBwYi0zIHBiLTdAcyAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PGI+MTAwJSBWQVJJRURBREVTIEFVVMOTQ1RPTkFTPC9iPjwvaDE+In19LHsidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0mIzM5O3AxJiMzOTs+TWFudGVuZW1vcyBsYSBmaWRlbGlkYWQgYSBsYXMgdmFyaWVkYWRlcyBhdXTDs2N0b25hcyB0cmFkaWNpb25hbGVzLCDDum5pY2FzIGVuIGVsIG11bmRvOiBNYWNhYmVvLCBYYXJlbMK3bG8geSBQYXJlbGxhZGEgcGFyYSBsb3MgYmxhbmNvcywgeSBUcmVwYXQgcGFyYSBlbCByb3NhZG8uPGJyPjwvcD4ifX0seyJ0eXBlIjoidy0xLTEgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6Ijxocj4ifX0seyJ0eXBlIjoibWMgdy0xLTIgd3MtMS0xIHBiLTggIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBpZD0mIzM5O2FydGljdWxvLW1hY2FiZW8mIzM5OyBjbGFzcz0mIzM5O3AxJiMzOTs+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+TUFDQUJFTzwvc3Bhbj4gLSZuYnNwOzwvYj48Yj5GaW51cmEgeSBlbGVnYW5jaWE8L2I+PC9wPjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC9hMTgxYzY5MDIwM2JkYmFmMTRkZTcxZmJiYjNiMjFkMi5qcGcmIzM5Oz48cCBjbGFzcz0mIzM5O3AyJiMzOTs+TGFzIHBhcmNlbGFzIGRlIGxhIHpvbmEgbGl0b3JhbCwgY29uIGdyYXZhcywgbsOzZHVsb3MgeSBzdWVsb3MgcG9icmVzLCBub3MgcHJvcG9yY2lvbmEgdXZhcyBkZSBhcm9tYXMgYWZydXRhZG9zIHkgbWFuemFuYSB2ZXJkZSwgcXVlIGFwb3J0YW4gZmludXJhIHkgZWxlZ2FuY2lhIGFsIGN1cGFnZSBBR1VTVMONIFRPUkVMTMOTIE1BVEEuIExhIHZhcmllZGFkIE1hY2FiZW8gcHJlZG9taW5hIGVuIHRvZG9zIGVsbG9zLi48YnI+PGJyPjwvcD48dWwgY2xhc3M9JiMzOTtnIGd3LTEtMSYjMzk7PjxsaT48Yj5QYWlzYWplOiA8L2I+U2l0Z2VzIC0gU2llcnJhIExpdG9yYWwuPC9saT48bGk+PGI+QWx0aXR1ZDombmJzcDs8L2I+RGUgMCBhIDIwMG0uPC9saT48bGk+PGI+U3VlbG86Jm5ic3A7PC9iPkdyYXZhcywgbsOzZHVsb3MgZGUgY2FsaWNoZSwgc3VlbG9zIHBvYnJlcy48L2xpPjwvdWw+In19LHsidHlwZSI6Im1jIHctMS0yIHdzLTEtMSBwYi04ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgaWQ9JiMzOTthcnRpY3Vsby14YXJlbGxvJiMzOTsgY2xhc3M9JiMzOTtwMSYjMzk7PjxiPjxzcGFuIHN0eWxlPSYjMzk7Y29sb3I6IHJnYigxODUsIDE0NiwgMjUpOyYjMzk7PlhBUkVMLkxPPC9zcGFuPiAtJm5ic3A7PC9iPjxiPkN1ZXJwbyB5IGVzdHJ1Y3R1cmE8L2I+PC9wPjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC8wNGY3MGVhYWQxOWZjYTU3OTBlOGQ1YWM4NTcxZmJiMy5qcGcmIzM5Oz48cCBzdHlsZT0mIzM5O3RleHQtYWxpZ246IGp1c3RpZnk7JiMzOTs+RGUgbGEgem9uYSBjZW50cmFsIGRlbCBQZW5lZMOpcywgdGllcnJhcyBkZSBhcmNpbGxhcyBjYWxjw6FyZWFzIGRlIHZpw7FlZG9zIHNpdHVhZG9zIGVudHJlIDIwMCB5IDMwMCBtZXRyb3MgZGUgYWx0aXR1ZCBsYSB2YXJpZWRhZCB4YXJlbMK3bG8gZXhwcmVzYSBzdSBjYXLDoWN0ZXIgbcOhcyB2ZWdldGFsLCB5ICBhcG9ydGEgY3VlcnBvIHkgZXN0cnVjdHVyYS48L3A+PHAgY2xhc3M9JiMzOTtwMyYjMzk7PjwvcD48dWwgY2xhc3M9JiMzOTtnIGd3LTEtMSYjMzk7PjxsaT48Yj5QYWlzYWplOiZuYnNwOzwvYj5TYW50IFNhZHVybsOtIGTigJlBbm9pYSAtIFZhbGwgZOKAmUFub2lhIEZvaXguPC9saT48bGk+PGI+QWx0aXR1ZDombmJzcDs8L2I+RW50cmUgMjAwIHkgNDAwbS48L2xpPjxsaT48Yj5TdWVsbzombmJzcDs8L2I+QXJjaWxsYXMgZGUgdGlwbyBjYWxjw6FyZW8uPC9saT48L3VsPiJ9fSx7InR5cGUiOiJtYyB3LTEtMiB3cy0xLTEgcGItOCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGlkPSYjMzk7YXJ0aWN1bG8tcGFyZWxsYWRhJiMzOTsgY2xhc3M9JiMzOTtwMSYjMzk7PjxiPjxzcGFuIHN0eWxlPSYjMzk7Y29sb3I6IHJnYigxODUsIDE0NiwgMjUpOyYjMzk7PlBBUkVMTEFEQTwvc3Bhbj4gLSZuYnNwOzwvYj48Yj5Bcm9tYSB5IGFjaWRlejwvYj48L3A+PGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50L2M0MjYzMjhmZGNlMzk1YjlmZDkzNzZhZWU4MThjMDkyLmpwZyYjMzk7PjxwIGNsYXNzPSYjMzk7cDMmIzM5Oz5BIDUwMCBtZXRyb3MgZGUgYWx0aXR1ZCwgZW4gc3VlbG9zIGRlIHBpemFycmEgeSBhcmVuaXRhcyBkZSBudWVzdHJhIGZpbmNhIFViYWMgZGUgTWVkaW9uYSBzZSBlbmN1ZW50cmFuIGxhcyBwYXJjZWxhcyBkZSBQYXJlbGxhZGEgcXVlIG5vcyBpbXByaW1lbiBhcm9tYXMgZGUgZnJ1dGEgdHJvcGljYWwuPC9wPjx1bCBjbGFzcz0mIzM5O2cgZ3ctMS0xJiMzOTs+PGxpPjxiPlBhaXNhamU6Jm5ic3A7PC9iPkNhc3RpbGxvIGRlIE1lZGlvbmEsIHMuIFhJSUkuIC0gVml0aWN1bHR1cmEgZGUgbW9udGHDsWEuPC9saT48bGk+PGI+QWx0aXR1ZDombmJzcDs8L2I+RW50cmUgNTAwIHkgOTAwTS48L2xpPjxsaT48Yj5TdWVsbzombmJzcDs8L2I+QXJlbml0YXMgeSBwaXphcnJhcy48L2xpPjwvdWw+In19LHsidHlwZSI6Im1jIHctMS0yIHdzLTEtMSBwYi04ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgaWQ9JiMzOTthcnRpY3Vsby10cmVwYXQmIzM5OyBjbGFzcz0mIzM5O3AxJiMzOTs+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+VFJFUEFUPC9zcGFuPjwvYj48Yj4tIEZpbnVyYSB5IGZyZXNjdXJhPC9iPjwvcD48cCBjbGFzcz0mIzM5O3AzJiMzOTs+PC9wPjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC9kY2Y5OWNiM2MzMmMxZTkxNTIxZWJmMWM1YWVlYTQ5NS5qcGcmIzM5Oz48YnI+PHAgc3R5bGU9JiMzOTt0ZXh0LWFsaWduOiBqdXN0aWZ5OyYjMzk7PkN1bHRpdmFkYSwgY29tbyBsYSBQYXJlbGxhZGEgZW4gcGFyY2VsYXMgZGUgYWx0YSBtb250YcOxYSwgc2UgZXhwcmVzYSBUcmVwYXQsIHZhcmllZGFkIHRpbnRhIGNvbiBsYSBxdWUgZWxhYm9yYW1vcyBlbCBDQVZBIFJPU0FULiBFbCBpbnRlcmNhbWJpbyB0w6lybWljbyBkw61hL25vY2hlIG5vcyBwcm9wb3JjaW9uYSB1bm9zIGluY3Jlw61ibGVzIGFyb21hcyBkZSBmcnV0b3Mgcm9qb3MgeSBmcmVzY29zLjwvcD48dWwgY2xhc3M9JiMzOTtnIGd3LTEtMSYjMzk7PjxsaT48Yj5QYWlzYWplOiZuYnNwOzwvYj5DYXN0aWxsbyBkZSBNZWRpb25hLCBzLiBYSUlJLiAtIFZpdGljdWx0dXJhIGRlIG1vbnRhw7FhLjwvbGk+PGxpPjxiPkFsdGl0dWQ6Jm5ic3A7PC9iPkVudHJlIDUwMCB5IDkwMG0uPC9saT48bGk+PGI+U3VlbG86Jm5ic3A7PC9iPkFyZW5pdGFzIHkgcGl6YXJyYXMuPC9saT48L3VsPiJ9fSx7InR5cGUiOiJ3LTEtMSBwYi0zIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX1d'),
(1204, 29, 'seo_resumen', ''),
(1205, 29, 'seo_checktitleonfreaturedimage', '0'),
(1206, 29, 'seo_customtitleonfreaturedimage', ''),
(1207, 29, 'seo_freaturedimage', ''),
(1208, 29, 'seo_noodp', '0'),
(1209, 29, 'seo_noydir', '0'),
(1210, 29, 'seo_nofollow', '0'),
(1211, 29, 'seo_noarchive', '0'),
(1212, 29, 'seo_keywords', ''),
(1213, 29, 'seo_description', ''),
(1214, 29, 'seo_customimage', ''),
(1299, 30, 'page_content', 'W3sidHlwZSI6InctMS0xIGdjIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiJocyIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBocyAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6InBvc2l0aW9uOnJlbGF0aXZlOyIsImNjbGFzcyI6ImhzIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50L2I1NjNhYTYzMGM5ZmQ5YjBkODNjNWU5NGQ3YTBmMTFlLmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoiaHMgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiJwb3NpdGlvbjphYnNvbHV0ZTsgdG9wOiAyJTsgcmlnaHQ6IDEyJTtjb2xvcjojZmZmOyB3aWR0aDozMDJweDsiLCJjY2xhc3MiOiJocyIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxkaXY+PGgxIGNsYXNzPSYjMzk7dHh0QHImIzM5Oz48Yj48c3BhbiBzdHlsZT0mIzM5O2NvbG9yOiByZ2IoMjU1LCAyNTUsIDI1NSk7JiMzOTs+Q1JJQU5aQTwvc3Bhbj48L2I+PC9oMT48L2Rpdj48ZGl2PjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz48L3A+PHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PkVuIGxhIHByb2Z1bmRpZGFkIGRlIGxhcyBjYXZhcywgcHJvdGVnaWRhcyBkZSBsYSBsdXosIGNvbiB1bmEgaHVtZWRhZCB5IHRlbXBlcmF0dXJhIGNvbnN0YW50ZXMsIHNlIHByb2R1Y2UgZWwgbWlsYWdybzogZW4gY2FkYSBib3RlbGxhIG5hY2Vyw6FuIGxlbnRhIHkgcGFjaWVudGVtZW50ZSBsYXMgZmluYXMgYnVyYnVqYXMgcXVlIHNlIHRyYW5zZm9ybWFuIGVuIHVuIGNhdmEgY29tcGxlam8geSBleGNlcGNpb25hbC4gPGJyPjxicj5FbGFib3JhbW9zIGV4Y2x1c2l2YW1lbnRlIFJFU0VSVkEgeSBHUkFOIFJFU0VSVkEgcG9ycXVlIHNvbG8gbGFzIGxhcmdhcyBjcmlhbnphcyBhcG9ydGFuIGxhIGNvbXBsZWppZGFkIGRlbCBib3VxdWV0IHkgbGEgZmluYSBpbnRlZ3JhY2nDs24gZGVsIGNhcmLDs25pY28gZW4gY2FkYSBib3RlbGxhLjxicj48L3A+PC9kaXY+In19LHsidHlwZSI6InctMS0xIGciLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6ImhzIiwiY29udHJvbCI6IiIsImRvbSI6e319LHsidHlwZSI6InctMS0xIGhzIHBiLW5AcyAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6InBvc2l0aW9uOiByZWxhdGl2ZTsgZGlzcGxheTpibG9jazsgcGFkZGluZy1ib3R0b206IDIwJTsiLCJjY2xhc3MiOiJuLXBAcyIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IiJ9fSx7InR5cGUiOiJ3LTEtMSBnYyIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoicG9zaXRpb246IHJlbGF0aXZlOyIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBocyAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6InBvc2l0aW9uOiByZWxhdGl2ZTsiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8ZGl2IHN0eWxlPSYjMzk7cG9zaXRpb246cmVsYXRpdmU7JiMzOTs+PGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50LzI2Yzc1YTIxNzJjODQ3ZTRkODc0OTIzOGIzMTkyNjA3LmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7PjxkaXYgY2xhc3M9JiMzOTt3LTQtMTAmIzM5OyBzdHlsZT0mIzM5O3Bvc2l0aW9uOiBhYnNvbHV0ZTsgdG9wOiAtMTUlOyBsZWZ0OiAxMCU7IGJhY2tncm91bmQtY29sb3I6I2ZmZjsgcGFkZGluZzogMSUgMiUgMSUgMiU7JiMzOTs+PGgxPjxiPkRFR8OcRUxMRTogRUwgRklOIERFIExBIENSSUFOWkE8L2I+PC9oMT48YnI+PHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PlRyYXMgYcOxb3MgZGUgY3JpYW56YSwgbGFzIGxldmFkdXJhcyBoYW4gZm9ybWFkbyBzdSBwb3NvLiBTb24gbGFzIG1hZHJlcyBkZWwgdmlubywgbGFzIGzDrWFzIHF1ZSB0ZW5kcmVtb3MgcXVlIGVsaW1pbmFyIGVuIGVsIGRlZ8O8ZWxsZSBwYXJhIHF1ZSBjYWRhIGJvdGVsbGEgcXVlZGUgcGVyZmVjdGFtZW50ZSBsaW1waWEuIEVzIGVsIG1vbWVudG8gZmluYWwgZW4gcXVlIHNlIGRlc2NvcmNoYSBsYSBib3RlbGxhIHkgc2UgY2llcnJhIGNvbiBlbCB0YXDDs24gZGUgY29yY2hvIGRlZmluaXRpdm8geSBkZSBlc3RlIG1vZG8gbGxlZ2FyYW4gY2F2YSB5IHZpbm8gYSBsYSBtZXNhIGRlIGNhZGEgY29uc3VtaWRvci48YnI+PC9wPjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz5Ub2RhcyBsYXMgYm90ZWxsYXMgQUdVU1RJIFRPUkVMTE8gTUFUQSBsbGV2YW4gY29tbyBsb3RlIGxhIDxiPmZlY2hhIGRlIGRlZ8O8ZWxsZTwvYj46IGVzIGxhIGluZm9ybWFjacOzbiBpbXByZXNjaW5kaWJsZSBwYXJhIGNvbm9jZXIgZWwgbW9tZW50byBlbiBxdWUgaGEgZmluYWxpemFkbyBsYSBjcmlhbnphIGVuIGxhIGJvZGVnYS4gTGEgZXRpcXVldGEgbm9zIGRpcsOhIGVsIGHDsW8gZGUgY29zZWNoYSwgbGEgZmVjaGEgZGUgZGVnw7xlbGxlLCB5IGN1w6FudG9zIGHDsW9zIGRlIGNyaWFuemEgdGllbmUgZWwgQ2F2YS4gRW4gZGVmaW5pdGl2YSwgc3UgbWVqb3IgbW9tZW50byBwYXJhIGRpc2ZydXRhcmxvLjwvcD48L2Rpdj48L2Rpdj4ifX0seyJ0eXBlIjoidy0xLTEgaHMgcGItbkBzICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6e319LHsidHlwZSI6InctMS0xIGciLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBobSBobCBoeGwgcHQtNCBwYi03ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGgxIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48Yj5DUklBTlpBPC9iPjwvaDE+In19LHsidHlwZSI6InctMS0xIGhtIGhsIGh4bCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC9iNTYzYWE2MzBjOWZkOWIwZDgzYzVlOTRkN2EwZjExZS5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0xIGhtIGhsIGh4bCBwdC02ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PkVuIGxhIHByb2Z1bmRpZGFkIGRlIGxhcyBjYXZhcywgcHJvdGVnaWRhcyBkZSBsYSBsdXosIGNvbiB1bmEgaHVtZWRhZCB5IHRlbXBlcmF0dXJhIGNvbnN0YW50ZXMsIHNlIHByb2R1Y2UgZWwgbWlsYWdybzogZW4gY2FkYSBib3RlbGxhIG5hY2Vyw6FuIGxlbnRhIHkgcGFjaWVudGVtZW50ZSBsYXMgZmluYXMgYnVyYnVqYXMgcXVlIHNlIHRyYW5zZm9ybWFuIGVuIHVuIGNhdmEgY29tcGxlam8geSBleGNlcGNpb25hbC4mbmJzcDs8YnI+PGJyPkVsYWJvcmFtb3MgZXhjbHVzaXZhbWVudGUgUkVTRVJWQSB5IEdSQU4gUkVTRVJWQSBwb3JxdWUgc29sbyBsYXMgbGFyZ2FzIGNyaWFuemFzIGFwb3J0YW4gbGEgY29tcGxlamlkYWQgZGVsIGJvdXF1ZXQgeSBsYSBmaW5hIGludGVncmFjacOzbiBkZWwgY2FyYsOzbmljbyBlbiBjYWRhIGJvdGVsbGEuPGJyPjwvcD4ifX0seyJ0eXBlIjoidy0xLTEgaG0gaGwgaHhsIHB0LTYgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPkRFR8OcRUxMRTogRUwgRklOIERFIExBIENSSUFOWkE8L2I+PC9oMT4ifX0seyJ0eXBlIjoidy0xLTEgaG0gaGwgaHhsIHB0LTcgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvMjZjNzVhMjE3MmM4NDdlNGQ4NzQ5MjM4YjMxOTI2MDcuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJ3LTEtMSBobSBobCBoeGwgcHQtNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz5UcmFzIGHDsW9zIGRlIGNyaWFuemEsIGxhcyBsZXZhZHVyYXMgaGFuIGZvcm1hZG8gc3UgcG9zby4gU29uIGxhcyBtYWRyZXMgZGVsIHZpbm8sIGxhcyBsw61hcyBxdWUgdGVuZHJlbW9zIHF1ZSBlbGltaW5hciBlbiBlbCBkZWfDvGVsbGUgcGFyYSBxdWUgY2FkYSBib3RlbGxhIHF1ZWRlIHBlcmZlY3RhbWVudGUgbGltcGlhLiBFcyBlbCBtb21lbnRvIGZpbmFsIGVuIHF1ZSBzZSBkZXNjb3JjaGEgbGEgYm90ZWxsYSB5IHNlIGNpZXJyYSBjb24gZWwgdGFww7NuIGRlIGNvcmNobyBkZWZpbml0aXZvIHkgZGUgZXN0ZSBtb2RvIGxsZWdhcmFuIGNhdmEgeSB2aW5vIGEgbGEgbWVzYSBkZSBjYWRhIGNvbnN1bWlkb3IuPGJyPjwvcD48cCBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+VG9kYXMgbGFzIGJvdGVsbGFzIEFHVVNUSSBUT1JFTExPIE1BVEEgbGxldmFuIGNvbW8gbG90ZSBsYSA8Yj5mZWNoYSBkZSBkZWfDvGVsbGU8L2I+OiBlcyBsYSBpbmZvcm1hY2nDs24gaW1wcmVzY2luZGlibGUgcGFyYSBjb25vY2VyIGVsIG1vbWVudG8gZW4gcXVlIGhhIGZpbmFsaXphZG8gbGEgY3JpYW56YSBlbiBsYSBib2RlZ2EuIExhIGV0aXF1ZXRhIG5vcyBkaXLDoSBlbCBhw7FvIGRlIGNvc2VjaGEsIGxhIGZlY2hhIGRlIGRlZ8O8ZWxsZSwgeSBjdcOhbnRvcyBhw7FvcyBkZSBjcmlhbnphIHRpZW5lIGVsIENhdmEuIEVuIGRlZmluaXRpdmEsIHN1IG1lam9yIG1vbWVudG8gcGFyYSBkaXNmcnV0YXJsby48L3A+In19LHsidHlwZSI6InctMS0xIGhtIGhsIGh4bCBwYi00ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6e319XQ=='),
(1300, 30, 'seo_resumen', ''),
(1301, 30, 'seo_checktitleonfreaturedimage', '0'),
(1302, 30, 'seo_customtitleonfreaturedimage', ''),
(1303, 30, 'seo_freaturedimage', ''),
(1304, 30, 'seo_noodp', '0'),
(1305, 30, 'seo_noydir', '0'),
(1306, 30, 'seo_nofollow', '0'),
(1307, 30, 'seo_noarchive', '0'),
(1308, 30, 'seo_keywords', ''),
(1309, 30, 'seo_description', ''),
(1310, 30, 'seo_customimage', ''),
(1335, 31, 'page_content', 'W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPkRFR8OcRUxMRTwvYj48L2gxPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBzdHlsZT0mIzM5O3RleHQtYWxpZ246IGp1c3RpZnk7JiMzOTs+VHJhcyBhw7FvcyBkZSBjcmlhbnphLCBsYXMgbGV2YWR1cmFzIGhhbiBmb3JtYWRvIHN1IHBvc28uIFNvbiBsYXMgbWFkcmVzIGRlbCB2aW5vLCBsYXMgbMOtYXMsIHF1ZSB0ZW5kcmVtb3MgcXVlIHNhY2FyIHBhcmEgcXVlIGNhZGEgYm90ZWxsYSBxdWVkZSBwZXJmZWN0YW1lbnRlIGxpbXBpYS4gRWwgZGVnw7xlbGxlIGVzIGVzdGUgbW9tZW50byBmaW5hbCBlbiBxdWUgc2UgZGVzY29yY2hhIGxhIGJvdGVsbGEsIGVsaW1pbmFuZG8gbGFzIGzDrWFzIHkgcG9uaWVuZG8gZWwgdGFww7NuIGRlIGNvcmNobyBkZWZpbml0aXZvLiBFcyBsYSBtaXNtYSAgYm90ZWxsYSBxdWUgbGxlZ2Fyw6EgYSBsYSBtZXNhIGRlIGNhZGEgY29uc3VtaWRvci48L3A+PGJyPjxwIHN0eWxlPSYjMzk7dGV4dC1hbGlnbjoganVzdGlmeTsmIzM5Oz5Ub2RhcyBsYXMgYm90ZWxsYXMgQUdVU1RJIFRPUkVMTE8gTUFUQSBsbGV2YW4gY29tbyBsb3RlLCBsYSA8Yj5mZWNoYSBkZSBkZWfDvGVsbGU8L2I+OiBlcyBsYSBpbmZvcm1hY2nDs24gaW1wcmVzY2luZGlibGUgcGFyYSBjb25vY2VyIGVsIG1vbWVudG8gZW4gcXVlIGhhIGZpbmFsaXphZG8gbGEgY3JpYW56YS4gTGEgZXRpcXVldGEgbm9zIGRpcsOhIGVsIGHDsW8gZGUgY29zZWNoYSwgbGEgZmVjaGEgZGUgZGVnw7xlbGxlLCBub3MgZGlyw6EgY3VhbnRvcyBhw7FvcyBkZSBjcmlhbnphIHRpZW5lIGVsIENhdmEuIEVzIGVudG9uY2VzLCBzdSBtb21lbnRvIMOzcHRpbW8gcGFyYSBkaXNmcnV0YXJsby48L3A+PGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvMWFlYTI0OGQ2NDQwMjQyZjk1MDI0YWJhYTcyNzA3ZjQuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJ3LTEtMSBwYi02IiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX1d'),
(1336, 31, 'seo_resumen', ''),
(1337, 31, 'seo_checktitleonfreaturedimage', '0'),
(1338, 31, 'seo_customtitleonfreaturedimage', ''),
(1339, 31, 'seo_freaturedimage', ''),
(1340, 31, 'seo_noodp', '0'),
(1341, 31, 'seo_noydir', '0'),
(1342, 31, 'seo_nofollow', '0'),
(1343, 31, 'seo_noarchive', '0'),
(1344, 31, 'seo_keywords', ''),
(1345, 31, 'seo_description', ''),
(1346, 31, 'seo_customimage', ''),
(1359, 32, 'page_content', 'W3sidHlwZSI6InctMS0xIGdjIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEgaHMgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiJwb3NpdGlvbjpyZWxhdGl2ZTsiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8ZGl2IHN0eWxlPSYjMzk7cG9zaXRpb246IHJlbGF0aXZlOyYjMzk7PjxkaXYgY2xhc3M9JiMzOTt3LTEtMSBwdC01JiMzOTsgc3R5bGU9JiMzOTtwb3NpdGlvbjphYnNvbHV0ZTsmIzM5Oz48aDEgY2xhc3M9JiMzOTt0eHRAYyBwYi0yJiMzOTs+PGI+VklOT1MgRC5PLiBQRU5FRMOIUzwvYj48L2gxPjxkaXYgc3R5bGU9JiMzOTtwb3NpdGlvbjphYnNvbHV0ZTsgbGVmdDogMTUlOyB3aWR0aDogNDUwcHg7JiMzOTs+PHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PkVsIFBlbmVkw6lzIGNvbiBzdSBnZW9ncmFmaWEgbGltaXRhZGEgcG9yIGVsIE1hciB5IGxhcyBtb250YcOxYXMgZGUgTW9udHNlcnJhdCBub3MgcGVybWl0ZSBlbGFib3JhciB2aW5vcyBibGFuY29zIHkgcm9zYWRvcyBkZSB1bmEgZ3JhbiBlbGVnYW5jaWEuIFNvbiB2aW5vcyBtZWRpdGVycsOhbmVvcywgdmlub3MgZGUgc29sLCB0b2RvcyBlbGxvcyBlY29sw7NnaWNvcywgY29uIGNlcnRpZmljYWNpw7NuIHZlZ2FuYSB5IHZlbmRpbWlhZG9zIGEgbWFuby4gU29sbyBsYXMgdmFyaWVkYWRlcyBtw6FzIG5vYmxlcyBzZSBjb252aWVydGVuIGVuIHZpbm9zIEFHVVNUw40gVE9SRUxMw5MgTUFUQS48L3A+PC9kaXY+PC9kaXY+PGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50LzY5YzBjMzQzNGY1NWNlYmRlZGEzNzQ0NmI1Y2E5ZjZhLmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7PjwvZGl2PiJ9fSx7InR5cGUiOiJ3LTEtMSBnIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEgaHMgcGItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJtYyB3LTgtMTAgaHMgd3MtMS0xIHBiLTUgcHQtNEBzIHBiLTdAcyAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxkaXYgY2xhc3M9JiMzOTtnJiMzOTs+PGRpdiBjbGFzcz0mIzM5O3ctMS0zJiMzOTs+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+WElDPC9zcGFuPjwvYj48cCBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+VmlubyBibGFuY28uIFZhcmllZGFkIHhhcmVsLmxvIDEwMCUuIEpvdmVuIHkgZnJlc2NvIHRpZW5lIHVuYSBmZXJtZW50YWNpw7NuIHkgY3JpYW56YSBlbiBsw61hcyBkdXJhbnRlIDUgbWVzZXMuPC9wPjwvZGl2PjxkaXYgY2xhc3M9JiMzOTt3LTEtMyYjMzk7PjxiPjxzcGFuIHN0eWxlPSYjMzk7Y29sb3I6IHJnYigxODUsIDE0NiwgMjUpOyYjMzk7PlhJQyBWRVJNRUxMPC9zcGFuPjwvYj48cCBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+Um9zYWRvIG11eSBww6FsaWRvLiBWYXJpZWRhZCB4YXJlbC5sbyB2ZXJtZWxsLiBNYWNlcmFkbyA4IGhvcmFzLiBGZXJtZW50YWNpw7NuIHkgY3JpYW56YSBlbiBsw61hcyBkdXJhbnRlIDcgbWVzZXMuIDxicj48L3A+PC9kaXY+PGRpdiBjbGFzcz0mIzM5O3ctMS0zJiMzOTs+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+RVNQQU5UQUxMT1BTPC9zcGFuPjwvYj48cCBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+QmxhbmNvIFJlc2VydmEuIE1hY2FiZXUgMTAwJSBmZXJtZW50YWRvIGR1cmFudGUgMSBhw7FvIGVuIGJhcnJpY2EgZGUgcm9ibGUgeSBwb3N0ZXJpb3IgY3JpYW56YSBlbiBib3RlbGxhIGR1cmFudGUgMTIgbWVzZXMgbcOtbmltby4gUGFyYSBsb3MgYW1hbnRlcyBkZSBsb3MgZ3JhbmRlcyBibGFuY29zLjxicj48L3A+PC9kaXY+PC9kaXY+In19LHsidHlwZSI6InctMS0xIGdjIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTIgaHMgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiJwYWRkaW5nLXJpZ2h0OiAyJTsiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvY2M2YWZiNDc0NGQ0NjE1ODQxMDUwNTQ2NjQyODI4ZTkuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJ3LTEtMiBocyAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6InBhZGRpbmctbGVmdDogMiU7IiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50L2IxMzVlZTc1M2NhNDdhNWM1NWVmMWE3YjEwZDExNzA2LmpwZyYjMzk7Pjxicj4ifX0seyJ0eXBlIjoidy0xLTEgZyIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6e319LHsidHlwZSI6InctMS0xIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEgaG0gaGwgaHhsIHB0LTcgcGItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PGI+VklOT1MgRC5PLiBQRU5FRMOIUzwvYj48L2gxPiJ9fSx7InR5cGUiOiJ3LTEtMSBobSBobCBoeGwgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC82OWMwYzM0MzRmNTVjZWJkZWRhMzc0NDZiNWNhOWY2YS5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0xIGhtIGhsIGh4bCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz5FbCBQZW5lZMOpcyBjb24gc3UgZ2VvZ3JhZmlhIGxpbWl0YWRhIHBvciBlbCBNYXIgeSBsYXMgbW9udGHDsWFzIGRlIE1vbnRzZXJyYXQgbm9zIHBlcm1pdGUgIGVsYWJvcmFyIHZpbm9zIGJsYW5jb3MgeSByb3NhZG9zIGRlIHVuYSAgZ3JhbiBlbGVnYW5jaWEuJm5ic3A7U29uIHZpbm9zIG1lZGl0ZXJyw6FuZW9zLCB2aW5vcyBkZSBzb2wsIHRvZG9zIGVsbG9zIGVjb2zDs2dpY29zLCBjb24gY2VydGlmaWNjacOzbiB2ZWdhbmEgeSB2ZW5kaW1pYWRvcyBhIG1hbm8uIFNvbG8gbGFzIHZhcmllZGFkZXMgbcOhcyBub2JsZXMgc2UgY29udmllcnRlbiBlbiB2aW5vcyBBR1VTVEkgVE9SRUxMTyBNQVRBPC9wPiJ9fSx7InR5cGUiOiJ3LTEtMSB3cy0xLTEgaG0gaGwgaHhsIHBiLTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEgaG0gaGwgaHhsIHBiLTUgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8Yj48c3BhbiBzdHlsZT0mIzM5O2NvbG9yOiByZ2IoMTg1LCAxNDYsIDI1KTsmIzM5Oz5YSUM8L3NwYW4+PC9iPjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz5WaW5vIGJsYW5jby4gVmFyaWVkYWQgeGFyZWwubG8gMTAwJS4gSm92ZW4gIHkgZnJlc2NvIHRpZW5lIHVuYSBmZXJtZW50YWNpw7NuIHkgY3JpYW56YSBlbiBsw61hcyBkdXJhbnRlIDUgbWVzZXM8L3A+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+WElDIFZFUk1FTEw8L3NwYW4+PC9iPjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz5Sb3NhZG8gbXV5IHBhbGlkby4gVmFyaWVkYWQgeGFyZWwubG8gdmVybWVsbC4gTWFjZXJhZG8gOCBob3JhcyBjb24gc3UgcGFydGljdWxhciBwaWVsIGNvbG9yIHJvc2EsIGNvbmp1Z2Egc3UgdG9uYWxpZGFkIHDDoWxpZGEsIGNvbiBlbCBjYXLDoWN0ZXIgZGUgbGEgeGFyZWwubG88L3A+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+WElDIFRSRVBBVDwvc3Bhbj48L2I+PHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7PlJvc2FkbyBpbnRlbnNvLCBjb24gdG9kb3MgbG9zIGFyb21hcyBkZSBmcnV0b3Mgcm9qb3MgdMOtcGljb3MgZGUgbGEgdmFyaWVkYWQgdHJlcGF0LiBGcmVzY28geSBhZnJ1dGFkbzwvcD4ifX0seyJ0eXBlIjoidy0xLTEgd3MtMS0xIGhtIGhsIGh4bCBwYi04ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50L2NjNmFmYjQ3NDRkNDYxNTg0MTA1MDU0NjY0MjgyOGU5LmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoidy0xLTEgd3MtMS0xIGhtIGhsIGh4bCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC9iMTM1ZWU3NTNjYTQ3YTVjNTVlZjFhN2IxMGQxMTcwNi5qcGcmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0xIHBiLTQiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fV0='),
(1360, 32, 'seo_resumen', ''),
(1361, 32, 'seo_checktitleonfreaturedimage', '0'),
(1362, 32, 'seo_customtitleonfreaturedimage', ''),
(1363, 32, 'seo_freaturedimage', ''),
(1364, 32, 'seo_noodp', '0'),
(1365, 32, 'seo_noydir', '0'),
(1366, 32, 'seo_nofollow', '0'),
(1367, 32, 'seo_noarchive', '0'),
(1368, 32, 'seo_keywords', ''),
(1369, 32, 'seo_description', ''),
(1370, 32, 'seo_customimage', ''),
(1503, 33, 'page_content', 'W3sidHlwZSI6InctMS0xIHB0LTQiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMiIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6e319LHsidHlwZSI6InctMS0yIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPkVMQUJPUkFDScOTTiBWSU5PUyBCQVNFPC9iPjwvaDE+In19LHsidHlwZSI6InctMS0xIGhtIGhsIGh4bCBwdC03ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGgxIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvODc5MjM4OWRkZGIxNDlkZmMxYTdmYzc5MjQ1YTdhOTQuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPjwvaDE+In19LHsidHlwZSI6InctMS0xIHBiLTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoibWMgdy0xLTIgd3MtMS0xIHBiLTYgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0mIzM5O3R4dEBqJiMzOTs+VW4gcHJlbnNhZG8gc3VhdmUgbm9zIHBlcm1pdGUgZXh0cmFlciBlbCBtb3N0byBmbG9yOiBzb2xvIHVuIDUwJSBzZXLDoSB2aW5vIGJhc2UgY2F2YS4gQ2FkYSB2YXJpZWRhZCBmZXJtZW50YSBlbiBkZXDDs3NpdG9zIGEgdGVtcGVyYXR1cmEgY29uc3RhbnRlIGRlIDE3IGdyYWRvcyB5IGNvbiBsZXZhZHVyYXMgcHJvcGlhcywgc2VsZWNjaW9uYWRhcyBtaWNyb2Jpb2zDs2dpY2FtZW50ZSBjYWRhIGHDsW8gYW50ZXMgZGUgbGEgY29zZWNoYSBwYXJhIHByZXNlcnZhciBlbCBjYXLDoWN0ZXIgYXV0w6ludGljbyBkZSBjYWRhIHZpbm8geSBkZSBlc3RlIG1vZG8gZXZpdGFyIHF1ZSBjdWFscXVpZXIgbGV2YWR1cmEgYXBvcnRlIHNhYm9yZXMgZm9yw6FuZW9zLjxicj48YnI+TG9zIHZpbm9zIHNlIHRyYXN2YXNhbiBwb3IgZGVjYW50YWNpw7NuIHkgbm8gc2UgdXRpbGl6YSBuaW5nw7puIGNsYXJpZmljYW50ZSBkZSBvcmlnZW4gYW5pbWFsLiBUb2RvcyBsb3Mgdmlub3MgdGllbmVuIGNlcnRpZmljYWNpw7NuIHZlZ2FuYSBwdWVzdG8gcXVlIHNvbiAxMDAlIHZlZ2V0YWxlcy48YnI+PGJyPlRyYW5zY3Vycmlkb3MgMyBtZXNlcyBkZXNkZSBsYSB2ZW5kaW1pYSwgbG9zIHZpbm9zIGVzdMOhbiBsaXN0b3MgcGFyYSBlbCBjdXBhZ2UuPC9wPiJ9fSx7InR5cGUiOiJtYyB3LTEtMiBocyB3cy0xLTEgcGItNiAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBjJiMzOTs+PGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50Lzg3OTIzODlkZGRiMTQ5ZGZjMWE3ZmM3OTI0NWE3YTk0LmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj48L2gxPiJ9fSx7InR5cGUiOiJ3LTEtMSB3cy0xLTEgaG0gaGwgaHhsIHBiLTcgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPkNVUEFHRVM8L2I+PC9oMT4ifX0seyJ0eXBlIjoidy0xLTIgaHMgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDE+PGI+Q1VQQUdFUzwvYj48L2gxPjxicj4ifX0seyJ0eXBlIjoidy0xLTIgaHMgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEgd3MtMS0xIHBiLTRAcyBwbC1uQHMgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiJ3aWR0aDogNTIlIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGgxIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvNzU1OTE5MzVhNjI3MzdhMGE5OGNhODkyZWY2NTAyMDkuanBnJiMzOTsgY2xhc3M9JiMzOTtlJiMzOTs+PGJyPjwvaDE+In19LHsidHlwZSI6InctMS0xIGhzICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoid2lkdGg6IDQ4JTtwYWRkaW5nLWxlZnQ6IDUlOyIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz5FcyBlbCBtb21lbnRvIGVuIHF1ZSBsb3Mgdmlub3Mgc2UgY29tYmluYW46IExhIGV4cGVyaWVuY2lhIGRlbCBlbsOzbG9nbyBlcyBlc2VuY2lhbCBwYXJhIGRldGVybWluYXIgZW4gY2FkYSB2ZW5kaW1pYSBsYSBwcm9wb3JjacOzbiBkZSBNYWNhYmVvLCBYYXJlbMK3bG8geSBQYXJlbGxhZGE6IGVzIGVsIOKAnGN1cGFnZeKAnSBxdWUgZGV0ZXJtaW5hIGPDs21vIHNlcsOhIGVsIGNhdmEuPGJyPjxicj5FbCBjdXBhZ2UgZGUgbG9zIHZpbm9zIGJhc2Ugc2UgZW1ib3RlbGxhIHkgc2UgbGUgYcOxYWRlbiBsZXZhZHVyYXMgeSBhesO6Y2FyIHBhcmEgcXVlIGNvbWllbmNlIGxhIHNlZ3VuZGEgZmVybWVudGFjacOzbiBlbiBjYWRhIGJvdGVsbGEuIEVsIHRhcMOzbiBoZXJtw6l0aWNvIG9icmFyw6EgZWwgbWlsYWdybzogZW4gZWwgc2lsZW5jaW8gZGUgbGFzIGNhdmFzLCBhIHRlbXBlcmF0dXJhIGNvbnN0YW50ZSBkZSAxNCBncmFkb3MsIGVsIHZpbm8gdHJhbnF1aWxvIHNlIGlyw6EgdHJhbnNmb3JtYW5kbyBlbiBlc3B1bW9zby48L3A+PGJyPjxicj48cD48YnI+PC9wPjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC8zYTZkODkwMzYyNjQ3MDNmOWUwNjUyMWFhNTExZTZmNS5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0xIHdzLTEtMSBobSBobCBoeGwgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0mIzM5O3R4dEBqJiMzOTsgc3R5bGU9JiMzOTt0ZXh0LWFsaWduOiBqdXN0aWZ5OyYjMzk7PkVzIGVsIG1vbWVudG8gZW4gcXVlIGxvcyB2aW5vcyBzZSBjb21iaW5hbjogTGEgZXhwZXJpZW5jaWEgZGVsIGVuw7Nsb2dvIGVzIGVzZW5jaWFsIHBhcmEgZGV0ZXJtaW5hciBlbiBjYWRhIHZlbmRpbWlhIGxhIHByb3BvcmNpw7NuIGRlIE1hY2FiZW8sIFhhcmVswrdsbyB5IFBhcmVsbGFkYTogZXMgZWwg4oCcY3VwYWdl4oCdICBxdWUgZGV0ZXJtaW5hIGPDs21vIHNlcsOhIGVsIGNhdmEuPC9wPjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz5FbCBjdXBhZ2UgZGUgbG9zIHZpbm9zIGJhc2Ugc2UgZW1ib3RlbGxhIHkgc2UgbGUgYcOxYWRlbiBsZXZhZHVyYXMgeSBhesO6Y2FyIHBhcmEgcXVlIGNvbWllbmNlIGxhIHNlZ3VuZGEgZmVybWVudGFjacOzbiBlbiBjYWRhIGJvdGVsbGEuIEVsIHRhcMOzbiBoZXJtw6l0aWNvIG9icmFyw6EgZWwgbWlsYWdybzogZW4gZWwgc2lsZW5jaW8gZGUgbGFzIGNhdmFzLCBhIHRlbXBlcmF0dXJhIGNvbnN0YW50ZSBkZSAxNCBncmFkb3MsIGVsIHZpbm8gdHJhbnF1aWxvIHNlIGlyw6EgdHJhbnNmb3JtYW5kbyBlbiBlc3B1bW9zby48L3A+PGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50LzNhNmQ4OTAzNjI2NDcwM2Y5ZTA2NTIxYWE1MTFlNmY1LmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj48cCBjbGFzcz0mIzM5O3R4dEBqJiMzOTsgc3R5bGU9JiMzOTt0ZXh0LWFsaWduOiBqdXN0aWZ5OyYjMzk7PjwvcD4ifX0seyJ0eXBlIjoidy0xLTEgcGItNCIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6e319XQ=='),
(1504, 33, 'seo_resumen', ''),
(1505, 33, 'seo_checktitleonfreaturedimage', '0'),
(1506, 33, 'seo_customtitleonfreaturedimage', ''),
(1507, 33, 'seo_freaturedimage', ''),
(1508, 33, 'seo_noodp', '0'),
(1509, 33, 'seo_noydir', '0'),
(1510, 33, 'seo_nofollow', '0'),
(1511, 33, 'seo_noarchive', '0'),
(1512, 33, 'seo_keywords', ''),
(1513, 33, 'seo_description', ''),
(1514, 33, 'seo_customimage', ''),
(1528, 34, 'page_content', 'W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPkNVUEFKRVM8L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwYi0zICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgc3R5bGU9JiMzOTt0ZXh0LWFsaWduOiBqdXN0aWZ5OyYjMzk7PkVzIGVsIG1vbWVudG8gZW4gcXVlIGxvcyB2aW5vcyBzZSBjb21iaW5hbjogTGEgZXhwZXJpZW5jaWEgZGVsIGVuw7Nsb2dvIGVzIGVzZW5jaWFsIHBhcmEgZGV0ZXJtaW5hciBlbiBjYWRhIHZlbmRpbWlhIGxhIHByb3BvcmNpw7NuIGRlIE1hY2FiZW8sIFhhcmVswrdsbyB5IFBhcmVsbGFkYTogZXMgZWwg4oCcY3VwYWdl4oCdICBxdWUgZGV0ZXJtaW5hIGVuIGVzdGUgbW9tZW50bywgZWwgZnV0dXJvIGRlbCBjYXZhLjwvcD48aDI+TUVUT0RPIFRSQURJQ0lPTkFMIEZFUk1FTlRBQ0lPTiBFTiBCT1RFTExBPC9oMj48cCBzdHlsZT0mIzM5O3RleHQtYWxpZ246IGp1c3RpZnk7JiMzOTs+RWwgY3VwYWdlIHNlbGVjY2lvbmFkbyBkZSBsb3Mgdmlub3MgYmFzZSwgc2UgZW1ib3RlbGxhIHkgc2UgYcOxYWRlbiBsZXZhZHVyYXMgeSBhesO6Y2FyIHBhcmEgcXVlIGVsIHZpbm8gdnVlbHZhIGEgZmVybWVudGFyIGRlbnRybyBkZSBjYWRhIGJvdGVsbGEgRWwgdGFww7NuIGhlcm3DqXRpY28gcmVhbGl6YXLDoSBlbCBtaWxhZ3JvOiBlbiBlbCBzaWxlbmNpbyBkZSBsYXMgY2F2YXMgLCBhIHRlbXBlcmF0dXJhIGNvbnN0YW50ZSBkZSAxNCBncmFkb3MsIGVsIHZpbm8gdHJhbnF1aWxvIHNlIGlyw6EgdHJhbnNmb3JtYW5kbyBlbiBlc3B1bW9zbywgY29uIGZpbmFzIGJ1cmJ1amFzIHF1ZSBsZW50YW1lbnRlIGFkcXVpcmlyw6FuIGNvbiBsb3MgYcOxb3MgZWwg4oCcYm91cXVldOKAnSBjYXJhY3RlcsOtc3RpY28gZGUgY2FkYSBhw7FhZGEuPC9wPjxwIHN0eWxlPSYjMzk7dGV4dC1hbGlnbjoganVzdGlmeTsmIzM5Oz5Bc8OtIHBlcm1hbmVjZXLDoW4gbGFyZ29zIGHDsW9zIGVuIGxvcyBxdWUgbGFzIGxldmFkdXJhcyB2YW4gZGVzcHJlbmRpZW5kbyBhcm9tYXMgdMOtcGljb3MgZGUgY3JpYW56YSBjb21vIGJvbGxlcmlhLCBmcnV0b3Mgc2Vjb3MgeSB0b3N0YWRvcyB5IHRyYWJhamFuZG8gZW4gY2FkYSBib3RlbGxhIHBhcmEgY29uc2VndWlyIGVsIG1lam9yIGRlIGxvcyBjYXZhcy4gPC9wPjxicj48YnI+In19LHsidHlwZSI6InctMS0xIHBiLTYiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fV0='),
(1529, 34, 'seo_resumen', ''),
(1530, 34, 'seo_checktitleonfreaturedimage', '0'),
(1531, 34, 'seo_customtitleonfreaturedimage', ''),
(1532, 34, 'seo_freaturedimage', ''),
(1533, 34, 'seo_noodp', '0'),
(1534, 34, 'seo_noydir', '0'),
(1535, 34, 'seo_nofollow', '0'),
(1536, 34, 'seo_noarchive', '0'),
(1537, 34, 'seo_keywords', ''),
(1538, 34, 'seo_description', ''),
(1539, 34, 'seo_customimage', ''),
(1708, 27, 'gallery_id', '26'),
(1781, 28, 'gallery_id', '28'),
(1782, 8, 'page_content', 'ZmFsc2U='),
(1783, 8, 'seo_resumen', ''),
(1784, 8, 'seo_checktitleonfreaturedimage', '0'),
(1785, 8, 'seo_customtitleonfreaturedimage', ''),
(1786, 8, 'seo_freaturedimage', ''),
(1787, 8, 'seo_noodp', '0'),
(1788, 8, 'seo_noydir', '0'),
(1789, 8, 'seo_nofollow', '0'),
(1790, 8, 'seo_noarchive', '0'),
(1791, 8, 'seo_keywords', ''),
(1792, 8, 'seo_description', ''),
(1793, 8, 'seo_customimage', ''),
(2358, 35, 'page_content', 'W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9J3R4dEBjJz48Yj5QUkVNSU9TIEVTUEFOVEFMTE9QUzwvYj48L2gxPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9J3R4dEBjJz48aW1nIGFsdD0nJyBzcmM9J2NvbnRlbnQvM2IzMDA1NDc1NzcyMjJhOTU0OTIxZGY5NDQ3YmNjNTEuanBnJz48L3A+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiIyMDE5IE9STyBQcmVtaW9zIE1vbm8gVmlubyBBcHRpw6AgMjAxNyAuIENvbmN1cnMgTmFjaW9uYWwgTW9ub3ZhcmlldGFscy4gT3IgY2F0ZWdvcsOtYSB2aW5zIGJsYW5jcyBjcmlhbsOnYSBhbWIgZnVzdGEuPGJyPjxicj4yMDE5IEJyb256ZSBDb25jb3VycyBBbXBob3JlIEFwdGnDoCAyMDE3LiBDb25jb3VycyBJbnRlcm5hdGlvbmFsIHZpbnMgQmlvbG9naXF1ZXMgJiBlbiBjb252ZXJzaW9uLjxicj48YnI+MjAxOSBDSVZBUyBkZSBPUk8gLSBQcmVtaW9zIEFrYXRhdmlubyA5MyBwdW50b3MgQXB0acOgIDIwMTcuIENvbmN1cnMgSW50ZXJuYWNpb25hbCBTdW1pbGxlcnMgZOKAmUVzcGFueWE8YnI+PGJyPiJ9fV0='),
(2359, 35, 'seo_resumen', ''),
(2360, 35, 'seo_checktitleonfreaturedimage', '0'),
(2361, 35, 'seo_customtitleonfreaturedimage', ''),
(2362, 35, 'seo_freaturedimage', ''),
(2363, 35, 'seo_noodp', '0'),
(2364, 35, 'seo_noydir', '0'),
(2365, 35, 'seo_nofollow', '0'),
(2366, 35, 'seo_noarchive', '0'),
(2367, 35, 'seo_keywords', ''),
(2368, 35, 'seo_description', ''),
(2369, 35, 'seo_customimage', ''),
(2468, 36, 'page_content', 'W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9J3R4dEBjJz48Yj5QUkVNSU9TIEJBUlJJQ0E8L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwICIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9J3R4dEBjJz48aW1nIGFsdD0nJyBzcmM9J2NvbnRlbnQvZmI0MjYzN2M5M2RmYjc5YzdlMThjMjcxNzIyYTYwNWQuanBnJyBjbGFzcz0nbWMnPjwvcD4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxwPjIwMjAgR1VJQSBERSBWSU5TIERFIENBVEFMVU5ZQSA5LDcyIHAuIEJhcnJpY2EgR3JhbiBSZXNlcnZhIDIwMTQ8L3A+PHA+MjAxOSA1MCBHcmVhdCBDYXZhcyBHT0xEIEJhcnJpY2EgYcOxYWRhIDIwMTI8YnI+MjAxOSBHdcOtYSBQZcOxw61uIDkzIHB1bnRvcyBCYXJyaWNhIGHDsWFkYSAyMDEyPGJyPjIwMTkgQ1VBRFJPIERFIEhPTk9SIEd1w61hIFNpbiBNYWxhIFV2YSBCYXJyaWNhIGHDsWFkYSAyMDE0PGJyPjIwMTkgQ0FUQVZJTlVNIFdPUkxEIFdJTkUgQ09NUEVUSVRJT04gT1IgQmFycmljYSAyMDE0PGJyPjIwMTkgQkVTVCBJTiBDTEFTUyBHdWlhIFdpbmUgdXAgQmFycmljYSAyMDE0PGJyPjIwMTkgQnJvbnplIERlY2FudGVyIDIwMTkgQmFycmljYSAyMDE0PGJyPjIwMTkgQ0lWQVMgZGUgT1JPIC0gUHJlbWlvcyBBa2F0YXZpbm8gOTQgcHVudHMgQmFycmljYSAyMDE0PC9wPjxwPjIwMTggQkFDQ0hVUy4gT1IgQmFycmljYSBHcmFuIFJlc2VydmEgMjAxNDxicj4yMDE4IElJIENPTkNVUlNPIElCRVJPQU1FUklDQU5PIFZJTk9TIEVTUFVNT1NPUyAuIEJhcnJpY2EgQnVyYnVqYSBkZSBvcm8gYcOxYWRhIDIwMTE8YnI+MjAxOCBDQVRBVklOVU0gV09STEQgV0lORSBDT01QRVRJVElPTiBPUiBCYXJyaWNhIDIwMTI8YnI+MjAxOCBXSU5FIFBMRUFTVVJFUyDCoCBCYXJyaWNhIDIwMTIuIEdvbGQgU2NvcmUgOTY8YnI+MjAxOCBBRVBFViBNZWpvciBFc3B1bW9zbyBkZWwgQcOxby4gQmFycmljYSBhw7FhZGEgMjAxNDxicj4yMDE4IERlY2FudGVyIFNJTFZFUi4gQmFycmljYSBhw7FhZGEgMjAxNDwvcD48cD4yMDE3IE1FIEdVU1RBIEJhcnJpY2EgT1JPIGHDsWFkYSAyMDExPGJyPjIwMTcgSSBDT05DVVJTTyBJQkVST0FNRVJJQ0FOTyBWSU5PUyBFU1BVTU9TT1MgQmFycmljYSAyMDExICBPUk8gPGJyPjIwMTcgQUVQRVYgQmFycmljYSBNRUpPUiBFU1BVTU9TTyBERUwgQcORTyBhw7FhZGEgMjAxMTxicj4yMDE3IENIQU1QSU9OIFdJTkVTIEJhcnJpY2EgT1IgYcOxYWRhIDIwMTE8YnI+MjAxNyBDSVZBUyBCYXJyaWNhIE9SIGHDsWFkYSAyMDEwPGJyPjIwMTcgTU9OT1ZJTk8gQmFycmljYSBPUiBhw7FhZGEgMjAxMTxicj4yMDE3IENBVEFWSU5VTSBXT1JMRCBXSU5FIENPTVBFVElUSU9OIEJhcnJpY2EgT1IgYcOxYWRhIDIwMTI8L3A+PHA+MjAxNiBQRcORSU4gOTNwLiBCYXJyaWNhIEdyYW4gUmVzZXJ2YSAyMDExPGJyPjIwMTYgVklOUyBERSBDQVRBTFVOWUEgOTcsNSBwLiBCYXJyaWNhIEdyYW4gUmVzZXJ2YSAyMDExPC9wPjxwPjIwMTUgVml2aW5vIFduZSBTdHVsZSB0b3AgMTAgQmFycmljYSBHcmFuIFJlc2VydmEgMjAwODwvcD48cD4yMDE0IFBFw5FJTiA5MiBwLiBCYXJyaWNhIEdyYW4gUmVzZXJ2YSAyMDA4PC9wPjxwPjIwMTMgREVDQU5URVIgQnJvbmNlIEJhcnJpY2EgR3JhbiBSZXNlcnZhIDIwMDg8YnI+MjAxMyBQQVJLRVIgOTIgcC4gQmFycmljYSBHcmFuIFJlc2VydmEgMjAwNTwvcD48cD5QQVJLRVIgOTIgUC4gQmFycmljYSBHcmFuIFJlc3NlcnZhIDIwMDU8YnI+UEFSS0VSIDkyIHAuIEJhcnJpY2EgR3JhbiBSZXNlcnZhIDIwMDc8YnI+UEFSS0VSIDkzIHAgQmFycmljYSBHcmFuIFJlc2VydmEgMjAwODxicj5QQVJLRVIgOTErIHAuIEJhcnJpY2EgR3JhbiBSZXNlcnZhIDIwMTA8L3A+In19XQ=='),
(2469, 36, 'seo_resumen', ''),
(2470, 36, 'seo_checktitleonfreaturedimage', '0'),
(2471, 36, 'seo_customtitleonfreaturedimage', ''),
(2472, 36, 'seo_freaturedimage', ''),
(2473, 36, 'seo_noodp', '0'),
(2474, 36, 'seo_noydir', '0'),
(2475, 36, 'seo_nofollow', '0'),
(2476, 36, 'seo_noarchive', '0'),
(2477, 36, 'seo_keywords', ''),
(2478, 36, 'seo_description', ''),
(2479, 36, 'seo_customimage', ''),
(2756, 37, 'page_content', 'W3sidHlwZSI6InctMS0xIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9J3R4dEBjJz48Yj5QUkVNSU9TIEtSSVBUQTwvYj48L2gxPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cCBjbGFzcz0ndHh0QGMnPjxpbWcgYWx0PScnIHNyYz0nY29udGVudC80Y2U0ZjgzNmQwMWNlZTRlMDIxMGIxZDY2MjI4NGZhNS5qcGcnIGNsYXNzPSdtYyc+PC9wPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cD4yMDE5IEd1w61hIFBlw7FpbiA5NCBwLiBLcmlwdGEgNDAgYW5pdmVyc2FyaSBhw7FhZGEgMjAwNzxicj4yMDE5IEJBQ0NIVVMgT1IgS3JpcHRhIEdyYW4gUmVzZXJ2YSAyMDEwPGJyPjIwMTkgVklWSU5PIEJyb256ZSBUT1AgV0lORSBTUEFOSVNIIENBVkEgS3JpcHRhIEdyYW4gUmVzZXJ2YSAyMDA4PGJyPjIwMTkgQ0lOVkUgT1JPIEtyaXB0YSBHcmFuIFJlc2VydmEgMjAxMDxicj4yMDE5IEJyb256ZSBEZWNhbnRlciBLcmlwdGEgMjAxMDxicj4yMDE5IEdSQU4gQ0lWQVMgZGUgT1JPIC0gUHJlbWlvcyBBa2F0YXZpbm8gOTUuNSBwdW50cyBLcmlwdGEgMjAxMCA8YnI+MjAxOSBHUkFOIENJVkFTIGRlIE9STyDigJMgUHJlbWlvcyBBa2F0YXZpbm8gOTYgcHVudHMgS3JpcHRhIDIwMDcgPC9wPjxicj48cD4yMDE4IERFQ0FOVEVSIEdPTEQgS3JpcHRhIDQwIGFuaXZlcnNhcmkgYcOxYWRhIDIwMDc8YnI+MjAxOCBDSU5WRSBPUk8gS3JpcHRhIDIwMDc8YnI+MjAxOCBHT0xEIENJTlZFIEtyaXB0YSA0MCBhbml2ZXJzYXJpIGHDsWFkYSAyMDA3PGJyPjIwMTggVklWSU5PIC4gVE9QIFdJTkUgU1BBTklTSCBDQVZBIEtyaXB0YSA0MCBhbml2ZXJzYXJpIGHDsWFkYSAyMDA3PGJyPjIwMTggV0lORSBFTlRIVVNJQVNUIENob2ljZSBFZGl0b3IgOTMgcC4gS3JpcHRhIDQwIGFuLiBBw7FhZGEgMjAwNzxicj4yMDE4IEFLQVRBVklOTyBUT1AgNyBNZWpvcmVzIGV0aXF1ZXRhcyB5IGJvdGVsbGFzLiBLUklQVEEgPGJyPjIwMTggV0lORSBQTEVBU1VSRVMgS1JJUFRBIDIwMDcuU2lsdmVyIFNjb3JlIDk0PGJyPjIwMTggQUVQRVYgTWVqb3IgRXNwdW1vc28gZGVsIEHDsW8gYcOxYWRhIDIwMDg8YnI+PGJyPjwvcD48cD4yMDE3IFRvcCBXaW5lIEVudGh1c2lhc3QgOTAgcC4gQcOxYWRhIDIwMDg8YnI+MjAxNyBDSU5WRSBPUk8gS3JpcHRhIEdyYW4gQcOxYWRhIDIwMDY8YnI+MjAxNyBQYXJrZXIgOTIgcC4gQcOxYWRhIDIwMDggPGJyPjIwMTcgREVDQU5URVIgUGxhdGludW0gQmVzdCBDYXZhIDk1IHAuIEdyYW4gQcOxYWRhIDIwMDY8YnI+MjAxNyBPUk8gQUtBVEFWSU5PIEdyYW4gQcOxYWRhIDIwMDYgKDM1IHN1bWlsbGVyZXMgZGUgRXNwYcOxYSkgPC9wPjxicj48cD4yMDE2IFBhcmtlciA5MyBwb2ludHMgR3JhbiBBw7FhZGEgMjAwNjxicj4yMDE2IE9STyBDSU5WRSAuIEHDsWFkYSAyMDA4PGJyPjIwMTYgT1JPIEFLQVRBVklOTyBDSVZBUyAuIEHDsWFkYSAyMDA4IChDb25jdXJzbyBJbi4gU3VtaWxsZXJlcyBFc3ApPGJyPjIwMTYgR29sZCA1MCBHcmVhdCBDYXZhczwvcD48YnI+PHA+MjAxNSBWSVZJTk8gbsK6IDEgU3BhbmlzaCBDYXZhLiBBw7FhZGEgMjAwNzxicj4yMDE1IERpYW1hbnRlIFByZW1pb3MgVmlubyB5IE11amVyIDxicj4yMDE1IE1lam9yIFZpbm8gZXNwdW1vc28gQUVQRVYgQcOxYWRhIDIwMDg8L3A+PGJyPjxwPjIwMTQgVklWSU5PIE1lam9yIHZpbm8gdm90IHggOCBtaWxsb25lcyBjb25zdW1pZG9yZXMgZGVsIG11bmRvLiBLIDIwMDcgIDxicj4yMDE0IE1lam9yIEVzcHVtb3NvIEFFUEVWPGJyPjIwMTQgR09MRCA5MyBwLiBXSU5FIFVQIC4gQcOxYWRhIDIwMDc8YnI+MjAxNCBPUk8gQ0lOVkUgKENvbmN1cnNvIEludGVybmFjaW9uYWwgZGUgVmlub3MpLiBBw7FhZGEgMjAwNzwvcD48YnI+PHA+MjAxMyBWSU5BUkkgROKAmU9SIE1pbGxvciBFc2N1bcOzcyBHcmFuIFJlc2VydmEgUHJlbWl1bS4gQcOxYWRhIDIwMDc8YnI+MjAxMyBWSU5BUkkgQlJPTlpFIGVzcGVjaWFsIGRlIGxhIERPIENhdmEuIEHDsWFkYSAyMDA3PGJyPjIwMTMgUHJlbWlvIFJJVFogYWwgdmlubyBtw6FzIHZvdGFkbyDCoCDCoCDCoCDCoCDCoCA8YnI+MjAxMyBNZWpvciBlc3B1bW9zbyBBRVBFVjwvcD48YnI+PHA+MjAxMiBERUNBTlRFUiAuIEJlc3QgV2luZS4gQnJvbnplIEHDsWFkYSAyMDA2ICDCoCA8YnI+MjAxMiBQcmVtaW8gUklUWiBhbCB2aW5vIG3DoXMgdm90YWRvIDwvcD48YnI+PHA+MjAxMSBQQVJLRVIgOTQgcG9pbnRzIGHDsWFkYSAyMDAzPGJyPjIwMTEgUEFSS0VSIDkzIHBvaW50cyBhw7FhZGEgMjAwNTxicj4yMDExIFByZW1pbyBSSVRaIGFsIHZpbm8gbcOhcyB2b3RhZG8gQcOxYWRhIDIwMDY8YnI+MjAxMSBNZWpvciBlc3B1bW9zbyBBRVBFVi4gQcOxYWRhIDIwMDY8L3A+PHA+MjAwOSBQQVJLRVIgOTQgcG9pbnRzIGHDsWFkYSAyMDAzPGJyPjxicj4xOTkwIENvbmN1cnNvIE5hY2lvbmFsIGV0aXF1ZXRhcyBkZSBjYXZhLiBQcmVtaW8gbWVqb3IgZXRpcXVldGEgZGVsIGHDsW88YnI+PGJyPjE5ODMgRGlwbG9tZSBk4oCZSG9ubmV1ciBkZSBsYSAyOWUgZm9pcmUgaW50ZXJuYXRpb25hbCB2aXRpLXZpbmljb2xlIExqdWJpamFuYS4gQ3JpcHRhIDE5ODA8YnI+PGJyPjE5ODQgR3JhbmQgRGlwbG9tZSBk4oCZSG9ubmV1ciBldCBNZWRhaWxsZSBk4oCZb3IgLiBWZSBDb25jb3VycyBJbnRlcm5hdGlvbmFsIGRlcyBWaW5zIGRlIEJyYXRpc2xhdmEgKE9mZmljZSBJbnRlcm5hdGlvbmFsIGRlIGxhIFZpZ25lIGV0IGR1IFZpbik8YnI+PGJyPjE5ODUgTWVkYWlsbGUgZOKAmU9yICAyM2UgU8OpbGVjdGlvbiBNb25kaWFsZSBkZXMgVmlucy4gTGlzYm9ubmUgLiBJbnN0aXR1dCBJbnRlcm5hdGlvbmFsIFBvdXIgIGxlcyBTw6lsZWN0aW9ucyBkZSBsYSBRdWFsaXTDqTxicj48YnI+RWwgMTk4OCBOT1JUSCBBTUVSSUNBYFMgSU5URVJOQVRJT05BTCBXSU5FIENPTVBFVElUSU9OLiBOZXcgWW9yayDigJMgVG9yb250byAxOTkyLiBJbnRlcnZpbiBNZWRhbCBXaW5uZXIgQ3JpcHRhIDE5ODwvcD4ifX1d'),
(2757, 37, 'seo_resumen', ''),
(2758, 37, 'seo_checktitleonfreaturedimage', '0'),
(2759, 37, 'seo_customtitleonfreaturedimage', ''),
(2760, 37, 'seo_freaturedimage', ''),
(2761, 37, 'seo_noodp', '0'),
(2762, 37, 'seo_noydir', '0'),
(2763, 37, 'seo_nofollow', '0'),
(2764, 37, 'seo_noarchive', '0'),
(2765, 37, 'seo_keywords', ''),
(2766, 37, 'seo_description', ''),
(2767, 37, 'seo_customimage', ''),
(3632, 38, 'page_content', 'W3sidHlwZSI6InctMS0xIHBiLTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEgcGItMyBwYi03QHMgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAYyYjMzk7PjxiPjIwMTktMjAyMDwvYj48L2gxPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHBiLTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAbCYjMzk7PjxiPjxzcGFuIHN0eWxlPSYjMzk7Y29sb3I6IHJnYigxODUsIDE0NiwgMjUpOyYjMzk7PjIwMjA8L3NwYW4+PC9iPjwvaDE+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cD5CQVJSSUNBIEdSQU4gUkVTRVJWQSAyMDE0IC0gR3VpYSBWaW5zIGRlIENhdGFsdW55YSA5LDcycCA8YnI+S1JJUFRBIEdSQU4gUkVTRVJWQSAyMDExIC0gTWVqb3IgRXNwdW1vc28gR3VpYSBHb3VybWV0cyA8YnI+PC9wPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTQgcGItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBsJiMzOTs+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+MjAxOTwvc3Bhbj48L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IkVTUEFOVEFMTE9QUyAyMDE3IC0gT1JPIFByZW1pb3MgTW9ubyBWaW5vIDxicj5FU1BBTlRBTExPUFMgMjAxNyAtIE9STyBDb25jdXJzIE5hY2lvbmFsIE1vbm92YXJpZXRhbHM8YnI+RVNQQU5UQUxMT1BTIDIwMTcgLSBCcm9uemUgQ29uY291cnMgQW1waG9yZS4gQ29uY291cnMgSW50ZXJuYXRpb25hbCB2aW5zIEJpb2xvZ2lxdWVzICZhbXA7IGVuIGNvbnZlcnNpb248YnI+RVNQQU5UQUxMT1BTIDIwMTcgQ0lWQVMgZGUgT1JPIC0gUHJlbWlvcyBBa2F0YXZpbm8sIENvbmN1cnMgSW50ZXJuYWNpb25hbCBTdW1pbGxlcnMgZOKAmUVzcGFueWE8YnI+QkFSUklDQSBHUkFOIFJFU0VSVkEgMjAxMiDigJMgR09MRCA1MCBHcmVhdCBDYXZhcyA8YnI+QkFSUklDQSBHUkFOIFJFU0VSVkEgMjAxMiAtIEd1w61hIFBlw7HDrW4gOTNwPGJyPkJBUlJJQ0EgR1JBTiBSRVNFUlZBIDIwMTQgLSBDVUFEUk8gREUgSE9OT1IgR3XDrWEgU2luIE1hbGEgVXZhIDxicj5CQVJSSUNBIEdSQU4gUkVTRVJWQSAyMDE0IOKAkyBPUk8gQ0FUQVZJTlVNIFdPUkxEIFdJTkUgQ09NUEVUSVRJT04gPGJyPkJBUlJJQ0EgR1JBTiBSRVNFUlZBIDIwMTQgLSBCRVNUIElOIENMQVNTIEd1aWEgV2luZSBVcDxicj5CQVJSSUNBIEdSQU4gUkVTRVJWQSAyMDE0IC1Ccm9uemUgRGVjYW50ZXIgMjAxOSA8YnI+QkFSUklDQSBHUkFOIFJFU0VSVkEgMjAxNCAtIENJVkFTIGRlIE9STyAtIFByZW1pb3MgQWthdGF2aW5vIDk0cDxicj5LUklQVFMgNDAgQU5JVkVSU0FSSSBBw5FBREEgMjAwNyAtIEd1w61hIFBlw7FpbiA5NHA8YnI+S1JJUFRBIEdSQU4gUkVTRVJWQSAyMDEwIOKAk0JBQ0NIVVMgT1I8YnI+S1JJUFRBIEdSQU4gUkVTRVJWQSAyMDA4IC0gVklWSU5PIEJyb256ZSBUT1AgV0lORSBTUEFOSVNIIENBVkEgPGJyPktSSVBUQSBHUkFOIFJFU0VSVkEgMjAxMCAtIENJTlZFIE9STyA8YnI+S1JJUFRBIEdSQU4gUkVTRVJWQSAyMDEwIC0gQnJvbnplIERlY2FudGVyIDxicj5LUklQVEEgR1JBTiBSRVNFUlZBIDIwMTAgLSBHUkFOIENJVkFTIGRlIE9STyAtIFByZW1pb3MgQWthdGF2aW5vPGJyPktSSVBUQSBHUkFOIFJFU0VSVkEgMjAwNyAtIEdSQU4gQ0lWQVMgZGUgT1JPIOKAkyBQcmVtaW9zIEFrYXRhdmlubyJ9fSx7InR5cGUiOiJ3LTEtMSBwYi00IiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX1d'),
(3633, 38, 'seo_resumen', ''),
(3634, 38, 'seo_checktitleonfreaturedimage', '0'),
(3635, 38, 'seo_customtitleonfreaturedimage', ''),
(3636, 38, 'seo_freaturedimage', ''),
(3637, 38, 'seo_noodp', '0'),
(3638, 38, 'seo_noydir', '0'),
(3639, 38, 'seo_nofollow', '0'),
(3640, 38, 'seo_noarchive', '0'),
(3641, 38, 'seo_keywords', ''),
(3642, 38, 'seo_description', ''),
(3643, 38, 'seo_customimage', '');
INSERT INTO `pages_meta` (`id`, `p_id`, `meta_key`, `meta_value`) VALUES
(3764, 39, 'page_content', 'W3sidHlwZSI6InctMS0xIHBiLTQiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBwYi00ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6e319LHsidHlwZSI6InctMS0xIHBiLTMgcGItN0BzICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGgxIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48Yj5ISVNUw5NSSUNPPC9iPjwvaDE+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcGItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBsJiMzOTs+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+MjAxODwvc3Bhbj48L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IkJBUlJJQ0EgR1JBTiBSRVNFUlZBIDIwMTQg4oCTIEJBQ0NIVVMgT1JPPGJyPkJBUlJJQ0EgR1JBTiBSRVNFUlZBIDIwMTEg4oCTIEJ1cmJ1amEgZGUgT3JvIElJIENPTkNVUlNPIElCRVJPQU1FUklDQU5PIFZJTk9TIEVTUFVNT1NPUzxicj5CQVJSSUNBIEdSQU4gUkVTRVJWQSAyMDEyIC0gT1JPIENhdGF2aW51bSBXb3JsZCBXaW5lIENvbXBldGl0aW9uIDxicj5CQVJSSUNBIEdSQU4gUkVTRVJWQSAyMDEyIC0gV0lORSBQTEVBU1VSRVMuIEdvbGQgU2NvcmUgOTY8YnI+QkFSUklDQSBHUkFOIFJFU0VSVkEgIDIwMTQgLSBBRVBFViBNZWpvciBFc3B1bW9zbyBkZWwgQcOxbzxicj5CQVJSSUNBIEdSQU4gUkVTRVJWQSAgMjAxNCAtIERlY2FudGVyIFNJTFZFUjxicj5LUklQVEEgNDAgQU5JVkVSU0FSSSAyMDA3IERFQ0FOVEVSIEdPTEQgPGJyPktSSVBUQSA0MCBBTklWRVJTQVJJIDIwMDcg4oCTIE9STyBDSU5WRSA8YnI+S1JJUFRBIDQwIEFOSVZFUlNBUkkgMjAwNyAtIFZJVklOTy4gVE9QIFdJTkUgU1BBTklTSCBDQVZBIDxicj5LUklQVEEgNDAgQU5JVkVSU0FSSSAyMDA3IC0gV0lORSBFTlRIVVNJQVNUIENob2ljZSBFZGl0b3IgOTNwPGJyPktSSVBUQSBHUkFOIFJFU0VSVkEgMjAxMCAtIEFLQVRBVklOTyBUT1AgNyBNZWpvcmVzIGV0aXF1ZXRhcyB5IGJvdGVsbGFzLiA8YnI+S1JJUFRBIDQwIEFOSVZFUlNBUkkgMjAwNyAtIFdJTkUgUExFQVNVUkVTLiBTaWx2ZXIgU2NvcmUgOTQ8YnI+S1JJUFRBIEdSQU4gUkVTRVJWQSAyMDA4IC0gQUVQRVYgTWVqb3IgRXNwdW1vc28gZGVsIEHDsW8ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC00IHBiLTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAbCYjMzk7PjxiPjxzcGFuIHN0eWxlPSYjMzk7Y29sb3I6IHJnYigxODUsIDE0NiwgMjUpOyYjMzk7PjIwMTc8L3NwYW4+PC9iPjwvaDE+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiJLUklQVEEgR1JBTiBSRVNFUlZBIDIwMDggLSBUb3AgV2luZSBFbnRodXNpYXN0IDkwcDxicj5LUklQVEEgR1JBTiBBw5FBREEgMjAwNiAtIENJTlZFIE9STyA8YnI+S1JJUFRBIEdSQU4gUkVTRVJWQSAyMDA4IC0gUGFya2VyIDkycDxicj5LUklQVEEgR1JBTiBBw5FBREEgMjAwNiAtIERFQ0FOVEVSIFBsYXRpbnVtIEJlc3QgQ2F2YSA5NXAgPGJyPktSSVBUQSBHUkFOIEHDkUFEQSAyMDA2IC0gT1JPIEFLQVRBVklOTyAoMzUgc3VtaWxsZXJlcyBkZSBFc3Bhw7FhKTxicj5CQVJSSUNBIEdUQU4gUkVTRVJWQSAyMDExIOKAkyBPUk8gUHJlbWlvcyBNZSBHdXN0YSA8YnI+QkFSUklDQSBHUkFOIFJFU0VSVkEgMjAxMSDigJMgT1JPIEkgQ09OQ1VSU08gSUJFUk9BTUVSSUNBTk8gVklOT1MgRVNQVU1PU09TIDxicj5CQVJSSUNBIEdSQU4gUkVTRVJWQSAyMDExIC0gQUVQRVYgTUVKT1IgRVNQVU1PU08gREVMIEHDkU8gPGJyPkJBUlJJQ0EgR1JBTiBSRVNFUlZBIDIwMTEgLSBPUk8gQ0hBTVBJT05TIFdJTkVTIDxicj5CQVJSSUNBIEdSQU4gUkVTRVJWQSAyMDEwIC0gQ0lWQVMgT1JPPGJyPkJBUlJJQ0EgR1JBTiBSRVNFUlZBIDIwMTEg4oCTIE9STyBNT05PVklOTyA8YnI+QkFSUklDQSBHUkFOIFJFU0VSVkEgMjAxMiDigJMgT1JPIENBVEFWSU5VTSBXT1JMRCBXSU5FIENPTVBFVElUSU9OIn19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNCBwYi00ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGgxIGNsYXNzPSYjMzk7dHh0QGwmIzM5Oz48Yj48c3BhbiBzdHlsZT0mIzM5O2NvbG9yOiByZ2IoMTg1LCAxNDYsIDI1KTsmIzM5Oz4yMDE2PC9zcGFuPjwvYj48L2gxPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiS1JJUFRBIEdSQU4gUkVTRVJWQSAyMDA2IC0gUGFya2VyIDkzcDxicj5LUklQVEEgR1JBTiBSRVNFUlZBIDIwMDggLSBPUk8gQ0lOVkUgPGJyPktSSVBUQSBHUkFOIFJFU0VSVkEgMjAwOCAtIE9STyBBS0FUQVZJTk8gQ0lWQVMgPGJyPkJBUlJJQ0EgR1JBTiBSRVNFUlZBIDIwMTEgLSBQRcORSU4gOTNwPGJyPkJBUlJJQ0EgR1JBTiBSRVNFUlZBIDIwMTEgLSBWSU5TIERFIENBVEFMVU5ZQSA5Nyw1cCJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTQgcGItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBsJiMzOTs+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+MjAxNTwvc3Bhbj48L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IktSSVBUQSBHUkFOIFJFU0VSVkEgMjAwNyAtIFZJVklOTyBuwrogMSBTcGFuaXNoIENhdmE8YnI+S1JJUFRBIEdSQU4gUkVTRVJWQSAgLSBNZWpvciBWaW5vIGVzcHVtb3NvIEFFUEVWIDxicj5CQVJSSUNBIEdSQU4gUkVTRVJWQSAyMDA4IC0gVml2aW5vIFRvcCAxMCJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTQgcGItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBsJiMzOTs+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+MjAxNDwvc3Bhbj48L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IktSSVBUQSBHUkFOIFJFU0VSVkEgMjAwNyAtICBWSVZJTk8gTWVqb3IgdmlubyA8YnI+S1JJUFRBIEdSQU4gUkVTRVJWQSAtIE1lam9yIEVzcHVtb3NvIEFFUEVWPGJyPktSSVBUQSBHUkFOIFJFU0VSVkEgMjAwNyAtIEdPTEQgOTMgcC4gV0lORSBVUCA8YnI+S1JJUFRBIEdSQU4gUkVTRVJWQSAyMDA3IC0gT1JPIENJTlZFIDxicj5CQVJSSUNBIEdSQU4gUkVTRVJWQSAyMDA4IC0gUEXDkUlOIDkycCJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTQgcGItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBsJiMzOTs+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+MjAxMzwvc3Bhbj48L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IktSSVBUQSBHUkFOIFJFU0VSVkEgMjAwNyAtIFZJTkFSSSBE4oCZT1IgTWlsbG9yIEVzY3Vtw7NzIEdyYW4gUmVzZXJ2YSA8YnI+S1JJUFRBIEdSQU4gUkVTRVJWQSAyMDA3IC0gVklOQVJJIEJST05aRSBlc3BlY2lhbCBkZSBsYSBETyBDYXZhPGJyPktSSVBUQSBHUkFOIFJFU0VSVkEgLSBQcmVtaW8gUklUWiBhbCB2aW5vIG3DoXMgdm90YWRvPGJyPktSSVBUQSBHUkFOIFJFU0VSVkEgLSBNZWpvciBlc3B1bW9zbyBBRVBFVjxicj5CQVJSSUNBIEdSQU4gUkVTRVJWQSAyMDA4IC0gREVDQU5URVIgQnJvbnplIDxicj5CQVJSSUNBIEdSQU4gUkVTRVJWQSAyMDA1IC0gIFBBUktFUiA5MnAifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC00IHBiLTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAbCYjMzk7PjxiPjxzcGFuIHN0eWxlPSYjMzk7Y29sb3I6IHJnYigxODUsIDE0NiwgMjUpOyYjMzk7PjIwMTI8L3NwYW4+PC9iPjwvaDE+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiJLUklQVEEgR1JBTiBSRVNFUlZBIDIwMDYgREVDQU5URVIgLiBCZXN0IFdpbmUuIEJyb256ZSA8YnI+S1JJUFRBIEdSQU4gUkVTRVJWQSBQcmVtaW8gUklUWiBhbCB2aW5vIG3DoXMgdm90YWRvIn19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgcHQtNCBwYi00ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGgxIGNsYXNzPSYjMzk7dHh0QGwmIzM5Oz48Yj48c3BhbiBzdHlsZT0mIzM5O2NvbG9yOiByZ2IoMTg1LCAxNDYsIDI1KTsmIzM5Oz4yMDExPC9zcGFuPjwvYj48L2gxPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiS1JJUFRBIEdSQU4gUkVTRVJWQSAyMDAzIDIwMTEgUEFSS0VSIDk0cDxicj5LUklQVEEgR1JBTiBSRVNFUlZBIDIwMDVQQVJLRVIgOTNwPGJyPktSSVBUQSBHUkFOIFJFU0VSVkEgMjAwNiBQcmVtaW8gUklUWiBhbCB2aW5vIG3DoXMgdm90YWRvIDxicj5LUklQVEEgR1JBTiBSRVNFUlZBIDIwMDYgTWVqb3IgZXNwdW1vc28gQUVQRVYifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSBwdC00IHBiLTQgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aDEgY2xhc3M9JiMzOTt0eHRAbCYjMzk7PjxiPjxzcGFuIHN0eWxlPSYjMzk7Y29sb3I6IHJnYigxODUsIDE0NiwgMjUpOyYjMzk7PjIwMDk8L3NwYW4+PC9iPjwvaDE+In19LHsidHlwZSI6Im1jIHctOC0xMCB3cy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiJLUklQVEEgR1JBTiBSRVNFUlZBIDIwMDMgLSBQQVJLRVIgOTRwIn19LHsidHlwZSI6Im1jIHctOC0xMCBocyB3cy0xLTEgcHQtNCBwYi00ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGgxIGNsYXNzPSYjMzk7dHh0QGwmIzM5Oz48Yj48c3BhbiBzdHlsZT0mIzM5O2NvbG9yOiByZ2IoMTg1LCAxNDYsIDI1KTsmIzM5Oz4xOTkwPC9zcGFuPjwvYj48L2gxPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiJDb25jdXJzbyBOYWNpb25hbCBldGlxdWV0YXMgZGUgY2F2YS4gUHJlbWlvIG1lam9yIGV0aXF1ZXRhIGRlbCBhw7FvPGJyPiJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTQgcGItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBsJiMzOTs+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+MTk4ODwvc3Bhbj48L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IktSSVBUQSAxOTgwIC0gRGlwbG9tZSBk4oCZSG9ubmV1ciBkZSBsYSAyOWUgZm9pcmUgaW50ZXJuYXRpb25hbCB2aXRpLXZpbmljb2xlIExqdWJpamFuYSJ9fSx7InR5cGUiOiJtYyB3LTgtMTAgd3MtMS0xIHB0LTQgcGItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxoMSBjbGFzcz0mIzM5O3R4dEBsJiMzOTs+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+MTk4NDwvc3Bhbj48L2I+PC9oMT4ifX0seyJ0eXBlIjoibWMgdy04LTEwIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IkdyYW5kIERpcGxvbWUgZOKAmUhvbm5ldXIgZXQgTWVkYWlsbGUgZOKAmW9yIC4gVmUgQ29uY291cnMgSW50ZXJuYXRpb25hbCBkZXMgVmlucyBkZSBCcmF0aXNsYXZhIChPZmZpY2UgSW50ZXJuYXRpb25hbCBkZSBsYSBWaWduZSBldCBkdSBWaW4pPGJyPk1lZGFpbGxlIGTigJlPciAyM2UgU8OpbGVjdGlvbiBNb25kaWFsZSBkZXMgVmlucy4gTGlzYm9ubmUgLiBJbnN0aXR1dCBJbnRlcm5hdGlvbmFsIFBvdXIgbGVzIFPDqWxlY3Rpb25zIGRlIGxhIFF1YWxpdMOpLjxicj4ifX1d'),
(3765, 39, 'seo_resumen', ''),
(3766, 39, 'seo_checktitleonfreaturedimage', '0'),
(3767, 39, 'seo_customtitleonfreaturedimage', ''),
(3768, 39, 'seo_freaturedimage', ''),
(3769, 39, 'seo_noodp', '0'),
(3770, 39, 'seo_noydir', '0'),
(3771, 39, 'seo_nofollow', '0'),
(3772, 39, 'seo_noarchive', '0'),
(3773, 39, 'seo_keywords', ''),
(3774, 39, 'seo_description', ''),
(3775, 39, 'seo_customimage', ''),
(3788, 40, 'page_content', 'W3sidHlwZSI6InctMS0xIGdjIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX0seyJ0eXBlIjoidmlkZW9mcy0wLTQwIHctMS0xIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBnIiwiYm94aGVpZ2h0IjpmYWxzZSwiZG9tIjp7fX1d'),
(3789, 40, 'seo_resumen', ''),
(3790, 40, 'seo_checktitleonfreaturedimage', '0'),
(3791, 40, 'seo_customtitleonfreaturedimage', ''),
(3792, 40, 'seo_freaturedimage', ''),
(3793, 40, 'seo_noodp', '0'),
(3794, 40, 'seo_noydir', '0'),
(3795, 40, 'seo_nofollow', '0'),
(3796, 40, 'seo_noarchive', '0'),
(3797, 40, 'seo_keywords', ''),
(3798, 40, 'seo_description', ''),
(3799, 40, 'seo_customimage', ''),
(3872, 22, 'gallery_id', '41'),
(3945, 29, 'gallery_id', '28'),
(3982, 41, 'page_content', 'W3sidHlwZSI6InctMS0xIGdjIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoidy00LTEwIGhzIHB0LTIgcHItMiBwYi0yIHBsLTIgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiJwb3NpdGlvbjogYWJzb2x1dGU7IHRvcDogMiU7IHJpZ2h0OiAxMCU7IiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGRpdj48ZGl2IGNsYXNzPSYjMzk7dHh0QGomIzM5OyBzdHlsZT0mIzM5O2Rpc3BsYXk6YmxvY2s7d2lkdGg6MTAwJTtoZWlnaHQ6MTAwJTtiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjU1IDI1NSAyNTUgLyA2NyUpO3BhZGRpbmc6IDMlIDQlIDElIDQlOyYjMzk7PjxwPk5vcyBlbmNvbnRyYW1vcyBlbiBTYW50IFNlZHVybmkgZCYjMzk7QW5vaWEuIGN1bmEgZGVsIENhdmEgZGVzZGUgc3UgbmFjaW1pZW50byBhIGZpbmFsZXMgZGVsIHMuIFhJWC4gZW4gbGEgem9uYSB0cmFkaWNpb25hbCBkZWxpbWl0YWRhIGNvbW8gJiMzOTtDb210YXRzIGRlIEJhcmNlbG9uYSYjMzk7LiBCYcOxYWRvcyBwb3IgZWwgTWVkaXRlcnLDoW5lbyB5IGFsIGFicmlnbyBkZSBsYXMgbW9udGHDsWFzIGRlIE1vbnRzZXJyYXQuIFZBTExTIEQmIzM5O0FOT0lBLUZPSVggbm9zIHByb3BvcmNpb25hIG1pY3RvY2xpbWFzIMO6bmljb3MgZW4gcGFyY2VsYXMgcXVlIHZhbiBkZSAwIGhhc3RhIDkwMCBtZXRyb3MgZGUgYWx0aXR1ZC4gRWwgcmVzcGV0byBhIGxhIHRpZXJyYSBjb24gdW4gY3VsdGl2byAxMDAlIGVjb2zDs2dpY28uIHkgdW5hIGVzbWVyYWRhIHZlbmRpbWlhIG1hbnVhbCBzb24gbGEgYmFzZSBwYXJhIHByZXBhcmFyIGxvcyB2aW5vcyBkZSBsb3MgcXVlIG5hY2Vyw6FuIG51ZXN0cm9zIGdyYW5kZXMgQ2F2YXMuPC9wPjwvZGl2PjwvZGl2PiJ9fSx7InR5cGUiOiJ3LTEtMSBocyAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6InBvc3RpdGlvbjogcmVsYXRpdmU7IiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50LzBhMmIzMGQ1MDFmMTU0MWVjZDA4NzE1ZTRlNjUxNTAzLmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoidy0xLTEgZyIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6e319LHsidHlwZSI6InctMS0xIGhtIGhsIGh4bCBwYi0zIHB0LTRAcyBwYi03QHMgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiJwb3NpdGlvbjogcmVsYXRpdmU7IiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGgxIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48Yj5ELk8uIENBVkE8L2I+PC9oMT4ifX0seyJ0eXBlIjoidy0xLTEgaG0gaGwgaHhsIHBiLTMgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8cD5Ob3MgZW5jb250cmFtb3MgZW4gU2FudCBTZWR1cm5pIGQmIzM5O0Fub2lhLiBjdW5hIGRlbCBDYXZhIGRlc2RlIHN1IG5hY2ltaWVudG8gYSBmaW5hbGVzIGRlbCBzLiBYSVguIGVuIGxhIHpvbmEgdHJhZGljaW9uYWwgZGVsaW1pdGFkYSBjb21vICYjMzk7Q29tdGF0cyBkZSBCYXJjZWxvbmEmIzM5Oy4gQmHDsWFkb3MgcG9yIGVsIE1lZGl0ZXJyw6FuZW8geSBhbCBhYnJpZ28gZGUgbGFzIG1vbnRhw7FhcyBkZSBNb250c2VycmF0LiBWQUxMUyBEJiMzOTtBTk9JQS1GT0lYIG5vcyBwcm9wb3JjaW9uYSBtaWN0b2NsaW1hcyDDum5pY29zIGVuIHBhcmNlbGFzIHF1ZSB2YW4gZGUgMCBoYXN0YSA5MDAgbWV0cm9zIGRlIGFsdGl0dWQuIEVsIHJlc3BldG8gYSBsYSB0aWVycmEgY29uIHVuIGN1bHRpdm8gMTAwJSBlY29sw7NnaWNvLiB5IHVuYSBlc21lcmFkYSB2ZW5kaW1pYSBtYW51YWwgc29uIGxhIGJhc2UgcGFyYSBwcmVwYXJhciBsb3Mgdmlub3MgZGUgbG9zIHF1ZSBuYWNlcsOhbiBudWVzdHJvcyBncmFuZGVzIENhdmFzLjwvcD4ifX0seyJ0eXBlIjoidy0xLTEgZ2MiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSBobSBobCBoeGwgcHQtNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC8wYTJiMzBkNTAxZjE1NDFlY2QwODcxNWU0ZTY1MTUwMy5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0xIGhtIGhsIGh4bCBwYi00ICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6e319XQ=='),
(3983, 41, 'seo_resumen', ''),
(3984, 41, 'seo_checktitleonfreaturedimage', '0'),
(3985, 41, 'seo_customtitleonfreaturedimage', ''),
(3986, 41, 'seo_freaturedimage', ''),
(3987, 41, 'seo_noodp', '0'),
(3988, 41, 'seo_noydir', '0'),
(3989, 41, 'seo_nofollow', '0'),
(3990, 41, 'seo_noarchive', '0'),
(3991, 41, 'seo_keywords', ''),
(3992, 41, 'seo_description', ''),
(3993, 41, 'seo_customimage', ''),
(4006, 41, 'gallery_id', '43'),
(4715, 42, 'page_content', 'W3sidHlwZSI6InctMS0xIHBiLTQiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGgxIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz48Yj5WSVNJVEFTPC9iPjwvaDE+In19LHsidHlwZSI6InctMS0xIHBiLTcgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEgaG0gaGwgaHhsIHBiLTQgbWItNCAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC9mOWZlM2JjYjkzMzg4YzMyYjY1YzFkMzYwNDUyMGVjZC5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz4ifX0seyJ0eXBlIjoidy0xLTIgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHAgY2xhc3M9JiMzOTt0eHRAaiYjMzk7Pk9mcmVjZW1vcyB2aXNpdGFzIGd1aWFkYXMgY29uIGNhdGFzIHBlcnNvbmFsaXphZGFzIHkgcmVhbGl6YW1vcyAgZGlzdGludGFzIGFjdGl2aWRhZGVzIGVub3R1csOtc3RpY2FzIGEgbG8gbGFyZ28gZGVsIGHDsW8gcGFyYSBwYXJ0aWN1bGFyZXMgeSBlbXByZXNhcy48L3A+PHA+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+VklTSVRBIFJFU0VSVkEgMTXigqw8L3NwYW4+PGJyPjwvYj5WaXNpdGEgeSBkZWd1c3RhY2nDs24gZGUgdW4gdmlubyB5IHRyZXMgY2F2YXMuPC9wPjxwPjxiPjxzcGFuIHN0eWxlPSYjMzk7Y29sb3I6IHJnYigxODUsIDE0NiwgMjUpOyYjMzk7PlZJU0lUQSBQUklWQURBIFBBUkEgMiBQQVggNTDigqw8L3NwYW4+PGJyPjwvYj5WaXNpdGEgcHJpdmFkYSB5IGNhdGEgZGUgbnVlc3Ryb3MgZ3JhbmRlcyBSZXNlcnZhcyBkZSBsYXJnYSBjcmlhbnphLiBJbmNsdcOtZG8gS3JpcHRhLjwvcD48cD48Yj48c3BhbiBzdHlsZT0mIzM5O2NvbG9yOiByZ2IoMTg1LCAxNDYsIDI1KTsmIzM5Oz5WSVNJVEEgR09VUk1FVCAzNeKCrDwvc3Bhbj48YnI+PC9iPlZpc2l0YSBwYXJhIDQtNiBwZXJzb25hcyB5IGRlZ3VzdGFjacOzbiBkZSBudWVzdHJvcyBncmFuZGVzIFJlc2VydmFzIGRlIGxhcmdhIGNyaWFuemEuPC9wPjxhIGhyZWY9JiMzOTttYWlsdG86dmlzaXRlc0BhZ3VzdGl0b3JlbGxvbWF0YS5jb20mIzM5OyBjbGFzcz0mIzM5O2J1dHRvbiB3cy0xLTEmIzM5Oz5SZXNlcnZhcjwvYT48YnI+PGJyPjxhIGhyZWY9JiMzOTtodHRwOi8vYWd1c3RpdG9yZWxsb21hdGEuY29tL19uZXcvZXMvYWN0aXZpZGFkZXMmIzM5Oz48c3BhbiBzdHlsZT0mIzM5O2NvbG9yOiByZ2IoMTg1LCAxNDYsIDI1KTsmIzM5Oz4mZ3Q7IDxzdHJvbmc+PHU+Q09OU1VMVEFSIEFDVElWSURBREVTIERFIENBREEgVEVNUE9SQURBPC91Pjwvc3Ryb25nPjwvc3Bhbj48L2E+PGJyPiJ9fSx7InR5cGUiOiJ3LTEtMiBocyAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC9mOWZlM2JjYjkzMzg4YzMyYjY1YzFkMzYwNDUyMGVjZC5qcGcmIzM5OyBjbGFzcz0mIzM5O2UmIzM5Oz4ifX0seyJ0eXBlIjoidy0xLTEgcGItNCIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6e319LHsidHlwZSI6InctMS0xICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9JiMzOTsmIzM5OyBzcmM9JiMzOTtjb250ZW50L2VkZjA3ZWE2MGNhMmM4NmY5MzhhNmQ1ZTgyYzIwNjIyLmpwZyYjMzk7IGNsYXNzPSYjMzk7ZSYjMzk7Pjxicj4ifX0seyJ0eXBlIjoidy0xLTEgcGItNCBwYi02QHMgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEgIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7InR5cGUiOiJ0ZXh0IiwidmFsdWUiOiI8aW1nIGFsdD0mIzM5OyYjMzk7IHNyYz0mIzM5O2NvbnRlbnQvYTMyM2YwODU4MzlhZTY2YjI5YjJiYzJiODkyYTI5MDkuanBnJiMzOTs+PGJyPiJ9fSx7InR5cGUiOiJ3LTEtMSBwYi00IiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiIiwiZG9tIjp7fX1d'),
(4716, 42, 'seo_resumen', ''),
(4717, 42, 'seo_checktitleonfreaturedimage', '0'),
(4718, 42, 'seo_customtitleonfreaturedimage', ''),
(4719, 42, 'seo_freaturedimage', ''),
(4720, 42, 'seo_noodp', '0'),
(4721, 42, 'seo_noydir', '0'),
(4722, 42, 'seo_nofollow', '0'),
(4723, 42, 'seo_noarchive', '0'),
(4724, 42, 'seo_keywords', ''),
(4725, 42, 'seo_description', ''),
(4726, 42, 'seo_customimage', ''),
(4739, 42, 'gallery_id', '45'),
(4920, 43, 'page_content', 'W3sidHlwZSI6InctMS0xIHB0LTQiLCJib3hoZWlnaHQiOmZhbHNlLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMSIsImJveGhlaWdodCI6ZmFsc2UsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGgxIGNsYXNzPSYjMzk7dHh0QGMmIzM5Oz5BQ1RJVklEQURFUzwvaDE+In19XQ=='),
(4921, 43, 'seo_resumen', ''),
(4922, 43, 'seo_checktitleonfreaturedimage', '0'),
(4923, 43, 'seo_customtitleonfreaturedimage', ''),
(4924, 43, 'seo_freaturedimage', ''),
(4925, 43, 'seo_noodp', '0'),
(4926, 43, 'seo_noydir', '0'),
(4927, 43, 'seo_nofollow', '0'),
(4928, 43, 'seo_noarchive', '0'),
(4929, 43, 'seo_keywords', ''),
(4930, 43, 'seo_description', ''),
(4931, 43, 'seo_customimage', ''),
(4932, 44, 'page_content', 'W3sidHlwZSI6InctMS0xIHB0LTQiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMiB3cy0xLTEgcGItNEBzICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHA+PGI+PHNwYW4gc3R5bGU9J2NvbG9yOiByZ2IoMTg1LCAxNDYsIDI1KTsnPlNPUEFSIERFIFZFUkVNQSAtIDE5IFNFVEVNQlJFIDIwMjA8L3NwYW4+PC9iPjwvcD5MVUdBUjogQ0FWQVMgQUdVU1TDjSBUT1JFTEzDkyBNQVRBIDxicj5IT1JBOiAyMC4zMEggICBQUkVDSU86IDQw4oKsPGJyPjxwIGNsYXNzPSd0eHRAaic+TG9yZW0gSXBzdW0gaXMgc2ltcGx5IGR1bW15IHRleHQgb2YgdGhlIHByaW50aW5nIGFuZCB0eXBlc2V0dGluZyBpbmR1c3RyeS4gTG9yZW0gSXBzdW0gaGFzIGJlZW4gdGhlIGluZHVzdHJ5J3Mgc3RhbmRhcmQgZHVtbXkgdGV4dCBldmVyIHNpbmNlIHRoZSAxNTAwcywgd2hlbiBhbiB1bmtub3duIHByaW50ZXIgdG9vayBhIGdhbGxleSBvZiB0eXBlIGFuZCBzY3JhbWJsZWQgaXQgdG8gbWFrZSBhIHR5cGUgc3BlY2ltZW4gYm9vay4gSXQgaGFzIHN1cnZpdmVkIG5vdCBvbmx5IGZpdmUgY2VudHVyaWVzLCBidXQgYWxzbyB0aGUgbGVhcCBpbnRvIGVsZWN0cm9uaWMgdHlwZXNldHRpbmcsIHJlbWFpbmluZyBlc3NlbnRpYWxseSB1bmNoYW5nZWQuIEl0IHdhcyBwb3B1bGFyaXNlZCBpbiB0aGUgMTk2MHMgd2l0aCB0aGUgcmVsZWFzZSBvZiBMZXRyYXNldCBzaGVldHMgY29udGFpbmluZyBMb3JlbSBJcHN1bSBwYXNzYWdlcywgYW5kIG1vcmUgcmVjZW50bHkgd2l0aCBkZXNrdG9wIHB1Ymxpc2hpbmcgc29mdHdhcmUgbGlrZSBBbGR1cyBQYWdlTWFrZXIgaW5jbHVkaW5nIHZlcnNpb25zIG9mIExvcmVtIElwc3VtLjwvcD4ifX0seyJ0eXBlIjoidy0xLTIgd3MtMS0xICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPGltZyBhbHQ9Jycgc3JjPSdjb250ZW50L2Y5ZmUzYmNiOTMzODhjMzJiNjVjMWQzNjA0NTIwZWNkLmpwZycgY2xhc3M9J2UnPjxicj4ifX0seyJ0eXBlIjoidy0xLTIiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiI4IiwiZG9tIjp7fX0seyJ0eXBlIjoidy0xLTEgcGItNCIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6e319XQ=='),
(4933, 44, 'seo_resumen', 'sopar de verema - 19 setembre 2020<br/>Lugar: Cavas Agustí Torelló Mata  <br/>Hora: 20.30h <br/>Precio: 40€'),
(4934, 44, 'seo_checktitleonfreaturedimage', '0'),
(4935, 44, 'seo_customtitleonfreaturedimage', ''),
(4936, 44, 'seo_freaturedimage', ''),
(4937, 44, 'seo_noodp', '0'),
(4938, 44, 'seo_noydir', '0'),
(4939, 44, 'seo_nofollow', '0'),
(4940, 44, 'seo_noarchive', '0'),
(4941, 44, 'seo_keywords', ''),
(4942, 44, 'seo_description', ''),
(4943, 44, 'seo_customimage', ''),
(6108, 51, 'page_content', 'W3sidHlwZSI6InctMS0xIHB0LTQiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fSx7InR5cGUiOiJ3LTEtMiB3cy0xLTEgcGItNEBzICIsImJveGhlaWdodCI6ZmFsc2UsInN0eWxlIjoiIiwiY2NsYXNzIjoiIiwiY29udHJvbCI6IiIsImRvbSI6eyJ0eXBlIjoidGV4dCIsInZhbHVlIjoiPHA+PGI+PHNwYW4gc3R5bGU9JiMzOTtjb2xvcjogcmdiKDE4NSwgMTQ2LCAyNSk7JiMzOTs+UFJPQkEgQUNUSVZJVEFUIDIwMjA8L3NwYW4+PC9iPjwvcD5MVUdBUjogQ0FWQVMgQUdVU1TDjSBUT1JFTEzDkyBNQVRBIDxicj5IT1JBOiAyMC4zMEggICBQUkVDSU86IDQw4oKsPGJyPjxwIGNsYXNzPSYjMzk7dHh0QGomIzM5Oz48c3R5bGU+cC5wMSB7bWFyZ2luOiAwLjBweCAwLjBweCAwLjBweCAwLjBweDsgZm9udDogMTIuMHB4IEhlbHZldGljYX08L3N0eWxlPjwvcD48cD5UZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLiBUZXh0IHByb2JhIGFjdGl2aXRhdCAyMDIwLjwvcD48cD48L3A+In19LHsidHlwZSI6InctMS0yIHdzLTEtMSAiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnsidHlwZSI6InRleHQiLCJ2YWx1ZSI6IjxpbWcgYWx0PSYjMzk7JiMzOTsgc3JjPSYjMzk7Y29udGVudC83NDZiYzkzYmRhOTc2ODNkNTkyYWE0ZjFjMWQ3YTEyOS5qcGcmIzM5Oz48YnI+In19LHsidHlwZSI6InctMS0yIiwiYm94aGVpZ2h0IjpmYWxzZSwic3R5bGUiOiIiLCJjY2xhc3MiOiIiLCJjb250cm9sIjoiOCIsImRvbSI6e319LHsidHlwZSI6InctMS0xIHBiLTQiLCJib3hoZWlnaHQiOmZhbHNlLCJzdHlsZSI6IiIsImNjbGFzcyI6IiIsImNvbnRyb2wiOiIiLCJkb20iOnt9fV0='),
(6109, 51, 'seo_checktitleonfreaturedimage', '0'),
(6110, 51, 'seo_customimage', ''),
(6111, 51, 'seo_customtitleonfreaturedimage', ''),
(6112, 51, 'seo_description', ''),
(6113, 51, 'seo_freaturedimage', ''),
(6114, 51, 'seo_keywords', ''),
(6115, 51, 'seo_noarchive', '0'),
(6116, 51, 'seo_nofollow', '0'),
(6117, 51, 'seo_noodp', '0'),
(6118, 51, 'seo_noydir', '0'),
(6119, 51, 'seo_resumen', 'sopar de verema - 19 setembre 2020<br/>Lugar: Cavas Agustí Torelló Mata  <br/>Hora: 20.30h <br/>Precio: 40€');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pages_types`
--

CREATE TABLE IF NOT EXISTS `pages_types` (
  `id` int(11) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `tmpl_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `pages_types`
--

INSERT INTO `pages_types` (`id`, `title`, `tmpl_name`) VALUES
(1, 'Página', 'pages_details'),
(2, 'Articulo', NULL),
(3, 'Blog - post', NULL),
(4, 'Faq', NULL),
(5, 'Actualidad', NULL),
(6, 'Home', 'home'),
(7, 'Producto - Cuadrícula', 'product_grid'),
(8, 'Actividades', NULL),
(9, 'Actividades - Listado', 'activity_list');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) unsigned NOT NULL,
  `order` int(11) DEFAULT '0',
  `cat_id` int(11) DEFAULT NULL,
  `lang_data` text,
  `active` int(11) DEFAULT NULL,
  `menu_title` varchar(100) DEFAULT NULL,
  `hash` varchar(255) DEFAULT '',
  `gallery_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `product`
--

INSERT INTO `product` (`id`, `order`, `cat_id`, `lang_data`, `active`, `menu_title`, `hash`, `gallery_id`) VALUES
(1, 3, 24, '{"es":"S&ograve;lid Blanc","en":"S&ograve;lid Blanc","ca":"S&ograve;lid Blanc"}', 0, 'Sòlid Blanc', 'solid-blanc', 2),
(2, 4, 24, '{"es":"S&ograve;lid Rosat","en":"S&ograve;lid Rosat","ca":"S&ograve;lid Rosat"}', 0, 'SÒLID ROSAT', 'solid-rosat', 3),
(3, 1, 24, '{"es":"vinagre de cava bals\\u00e1mico","en":"vinagre de cava bals\\u00e1mico","ca":"vinagre de cava bals\\u00e1mico"}', 1, 'vinagre de cava balsámico', 'vinagre-de-cava-balsamico', 5),
(4, 2, 24, '{"es":"vinagre de cava sec","en":"vinagre de cava sec","ca":"vinagre de cava sec"}', 1, 'vinagre de cava sec', 'vinagre de cava sec', 4),
(5, 0, 24, '{"es":"Marc de Cava L&rsquo;ESPERIT D''AGUST&Iacute; TORELL&Oacute; MATA","en":"Marc de Cava  L''Esperit","ca":"Marc de Cava  L''Esperit"}', 1, 'Marc de Cava L’ESPERIT D''AGUSTÍ TORELLÓ MATA', 'marc-de-cava-lesperit', 6),
(6, 1, 20, '{"es":"Xic Xarel.lo","en":"Xic","ca":"Xic"}', 1, 'XIC', 'xic-xarel.lo', 7),
(7, 2, 20, '{"es":"Espantallops Macabeu Barrica","en":"Espantallops","ca":"Espantallops"}', 1, 'Espantallops Macabeu Barrica', 'espantallops-macabeu-barrica', 8),
(8, 0, 19, '{"es":"Kripta 2007&lt;br\\/&gt;40 aniversari","en":"Kripta 2007&lt;br\\/&gt;40 aniversari","ca":"Kripta 2007&lt;br\\/&gt;40 aniversari"}', 0, 'KRIPTA 2007 40 aniversari', 'kripta-2007-40-aniversari', 9),
(9, 1, 19, '{"es":"Kripta gran reserva","en":"Kripta","ca":"Kripta"}', 1, 'KRIPTA GRAN RESERVA', 'kripta-gran-reserva', 10),
(10, 7, 19, '{"es":"Magnum Gran Reserva","en":"Magnum Gran Reserva","ca":"Magnum Gran Reserva"}', 1, 'MAGNUM GRAN RESERVA', 'magnum-gran-reserva', 11),
(11, 2, 19, '{"es":"Barrica gran reserva","en":"Gran Reserva Barrica","ca":"Gran Reserva Barrica"}', 1, 'BARRICA GRAN RESERVA', 'barrica-gran-reserva', 12),
(12, 4, 19, '{"es":"Ubac Brut Gran Reserva","en":"Ubac Gran Reserva","ca":"Ubac Gran Reserva"}', 1, 'UBAC BRUT GRAN RESERVA', 'ubac-gran-reserva', 13),
(13, 5, NULL, '{"es":"Brut Gran Reserva","en":"Brut Gran Reserva","ca":"Brut Gran Reserva"}', 1, 'BRUT GRAN RESERVA', 'brut-gran-reserva', 14),
(14, 5, 19, '{"es":"Brut Reserva","en":"Brut Reserva","ca":"Brut Reserva"}', 1, 'BRUT RESERVA', 'brut-reserva', 15),
(15, 6, 19, '{"es":"Rosat Trepat Reserva","en":"Rosat Trepat","ca":"Rosat Trepat"}', 1, 'ROSAT TREPAT RESERVA', 'rosat-trepat-reserva', 16),
(16, 8, 19, '{"es":"375 Brut Reserva","en":"375 Blanc","ca":"375 Blanc"}', 1, '375 Brut Reserva', '375-brut-reserva', 17),
(17, 9, NULL, '{"es":"375 Rosat Trepat","en":"375 Rosat Trepat","ca":"375 Rosat Trepat"}', 1, '375 ROSAT TREPAT', '375-rosat-trepat', 18),
(19, 0, 20, '{"es":"XIC Vermell Xarel.lo vermell","en":"XIC Vermell","ca":"XIC Vermell"}', 1, 'XIC Vermell', 'xic-vermell', 34),
(21, 3, 19, '{"es":"Brut Nature Gran Reserva","en":"Brut Nature Gran Reserva","ca":"Brut Nature Gran Reserva"}', 1, 'Brut Nature Gran Reserva', 'brut-nature-gran-reserva', 36);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product_color`
--

CREATE TABLE IF NOT EXISTS `product_color` (
  `id` int(11) unsigned NOT NULL,
  `lang_data` text,
  `order` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `product_color`
--

INSERT INTO `product_color` (`id`, `lang_data`, `order`) VALUES
(12, '{"es":"-sin especificaci&oacute;n-","en":"-without specification-","ca":"-sense especificaci&oacute;n-"}', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product_meta`
--

CREATE TABLE IF NOT EXISTS `product_meta` (
  `id` int(11) unsigned NOT NULL,
  `p_id` int(11) DEFAULT NULL,
  `m_key` varchar(250) DEFAULT NULL,
  `m_value` text
) ENGINE=InnoDB AUTO_INCREMENT=497 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `product_meta`
--

INSERT INTO `product_meta` (`id`, `p_id`, `m_key`, `m_value`) VALUES
(1, 8, 'page_is_link', 'content/dabe15cd3493c251afc06bc06fcc226a.pdf'),
(2, 8, 'lang_content', '{"es":"","en":"","ca":""}'),
(3, 8, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(4, 8, 'show_button_addcart', '0'),
(6, 8, 'seo_noodp', '0'),
(7, 8, 'seo_noydir', '0'),
(8, 8, 'seo_nofollow', '0'),
(9, 8, 'seo_noarchive', '0'),
(10, 8, 'seo_keywords', ''),
(11, 8, 'seo_description', ''),
(12, 8, 'seo_customimage', ''),
(13, 9, 'lang_content', '{"es":"","en":"","ca":""}'),
(14, 9, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(15, 9, 'show_button_addcart', '0'),
(16, 9, 'page_is_link', 'content/cc12b767e4fbf8e0953a30f4f2626d13.pdf'),
(17, 9, 'seo_noodp', '0'),
(18, 9, 'seo_noydir', '0'),
(19, 9, 'seo_nofollow', '0'),
(20, 9, 'seo_noarchive', '0'),
(21, 9, 'seo_keywords', ''),
(22, 9, 'seo_description', ''),
(23, 9, 'seo_customimage', ''),
(24, 10, 'lang_content', '{"es":"","en":"","ca":""}'),
(25, 10, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(26, 10, 'show_button_addcart', '0'),
(27, 10, 'page_is_link', 'content/e97d2dbbd2feead67b0849f96296e130.pdf'),
(28, 10, 'seo_noodp', '0'),
(29, 10, 'seo_noydir', '0'),
(30, 10, 'seo_nofollow', '0'),
(31, 10, 'seo_noarchive', '0'),
(32, 10, 'seo_keywords', ''),
(33, 10, 'seo_description', ''),
(34, 10, 'seo_customimage', ''),
(35, 11, 'lang_content', '{"es":"","en":"","ca":""}'),
(36, 11, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(37, 11, 'show_button_addcart', '0'),
(38, 11, 'page_is_link', 'content/63f50d967f97151989c34d5c0f6257a6.pdf'),
(39, 11, 'seo_noodp', '0'),
(40, 11, 'seo_noydir', '0'),
(41, 11, 'seo_nofollow', '0'),
(42, 11, 'seo_noarchive', '0'),
(43, 11, 'seo_keywords', ''),
(44, 11, 'seo_description', ''),
(45, 11, 'seo_customimage', ''),
(46, 12, 'lang_content', '{"es":"","en":"","ca":""}'),
(47, 12, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(48, 12, 'show_button_addcart', '0'),
(49, 12, 'page_is_link', 'content/c544b94c7b5939fc4e872ee03ebfdd80.pdf'),
(50, 12, 'seo_noodp', '0'),
(51, 12, 'seo_noydir', '0'),
(52, 12, 'seo_nofollow', '0'),
(53, 12, 'seo_noarchive', '0'),
(54, 12, 'seo_keywords', ''),
(55, 12, 'seo_description', ''),
(56, 12, 'seo_customimage', 'content/926451963f54612432aff80e321dffbd.pdf'),
(57, 13, 'lang_content', '{"es":"","en":"","ca":""}'),
(58, 13, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(59, 13, 'show_button_addcart', '0'),
(60, 13, 'page_is_link', 'content/ef5ce2fbf5c65bd1ef38b639dd7327ef.pdf'),
(61, 13, 'seo_noodp', '0'),
(62, 13, 'seo_noydir', '0'),
(63, 13, 'seo_nofollow', '0'),
(64, 13, 'seo_noarchive', '0'),
(65, 13, 'seo_keywords', ''),
(66, 13, 'seo_description', ''),
(67, 13, 'seo_customimage', ''),
(68, 14, 'lang_content', '{"es":"","en":"","ca":""}'),
(69, 14, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(70, 14, 'show_button_addcart', '0'),
(71, 14, 'page_is_link', 'content/a4e38ce985e8900c0a36aaf228f7b5c6.pdf'),
(72, 14, 'seo_noodp', '0'),
(73, 14, 'seo_noydir', '0'),
(74, 14, 'seo_nofollow', '0'),
(75, 14, 'seo_noarchive', '0'),
(76, 14, 'seo_keywords', ''),
(77, 14, 'seo_description', ''),
(78, 14, 'seo_customimage', ''),
(79, 15, 'lang_content', '{"es":"","en":"","ca":""}'),
(80, 15, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(81, 15, 'show_button_addcart', '0'),
(82, 15, 'page_is_link', 'content/820ffe1683a76e858de3b918e4176252.pdf'),
(83, 15, 'seo_noodp', '0'),
(84, 15, 'seo_noydir', '0'),
(85, 15, 'seo_nofollow', '0'),
(86, 15, 'seo_noarchive', '0'),
(87, 15, 'seo_keywords', ''),
(88, 15, 'seo_description', ''),
(89, 15, 'seo_customimage', ''),
(90, 6, 'lang_content', '{"es":"","en":"","ca":""}'),
(91, 6, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(92, 6, 'show_button_addcart', '0'),
(93, 6, 'page_is_link', 'content/aa4d13b708a87dde3afac0f2c4829aa3.pdf'),
(94, 6, 'seo_noodp', '0'),
(95, 6, 'seo_noydir', '0'),
(96, 6, 'seo_nofollow', '0'),
(97, 6, 'seo_noarchive', '0'),
(98, 6, 'seo_keywords', ''),
(99, 6, 'seo_description', ''),
(100, 6, 'seo_customimage', ''),
(101, 7, 'lang_content', '{"es":"","en":"","ca":""}'),
(102, 7, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(103, 7, 'show_button_addcart', '0'),
(104, 7, 'page_is_link', 'content/cbdbfff86cf3388a0af7450d2949a58b.pdf'),
(105, 7, 'seo_noodp', '0'),
(106, 7, 'seo_noydir', '0'),
(107, 7, 'seo_nofollow', '0'),
(108, 7, 'seo_noarchive', '0'),
(109, 7, 'seo_keywords', ''),
(110, 7, 'seo_description', ''),
(111, 7, 'seo_customimage', 'content/0eb72fe7b59f5d320f1bbf7cee69c17c.jpg'),
(134, 5, 'lang_content', '{"es":"","en":"","ca":""}'),
(135, 5, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(136, 5, 'show_button_addcart', '0'),
(137, 5, 'page_is_link', ''),
(138, 5, 'seo_noodp', '0'),
(139, 5, 'seo_noydir', '0'),
(140, 5, 'seo_nofollow', '0'),
(141, 5, 'seo_noarchive', '0'),
(142, 5, 'seo_keywords', ''),
(143, 5, 'seo_description', ''),
(144, 5, 'seo_customimage', ''),
(244, 16, 'lang_content', '{"es":"","en":"","ca":""}'),
(245, 16, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(246, 16, 'show_button_addcart', '0'),
(247, 16, 'page_is_link', ''),
(248, 16, 'seo_noodp', '0'),
(249, 16, 'seo_noydir', '0'),
(250, 16, 'seo_nofollow', '0'),
(251, 16, 'seo_noarchive', '0'),
(252, 16, 'seo_keywords', ''),
(253, 16, 'seo_description', ''),
(254, 16, 'seo_customimage', 'content/1b9471c2423d014428df8f1e8d510e2c.jpg'),
(255, 19, 'lang_content', '{"es":"","en":"","ca":""}'),
(256, 19, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(257, 19, 'show_button_addcart', '0'),
(258, 19, 'page_is_link', 'content/7a202742cf46561a19cef4c3dd37352e.pdf'),
(259, 19, 'seo_noodp', '0'),
(260, 19, 'seo_noydir', '0'),
(261, 19, 'seo_nofollow', '0'),
(262, 19, 'seo_noarchive', '0'),
(263, 19, 'seo_keywords', ''),
(264, 19, 'seo_description', ''),
(265, 19, 'seo_customimage', ''),
(266, 1, 'lang_content', '{"es":"","en":"","ca":""}'),
(267, 1, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(268, 1, 'show_button_addcart', '0'),
(269, 1, 'page_is_link', 'content/fb2581a3805deccea33f47bbc3f25033.pdf'),
(270, 1, 'seo_noodp', '0'),
(271, 1, 'seo_noydir', '0'),
(272, 1, 'seo_nofollow', '0'),
(273, 1, 'seo_noarchive', '0'),
(274, 1, 'seo_keywords', ''),
(275, 1, 'seo_description', ''),
(276, 1, 'seo_customimage', ''),
(277, 2, 'lang_content', '{"es":"","en":"","ca":""}'),
(278, 2, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(279, 2, 'show_button_addcart', '0'),
(280, 2, 'page_is_link', 'content/fb2581a3805deccea33f47bbc3f25033.pdf'),
(281, 2, 'seo_noodp', '0'),
(282, 2, 'seo_noydir', '0'),
(283, 2, 'seo_nofollow', '0'),
(284, 2, 'seo_noarchive', '0'),
(285, 2, 'seo_keywords', ''),
(286, 2, 'seo_description', ''),
(287, 2, 'seo_customimage', ''),
(354, 21, 'lang_content', '{"es":"","en":"","ca":""}'),
(355, 21, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(356, 21, 'show_button_addcart', '0'),
(357, 21, 'page_is_link', 'content/1f3c12c9f2df8761bd35c3ad688fdf23.pdf'),
(358, 21, 'seo_noodp', '0'),
(359, 21, 'seo_noydir', '0'),
(360, 21, 'seo_nofollow', '0'),
(361, 21, 'seo_noarchive', '0'),
(362, 21, 'seo_keywords', ''),
(363, 21, 'seo_description', ''),
(364, 21, 'seo_customimage', 'content/42e6c7460d5362e658a92be86aa778c9.jpg'),
(420, 4, 'lang_content', '{"es":"","en":"","ca":""}'),
(421, 4, 'lang_envio_extra', '{"es":"","en":"","ca":""}'),
(422, 4, 'show_button_addcart', '0'),
(423, 4, 'page_is_link', ''),
(424, 4, 'seo_noodp', '0'),
(425, 4, 'seo_noydir', '0'),
(426, 4, 'seo_nofollow', '0'),
(427, 4, 'seo_noarchive', '0'),
(428, 4, 'seo_keywords', ''),
(429, 4, 'seo_description', ''),
(430, 4, 'seo_customimage', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product_size`
--

CREATE TABLE IF NOT EXISTS `product_size` (
  `id` int(11) unsigned NOT NULL,
  `lang_data` text,
  `order` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `product_size`
--

INSERT INTO `product_size` (`id`, `lang_data`, `order`) VALUES
(8, '{"es":"-sin especificaci&oacute;n-","en":"-without specification-","ca":"-sense especificaci&oacute;n-"}', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product_stock`
--

CREATE TABLE IF NOT EXISTS `product_stock` (
  `id` int(11) unsigned NOT NULL,
  `prid` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT '0',
  `color_id` int(11) DEFAULT '0',
  `gallery_id` int(11) DEFAULT NULL,
  `precio_coste` float DEFAULT NULL,
  `precio_tachado` float DEFAULT NULL,
  `precio_venta` float DEFAULT NULL,
  `stock_min` int(11) DEFAULT NULL,
  `stock_base` int(11) DEFAULT NULL,
  `stock_count` int(11) DEFAULT NULL,
  `peso` float DEFAULT NULL,
  `size_y` int(11) DEFAULT NULL COMMENT 'arriba-abajo',
  `size_x` int(11) DEFAULT NULL COMMENT 'izq-der',
  `item_base` int(1) DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `product_stock`
--

INSERT INTO `product_stock` (`id`, `prid`, `size_id`, `color_id`, `gallery_id`, `precio_coste`, `precio_tachado`, `precio_venta`, `stock_min`, `stock_base`, `stock_count`, `peso`, `size_y`, `size_x`, `item_base`) VALUES
(1, 1, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(2, 2, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(3, 3, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(4, 4, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(5, 5, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(6, 6, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(7, 7, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(8, 8, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(9, 9, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(10, 10, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(11, 11, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(12, 12, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(13, 13, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(14, 14, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(15, 15, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(16, 16, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(17, 17, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(19, 19, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0.1, 0, 0, 1),
(21, 21, 8, 12, NULL, 0, 0, 0, 0, 0, 0, 0.1, 0, 0, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(11) NOT NULL,
  `user_name` varchar(60) NOT NULL DEFAULT '',
  `user_pass` text NOT NULL,
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_registred` datetime DEFAULT NULL,
  `user_activation_key` varchar(65) NOT NULL DEFAULT '',
  `user_status` int(3) NOT NULL DEFAULT '0',
  `user_add_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=10001 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`ID`, `user_name`, `user_pass`, `user_email`, `user_registred`, `user_activation_key`, `user_status`, `user_add_date`) VALUES
(9999, '211', '0138db6833e72a16271aba2ca4f179bc8225ef9b5eb879d1177db6271ffd29ea218be5472f9415aa84a7c93fc7349308d06ad460cfe490eb14198b69f6874fa5', 'hello@dm211.com', '0000-00-00 00:00:00', 'bcc2a152c5cd79ed342f02614cb6dc49', 1, '2019-02-15 19:51:48'),
(10000, 'admin-albert', 'b58ea32e420dd00997c99d0f48917cc67654e66e804fe2d09a12cc975ca021824f12643d58460f49cf7f1f4c1a3185235da036b375023aa0722a2b299ea49486', 'albertventosadesign@gmail.com', NULL, '', 1, '2019-11-25 09:52:06');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_login_ban`
--

CREATE TABLE IF NOT EXISTS `users_login_ban` (
  `id` int(11) unsigned NOT NULL,
  `isBanned` int(11) DEFAULT '0',
  `u_ip` varchar(50) DEFAULT NULL,
  `count_attempt` int(11) DEFAULT NULL,
  `time_sep` timestamp NULL DEFAULT NULL,
  `ban_time` timestamp NULL DEFAULT NULL,
  `u_name` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_meta`
--

CREATE TABLE IF NOT EXISTS `users_meta` (
  `ID` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `meta_key` varchar(65) NOT NULL DEFAULT '',
  `meta_value` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users_meta`
--

INSERT INTO `users_meta` (`ID`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 9999, 'user_level', '100'),
(2, 9999, 'user_access', '1'),
(5, 10000, 'user_access', '1'),
(6, 10000, 'user_level', '100');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_status`
--

CREATE TABLE IF NOT EXISTS `users_status` (
  `ID` bigint(9) NOT NULL,
  `user_status` int(3) NOT NULL,
  `status_value` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users_status`
--

INSERT INTO `users_status` (`ID`, `user_status`, `status_value`) VALUES
(1, 0, 'No activo'),
(2, 1, 'Activo'),
(3, 2, 'Baneado'),
(4, 3, 'Eliminado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_type`
--

CREATE TABLE IF NOT EXISTS `user_type` (
  `id` int(11) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `level` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `user_type`
--

INSERT INTO `user_type` (`id`, `title`, `level`) VALUES
(1, 'Default', 1),
(2, 'Comprador', 15),
(11, 'Creator (superadmin)', 100);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `apps_countries`
--
ALTER TABLE `apps_countries`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `hash` (`hash`);

--
-- Indices de la tabla `distribuidores`
--
ALTER TABLE `distribuidores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `iva`
--
ALTER TABLE `iva`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `year` (`year`);

--
-- Indices de la tabla `lang`
--
ALTER TABLE `lang`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `lang_key` (`lang_key`,`lang_type`);

--
-- Indices de la tabla `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `menus_meta`
--
ALTER TABLE `menus_meta`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `menus_structure`
--
ALTER TABLE `menus_structure`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indices de la tabla `menus_types`
--
ALTER TABLE `menus_types`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `options_key` (`options_key`);

--
-- Indices de la tabla `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `obj_hash` (`obj_hash`,`lang`);

--
-- Indices de la tabla `pages_lang_rel`
--
ALTER TABLE `pages_lang_rel`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `page_id` (`page_id`,`page_translate_id`,`lang_type`);

--
-- Indices de la tabla `pages_meta`
--
ALTER TABLE `pages_meta`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `p_id` (`p_id`,`meta_key`);

--
-- Indices de la tabla `pages_types`
--
ALTER TABLE `pages_types`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `hash` (`hash`);

--
-- Indices de la tabla `product_color`
--
ALTER TABLE `product_color`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `product_meta`
--
ALTER TABLE `product_meta`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `p_id` (`p_id`,`m_key`);

--
-- Indices de la tabla `product_size`
--
ALTER TABLE `product_size`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `product_stock`
--
ALTER TABLE `product_stock`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `prid` (`prid`,`size_id`,`color_id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `user_email` (`user_email`);

--
-- Indices de la tabla `users_login_ban`
--
ALTER TABLE `users_login_ban`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users_meta`
--
ALTER TABLE `users_meta`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `user_id` (`user_id`,`meta_key`);

--
-- Indices de la tabla `users_status`
--
ALTER TABLE `users_status`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `user_type`
--
ALTER TABLE `user_type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `apps_countries`
--
ALTER TABLE `apps_countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=253;
--
-- AUTO_INCREMENT de la tabla `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT de la tabla `distribuidores`
--
ALTER TABLE `distribuidores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=382;
--
-- AUTO_INCREMENT de la tabla `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT de la tabla `iva`
--
ALTER TABLE `iva`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `lang`
--
ALTER TABLE `lang`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=934;
--
-- AUTO_INCREMENT de la tabla `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `menus_meta`
--
ALTER TABLE `menus_meta`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `menus_structure`
--
ALTER TABLE `menus_structure`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT de la tabla `menus_types`
--
ALTER TABLE `menus_types`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `options`
--
ALTER TABLE `options`
  MODIFY `ID` bigint(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=86;
--
-- AUTO_INCREMENT de la tabla `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=54;
--
-- AUTO_INCREMENT de la tabla `pages_lang_rel`
--
ALTER TABLE `pages_lang_rel`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `pages_meta`
--
ALTER TABLE `pages_meta`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6864;
--
-- AUTO_INCREMENT de la tabla `pages_types`
--
ALTER TABLE `pages_types`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT de la tabla `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT de la tabla `product_color`
--
ALTER TABLE `product_color`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de la tabla `product_meta`
--
ALTER TABLE `product_meta`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=497;
--
-- AUTO_INCREMENT de la tabla `product_size`
--
ALTER TABLE `product_size`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `product_stock`
--
ALTER TABLE `product_stock`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10001;
--
-- AUTO_INCREMENT de la tabla `users_login_ban`
--
ALTER TABLE `users_login_ban`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `users_meta`
--
ALTER TABLE `users_meta`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `users_status`
--
ALTER TABLE `users_status`
  MODIFY `ID` bigint(9) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `user_type`
--
ALTER TABLE `user_type`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
